#!/bin/sh
awslocal sns create-topic --name bank-service-temp-card-backfill-event
awslocal sns create-topic --name card-vault-bin-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name credit-onboarding-service-allow-application-reapply-event
awslocal sns create-topic --name credit-program-service-notification-scheduled-event
awslocal sns create-topic --name decider-iso-message-log-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name dispute-service-dispute-hold-applied-event
awslocal sns create-topic --name iso-vault-chargeback-parent-message-found-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name mcd-chargeback-service-chargeback-message-received-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name mcd-chargeback-service-mcd-dispute-message-received-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name partner-configuration-service-partner-upserted-event
awslocal sns create-topic --name partner-gateway-customer-metadata-collected-event
awslocal sns create-topic --name payments-service-inbound-eft-upserted-event
awslocal sns create-topic --name payments-service-telpay-bill-payment-processed-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name savings-account-service-savings-program-settings-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name savings-onboarding-service-allow-application-reapply-event
awslocal sns create-topic --name admin-authorization-service-admin-user-roles-updated-event
awslocal sns create-topic --name application-service-adjudication-report-upserted-event
awslocal sns create-topic --name application-service-approved-credit-card-application-completed-event
awslocal sns create-topic --name application-service-berbix-id-verification-report-upserted-event
awslocal sns create-topic --name application-service-berbix-metadata-updated-event
awslocal sns create-topic --name application-service-comply-advantage-report-upserted-event
awslocal sns create-topic --name application-service-credit-account-application-upserted-event
awslocal sns create-topic --name application-service-credit-application-auto-declined-event
awslocal sns create-topic --name application-service-credit-application-completed-event
awslocal sns create-topic --name application-service-credit-application-created-event
awslocal sns create-topic --name application-service-credit-application-manually-approved-for-secured-credit-event
awslocal sns create-topic --name application-service-credit-application-manually-reviewed-event
awslocal sns create-topic --name application-service-credit-application-submitted-event
awslocal sns create-topic --name application-service-credit-application-user-preliminary-data-collected-event
awslocal sns create-topic --name application-service-credit-card-account-created-event
awslocal sns create-topic --name application-service-credit-card-application-completed-event
awslocal sns create-topic --name application-service-credit-limit-increase-accepted-event
awslocal sns create-topic --name application-service-enstream-account-integrity-report-upserted-event
awslocal sns create-topic --name application-service-enstream-report-upserted-event
awslocal sns create-topic --name application-service-fund-secured-external-funds-completed-event
awslocal sns create-topic --name application-service-fund-secured-account-external-funds-rejected-event
awslocal sns create-topic --name application-service-fund-secured-credit-with-external-account-initiated-event
awslocal sns create-topic --name application-service-fund-secured-credit-with-savings-account-initiated-event
awslocal sns create-topic --name application-service-hbc-credit-application-abandoned-event
awslocal sns create-topic --name application-service-hbc-credit-application-declined-event
awslocal sns create-topic --name application-service-hbc-credit-application-relinked-event
awslocal sns create-topic --name application-service-hbc-credit-application-upserted-event
awslocal sns create-topic --name application-service-hbc-employee-credit-declined-event
awslocal sns create-topic --name application-service-hbc-in-store-credit-application-upserted-event
awslocal sns create-topic --name application-service-hbc-in-store-setup-password-reminder-event
awslocal sns create-topic --name application-service-hbc-point-of-sale-indentification-upserted-event
awslocal sns create-topic --name application-service-in-store-application-credit-reason-declined-event
awslocal sns create-topic --name application-service-iovation-digital-fraud-report-upserted-event
awslocal sns create-topic --name application-service-maximum-dti-for-concentra-exceeded-event
awslocal sns create-topic --name application-service-neo-in-store-manual-identification-upserted-event
awslocal sns create-topic --name application-service-neo-secured-credit-application-upserted-event
awslocal sns create-topic --name application-service-savings-account-opened-event
awslocal sns create-topic --name application-service-savings-application-manual-reviewed-event
awslocal sns create-topic --name application-service-savings-application-submitted-event
awslocal sns create-topic --name application-service-secured-credit-application-abandoned-event
awslocal sns create-topic --name application-service-secured-credit-application-created-event
awslocal sns create-topic --name application-service-secured-credit-application-manually-reviewed-event
awslocal sns create-topic --name application-service-sin-income-tax-updated-event
awslocal sns create-topic --name application-service-transunion-hard-credit-report-upserted-event
awslocal sns create-topic --name application-service-transunion-kyc-report-upserted-event
awslocal sns create-topic --name application-service-transunion-personal-fraud-report-upserted-event
awslocal sns create-topic --name application-service-transunion-soft-credit-check-report-upserted-event
awslocal sns create-topic --name atb-pad-download-job-installment-plan-external-transfer-ivf-received-event
awslocal sns create-topic --name atb-pad-download-job-installment-plan-external-transfer-rin-received-event
awslocal sns create-topic --name atb-pad-download-job-secured-credit-external-transfer-ivf-received-event
awslocal sns create-topic --name atb-pad-download-job-secured-credit-external-transfer-rin-received-event
awslocal sns create-topic --name atb-pad-download-job-tax-refund-repayment-external-transfer-ivf-received-event
awslocal sns create-topic --name atb-pad-download-job-tax-refund-repayment-external-transfer-rin-received-event
awslocal sns create-topic --name atb-pre-authorized-debit-download-job-incoming-merchant-pad-event
awslocal sns create-topic --name attestation-ledger-svc-savings-balance-summary-generated-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name auto-transfer-service-credit-account-auto-payment-disabled-event
awslocal sns create-topic --name auto-transfer-service-credit-auto-payment-fallback-successful-event
awslocal sns create-topic --name auto-transfer-service-credit-auto-payment-successful-event
awslocal sns create-topic --name auto-transfer-service-external-to-savings-auto-transfer-initiated-event
awslocal sns create-topic --name auto-transfer-service-external-to-savings-subscription-auto-disabled-event
awslocal sns create-topic --name auto-transfer-service-savings-to-credit-auto-payment-triggered-event
awslocal sns create-topic --name auto-transfer-service-savings-to-payee-auto-bill-pay-initiated-event
awslocal sns create-topic --name auto-transfer-service-savings-to-payee-subscription-auto-disabled-event
awslocal sns create-topic --name auto-transfer-service-term-loan-auto-payment-triggered-event
awslocal sns create-topic --name bank-service-bill-pay-vendor-upserted-event
awslocal sns create-topic --name bank-service-billing-cycle-processed-event
awslocal sns create-topic --name bank-service-billing-cycle-upserted-event
awslocal sns create-topic --name bank-service-card-account-changed-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name bank-service-card-activated-event
awslocal sns create-topic --name bank-service-card-cancelled-event
awslocal sns create-topic --name bank-service-card-creation-initialized-event
awslocal sns create-topic --name bank-service-card-pin-updated-event
awslocal sns create-topic --name bank-service-card-reissuance-completed-event
awslocal sns create-topic --name bank-service-card-replacement-sent-event
awslocal sns create-topic --name bank-service-card-upserted-event
awslocal sns create-topic --name bank-service-complyadvantage-payment-review-triggered-event
awslocal sns create-topic --name bank-service-credit-account-charged-off-event
awslocal sns create-topic --name bank-service-credit-account-closed-event
awslocal sns create-topic --name bank-service-credit-account-created-event
awslocal sns create-topic --name bank-service-credit-account-opened-event
awslocal sns create-topic --name bank-service-credit-account-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name bank-service-credit-account-transaction-changed-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name bank-service-credit-account-transaction-deleted-event
awslocal sns create-topic --name bank-service-credit-account-transaction-upserted-event
awslocal sns create-topic --name bank-service-credit-account-upserted-event
awslocal sns create-topic --name bank-service-credit-limit-adjustment-upserted-event
awslocal sns create-topic --name bank-service-credit-limit-increase-applied-event
awslocal sns create-topic --name bank-service-credit-limit-increase-offer-initiated-event
awslocal sns create-topic --name bank-service-credit-limit-restriction-applied-event
awslocal sns create-topic --name bank-service-credit-program-requested-event
awslocal sns create-topic --name bank-service-e-transfer-customer-upserted-event
awslocal sns create-topic --name bank-service-e-transfer-fraud-check-request-event
awslocal sns create-topic --name bank-service-encrypted-pin-stored-event
awslocal sns create-topic --name bank-service-external-acc-verif-upserted-event
awslocal sns create-topic --name bank-service-external-account-deleted-event
awslocal sns create-topic --name bank-service-external-account-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name bank-service-external-account-to-secured-credit-funding-initiated-event
awslocal sns create-topic --name bank-service-external-account-upserted-event
awslocal sns create-topic --name bank-service-hbc-card-payment-prepared-event
awslocal sns create-topic --name bank-service-inbound-eft-declined-event
awslocal sns create-topic --name bank-service-incoming-aft-credit-txn-created-event
awslocal sns create-topic --name bank-service-incoming-bill-payment-failed-event
awslocal sns create-topic --name bank-service-incoming-bill-payment-transaction-error-triggered-event
awslocal sns create-topic --name bank-service-incoming-bill-payment-transaction-event
awslocal sns create-topic --name bank-service-initiate-tax-refund-funding-transfer-event
awslocal sns create-topic --name bank-service-interest-payment-evaluated-event
awslocal sns create-topic --name bank-service-mcd-card-creation-initialized-event
awslocal sns create-topic --name bank-service-mcd-card-suspension-status-changed-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name bank-service-outbound-eft-transaction-rejected-event
awslocal sns create-topic --name bank-service-outbound-eft-transaction-settled-event
awslocal sns create-topic --name bank-service-outgoing-bill-payment-created-event
awslocal sns create-topic --name bank-service-outgoing-bill-payment-reversed-event
awslocal sns create-topic --name bank-service-outgoing-etransfer-failed-event
awslocal sns create-topic --name bank-service-payee-upserted-event
awslocal sns create-topic --name bank-service-prepaid-card-application-pin-set-completed-event
awslocal sns create-topic --name bank-service-prepaid-card-creation-completed-event
awslocal sns create-topic --name bank-service-prepaid-settled-transaction-authorized-event
awslocal sns create-topic --name bank-service-prepaid-transaction-authorized-event
awslocal sns create-topic --name bank-service-prepaid-transaction-declined-event
awslocal sns create-topic --name bank-service-prepaid-transaction-reversed-event
awslocal sns create-topic --name bank-service-replacement-card-shipped-event
awslocal sns create-topic --name bank-service-rewards-cash-out-to-credit-failed-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name bank-service-rewards-cash-out-to-credit-succeeded-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name bank-service-rewards-cash-out-to-savings-failed-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name bank-service-rewards-cash-out-to-savings-succeeded-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name bank-service-rewards-cashout-to-savings-transaction-created-event
awslocal sns create-topic --name bank-service-savings-account-closed-event
awslocal sns create-topic --name bank-service-savings-account-created-event
awslocal sns create-topic --name bank-service-savings-account-opened-event
awslocal sns create-topic --name bank-service-savings-account-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name bank-service-savings-account-suspended-event
awslocal sns create-topic --name bank-service-savings-account-transaction-changed-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name bank-service-savings-account-transaction-deleted-event
awslocal sns create-topic --name bank-service-savings-account-transaction-upserted-event
awslocal sns create-topic --name bank-service-savings-account-unsuspended-event
awslocal sns create-topic --name bank-service-savings-account-updated-event
awslocal sns create-topic --name bank-service-savings-interest-cutoff-calculated-event
awslocal sns create-topic --name bank-service-savings-statement-period-closed-event
awslocal sns create-topic --name bank-service-savings-statement-period-upserted-event
awslocal sns create-topic --name bank-service-savings-to-secured-credit-funding-initiated-event
awslocal sns create-topic --name bank-service-secured-credit-account-closed-event
awslocal sns create-topic --name bank-service-secured-credit-deposit-account-upserted-event
awslocal sns create-topic --name bank-service-secured-credit-external-transfer-declined-event
awslocal sns create-topic --name bank-service-secured-credit-funds-completed-event
awslocal sns create-topic --name bank-service-secured-credit-limit-decreased-event
awslocal sns create-topic --name bank-service-secured-credit-limit-increased-event
awslocal sns create-topic --name bank-service-settled-transaction-authorized-event
awslocal sns create-topic --name bank-service-stale-e-transfer-status-fetched-event
awslocal sns create-topic --name bank-service-transaction-authorized-event
awslocal sns create-topic --name bank-service-transaction-declined-event
awslocal sns create-topic --name bank-service-transaction-manually-reversed-event
awslocal sns create-topic --name bank-service-transaction-reversed-event
awslocal sns create-topic --name bank-service-transfer-contact-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name bank-service-update-card-attributes-event
awslocal sns create-topic --name bill-pay-job-incoming-bill-payment-transaction-event
awslocal sns create-topic --name bill-pay-vendor-list-job-vendor-details-updated-event
awslocal sns create-topic --name card-scammer-service-e-transfer-fraud-check-response-event
awslocal sns create-topic --name card-scammer-service-eft-manually-reviewed-event
awslocal sns create-topic --name card-service-card-design-upserted-event
awslocal sns create-topic --name card-service-card-program-template-upserted-event
awslocal sns create-topic --name card-service-card-program-updated-event
awslocal sns create-topic --name card-service-card-reissuance-requested-event
awslocal sns create-topic --name card-service-card-reissued-event
awslocal sns create-topic --name card-service-unlink-hbc-subscription-event
awslocal sns create-topic --name card-vault-card-account-changed-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name card-vault-mcd-card-created-event
awslocal sns create-topic --name card-vault-mcd-card-suspension-status-changed-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name card-vault-mcd-card-upserted-event
awslocal sns create-topic --name card-vault-pin-block-generated-event
awslocal sns create-topic --name cardinal-service-mcd-3ds-otp-received-event
awslocal sns create-topic --name central-1-service-fresh-e-transfer-status-fetched-event
awslocal sns create-topic --name central-1-service-outgoing-bill-payment-download-event
awslocal sns create-topic --name central-1-service-outgoing-bill-payment-upload-event
awslocal sns create-topic --name core-ledger-service-credit-balance-summary-generated-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name core-ledger-service-loan-credit-facility-balance-summary-generated-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name core-ledger-service-rewards-merchant-balance-summary-generated-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name core-ledger-service-rewards-user-balance-summary-generated-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name core-ledger-service-savings-balance-summary-generated-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name core-ledger-service-term-loan-balance-summary-generated-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name cra-service-direct-deposit-registration-uploaded-event
awslocal sns create-topic --name credit-delinquency-service-account-marked-critically-delinquent-event
awslocal sns create-topic --name credit-delinquency-service-credit-delinquency-block-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name credit-delinquency-service-credit-delinquency-block-updated-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name credit-delinquency-service-delinquency-block-updated-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name credit-delinquency-service-series-snapshot-upserted-event
awslocal sns create-topic --name credit-facility-service-credit-facility-account-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name credit-onboarding-service-approved-credit-application-completed-event
awslocal sns create-topic --name credit-onboarding-service-baas-credit-application-created-event
awslocal sns create-topic --name credit-onboarding-service-baas-secured-credit-application-created-event
awslocal sns create-topic --name credit-onboarding-service-credit-application-abandoned-event
awslocal sns create-topic --name credit-onboarding-service-credit-application-created-event
awslocal sns create-topic --name credit-onboarding-service-credit-application-decision-updated-event
awslocal sns create-topic --name credit-onboarding-service-credit-application-ops-reviewed-event
awslocal sns create-topic --name credit-onboarding-service-credit-application-status-updated-event
awslocal sns create-topic --name credit-onboarding-service-credit-card-and-account-data-collected-event
awslocal sns create-topic --name credit-onboarding-service-credit-disclosure-accepted-event
awslocal sns create-topic --name credit-onboarding-service-credit-information-updated-event
awslocal sns create-topic --name credit-onboarding-service-in-store-application-credit-reason-declined-event
awslocal sns create-topic --name credit-onboarding-service-in-store-credit-application-declined-event
awslocal sns create-topic --name credit-onboarding-service-manual-id-verification-completed-event
awslocal sns create-topic --name credit-onboarding-service-reminder-claim-profile-instore-applications-event
awslocal sns create-topic --name credit-onboarding-service-secured-credit-application-funding-event
awslocal sns create-topic --name credit-onboarding-service-security-funds-completed-event
awslocal sns create-topic --name credit-onboarding-service-security-funds-external-transfer-initiated-event
awslocal sns create-topic --name credit-onboarding-service-security-funds-savings-transfer-initiated-event
awslocal sns create-topic --name credit-onboarding-service-user-information-reviewed-event
awslocal sns create-topic --name credit-program-service-credit-program-scheduled-event
awslocal sns create-topic --name customer-support-service-authentication-requested-event
awslocal sns create-topic --name customer-support-service-disposition-received-event
awslocal sns create-topic --name customer-support-service-user-authorized-support-event
awslocal sns create-topic --name data-transunion-credit-report-updated
awslocal sns create-topic --name decider-declined-transaction-fraudnet-request-prepared-event
awslocal sns create-topic --name decider-declined-transaction-fraudnet-update-prepared-event
awslocal sns create-topic --name decider-dispute-message-received-event
awslocal sns create-topic --name decider-exchange-rate-discrepancy-identified-event
awslocal sns create-topic --name decider-fingerprint-upsert-failed-event
awslocal sns create-topic --name decider-fraudnet-response-received-event
awslocal sns create-topic --name decider-iso-message-log-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name decider-merchant-invalid-transaction-received-event
awslocal sns create-topic --name decider-mobile-wallet-token-updated-event
awslocal sns create-topic --name decider-refund-reversal-debit-adjustment-event
awslocal sns create-topic --name decider-settled-transaction-refunded-event
awslocal sns create-topic --name decider-transaction-processed-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name decider-wallet-activated-event
awslocal sns create-topic --name decider-wallet-otp-requested-event
awslocal sns create-topic --name delinquency-service-balance-entry-upserted-event
awslocal sns create-topic --name delinquency-service-credit-account-charged-off-event
awslocal sns create-topic --name delinquency-service-delinquency-block-updated-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name delinquency-service-delinquency-upserted-event
awslocal sns create-topic --name delinquency-service-user-paid-off-amount-owing-event
awslocal sns create-topic --name dispute-service-dispute-closed-event
awslocal sns create-topic --name dispute-service-dispute-exchange-rate-variance-event
awslocal sns create-topic --name dispute-service-dispute-opened-event
awslocal sns create-topic --name e-transfer-service-e-transfer-customer-upserted-event
awslocal sns create-topic --name external-plan-benefits-service-user-membership-updated-event
awslocal sns create-topic --name i2c-service-3d-secure-message-received-event
awslocal sns create-topic --name i2c-service-i2c-card-created-event
awslocal sns create-topic --name identity-service-adjudication-report-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name identity-service-berbix-report-upserted-event
awslocal sns create-topic --name identity-service-berbix-retry-triggered-event
awslocal sns create-topic --name identity-service-berbix-token-successfully-retried-event
awslocal sns create-topic --name identity-service-berbix-transaction-created-event
awslocal sns create-topic --name identity-service-id-verification-completed-event
awslocal sns create-topic --name identity-service-investment-account-completion-data-populated-event
awslocal sns create-topic --name identity-service-kyc-document-requested-event
awslocal sns create-topic --name identity-service-primary-checks-completed-event
awslocal sns create-topic --name identity-service-primary-checks-retry-succeeded-event
awslocal sns create-topic --name identity-service-secondary-checks-completed-event
awslocal sns create-topic --name identity-service-transunion-soft-credit-check-report-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name identity-service-user-reports-metadata-snapshot-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name installments-service-credit-limit-replenished-event
awslocal sns create-topic --name installments-service-installment-plan-external-payment-rejected-event
awslocal sns create-topic --name installments-service-installment-plan-initialized-event
awslocal sns create-topic --name installments-service-installment-plan-payment-successful-event
awslocal sns create-topic --name installments-service-installment-plan-savings-insufficient-funds-event
awslocal sns create-topic --name installments-service-installment-repayment-method-invalidated-event
awslocal sns create-topic --name installments-service-installments-credit-limit-replenished-event
awslocal sns create-topic --name instant-tax-refund-service-instant-tax-refund-cra-deposit-received-event
awslocal sns create-topic --name instant-tax-refund-service-instant-tax-refund-initialized-event
awslocal sns create-topic --name instant-tax-refund-service-instant-tax-refund-nsf-charged-event
awslocal sns create-topic --name instant-tax-refund-service-instant-tax-refund-payment-failed-event
awslocal sns create-topic --name instant-tax-refund-service-instant-tax-refund-payment-successful-event
awslocal sns create-topic --name instant-tax-refund-service-instant-tax-refund-repayment-method-invalidated-event
awslocal sns create-topic --name instant-tax-refund-service-loan-agreement-generated-event
awslocal sns create-topic --name instant-tax-refund-service-loan-prequalification-fee-created-event
awslocal sns create-topic --name investment-onboarding-service-annual-reassessment-completed-event
awslocal sns create-topic --name investment-onboarding-service-annual-reassessment-started-event
awslocal sns create-topic --name investment-onboarding-service-application-metadata-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name investment-onboarding-service-approved-investment-application-completed-event
awslocal sns create-topic --name investment-onboarding-service-investment-account-completion-synced-event
awslocal sns create-topic --name investment-onboarding-service-investment-agreements-block-started-event
awslocal sns create-topic --name investment-onboarding-service-investment-application-abandoned-event
awslocal sns create-topic --name investment-onboarding-service-investment-application-decision-updated-event
awslocal sns create-topic --name investment-onboarding-service-investment-application-ops-reviewed-event
awslocal sns create-topic --name investment-onboarding-service-investment-portfolio-block-started-event
awslocal sns create-topic --name investment-onboarding-service-investment-questionnaire-block-started-event
awslocal sns create-topic --name investment-onboarding-service-investment-user-information-reviewed-event
awslocal sns create-topic --name investment-service-annual-reassessment-notification-created-event
awslocal sns create-topic --name investment-service-annual-reassessment-notification-updated-event
awslocal sns create-topic --name investment-service-annual-reassessment-synced-event
awslocal sns create-topic --name investment-service-application-flagged-for-review-event
awslocal sns create-topic --name investment-service-citizenship-upserted-event
awslocal sns create-topic --name investment-service-investment-account-closed-event
awslocal sns create-topic --name investment-service-investment-account-opened-event
awslocal sns create-topic --name investment-service-investment-agreement-previews-synced-event
awslocal sns create-topic --name investment-service-investment-application-reviewed-event
awslocal sns create-topic --name investment-service-investment-portfolio-changes-synced-event
awslocal sns create-topic --name investment-service-marital-information-upserted-event
awslocal sns create-topic --name investment-service-new-investment-account-type-opened-event
awslocal sns create-topic --name investment-service-questionnaire-reset-event
awslocal sns create-topic --name investment-service-risk-capacity-upserted-event
awslocal sns create-topic --name investment-service-suitability-annual-income-updated-event
awslocal sns create-topic --name ledger-service-credit-account-balance-summary-generated-event
awslocal sns create-topic --name ledger-service-payment-credit-allocated-event
awslocal sns create-topic --name ledger-service-secured-credit-balance-summary-replicated-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name ledger-service-transaction-processed-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name loan-credit-facility-service-loan-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name loan-onboarding-service-approved-loan-application-completed-event
awslocal sns create-topic --name loan-onboarding-service-loan-application-decision-updated-event
awslocal sns create-topic --name loan-onboarding-service-loan-application-ops-reviewed-event
awslocal sns create-topic --name loan-onboarding-service-loan-link-account-block-completed-event
awslocal sns create-topic --name loan-onboarding-service-user-information-reviewed-event
awslocal sns create-topic --name loan-onboarding-service-web-to-app-deep-link-requested-event
awslocal sns create-topic --name mcd-decider-card-block-attempt-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name mcd-decider-card-block-attempt-upserted-event
awslocal sns create-topic --name mcd-decider-fingerprint-upsert-failed-event
awslocal sns create-topic --name mcd-decider-iso-message-reference-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name mcd-decider-transaction-processed-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name merchant-billing-service-credit-card-payment-fail-event
awslocal sns create-topic --name merchant-billing-service-funding-account-credit-card-payment-fail-event
awslocal sns create-topic --name merchant-billing-service-location-freeze-event
awslocal sns create-topic --name merchant-billing-service-location-funding-account-updated-event
awslocal sns create-topic --name merchant-fingerprint-service-fingerprint-upserted-event
awslocal sns create-topic --name mortgage-service-mortgage-account-opened-event
awslocal sns create-topic --name mortgage-service-mortgage-account-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name mortgage-service-mortgage-lead-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name neo-mart-guaranteed-cashback-cycle-ended-event
awslocal sns create-topic --name neo-mart-order-processed-event
awslocal sns create-topic --name neo-mart-plan-subscription-renewed-event
awslocal sns create-topic --name neo-mart-rewards-account-created-event
awslocal sns create-topic --name neo-mart-rewards-account-transaction-upserted-event
awslocal sns create-topic --name neo-mart-rewards-account-upserted-event
awslocal sns create-topic --name neo-mart-rewards-cash-out-to-credit-failed-event
awslocal sns create-topic --name neo-mart-rewards-cash-out-to-credit-initiated-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name neo-mart-rewards-cash-out-to-savings-failed-event
awslocal sns create-topic --name neo-mart-rewards-cash-out-to-savings-initiated-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name neo-mart-store-item-refunded-event
awslocal sns create-topic --name neo-mart-top-up-processing-completed-event
awslocal sns create-topic --name neo-mart-plan-subscription-changed-event
awslocal sns create-topic --name payment-token-service-mcd-wallet-activated-event
awslocal sns create-topic --name payment-token-service-payment-token-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name payment-token-service-token-activation-code-notification-received-event
awslocal sns create-topic --name payment-token-service-token-provisioning-card-block-attempted-event
awslocal sns create-topic --name payments-service-cheque-bill-payment-processed-event
awslocal sns create-topic --name payments-service-complyadvantage-payment-review-triggered-event
awslocal sns create-topic --name payments-service-credit-account-auto-payment-failed-event
awslocal sns create-topic --name payments-service-credit-account-auto-payment-transfer-processed-event
awslocal sns create-topic --name payments-service-etf-fraud-check-event
awslocal sns create-topic --name payments-service-external-account-rin-recieved-event
awslocal sns create-topic --name payments-service-external-to-savings-transfer-overlimit-event
awslocal sns create-topic --name payments-service-external-to-term-loan-late-decline-received-event
awslocal sns create-topic --name payments-service-inbound-eft-hold-processed-event
awslocal sns create-topic --name payments-service-inbound-eft-processed-event
awslocal sns create-topic --name payments-service-installment-to-savings-transfer-created-event
awslocal sns create-topic --name payments-service-installment-to-savings-transfer-declined-event
awslocal sns create-topic --name payments-service-outbound-eft-rejected-event
awslocal sns create-topic --name payments-service-outbound-eft-release-funds-event
awslocal sns create-topic --name payments-service-savings-to-installments-transfer-created-event
awslocal sns create-topic --name payments-service-savings-to-installments-transfer-declined-event
awslocal sns create-topic --name payments-service-secured-credit-external-transfer-completed-event
awslocal sns create-topic --name payments-service-secured-credit-initial-funding-transfer-declined-event
awslocal sns create-topic --name payments-service-secured-credit-limit-decrease-unsuccessful-event
awslocal sns create-topic --name payments-service-secured-credit-limit-increase-unsuccessful-event
awslocal sns create-topic --name payments-service-telpay-bill-payment-failed-event
awslocal sns create-topic --name payments-service-telpay-bill-payment-processed-event
awslocal sns create-topic --name plans-service-addon-purchased-event
awslocal sns create-topic --name plans-service-benefit-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name plans-service-user-benefit-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name plans-service-user-benefits-updated-event
awslocal sns create-topic --name plans-service-user-rewards-plan-actions-event
awslocal sns create-topic --name prequalification-service-prequalification-claimed-event
awslocal sns create-topic --name prequalification-service-prequalification-completed-event
awslocal sns create-topic --name prequalification-service-prequalification-created-event
awslocal sns create-topic --name prequalification-service-prequalification-upserted-event
awslocal sns create-topic --name prequalification-service-prequalification-url-updated-event
awslocal sns create-topic --name redemption-service-basket-bump-spend-amount-condition-not-met-event
awslocal sns create-topic --name redemption-service-habit-builder-entry-earned-event
awslocal sns create-topic --name redemption-service-in-progress-offer-event
awslocal sns create-topic --name redemption-service-offer-expiring-soon-event
awslocal sns create-topic --name redemption-service-punch-earned-event
awslocal sns create-topic --name redemption-service-redemption-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name redemption-service-reward-redeemed-to-account-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name redemption-service-spend-entry-earned-event
awslocal sns create-topic --name referral-service-applied-bonus-expiring-soon-event
awslocal sns create-topic --name referral-service-applied-bonus-upserted-event
awslocal sns create-topic --name referral-service-applied-bounty-upserted-event
awslocal sns create-topic --name restriction-policy-service-restriction-policy-association-changed-event
awslocal sns create-topic --name restriction-policy-service-restriction-policy-changed-event
awslocal sns create-topic --name rewards-service-brand-updated-event
awslocal sns create-topic --name rewards-service-credit-transaction-upserted-event
awslocal sns create-topic --name rewards-service-eligible-offer-for-transaction-event
awslocal sns create-topic --name rewards-service-fingerprint-manually-created-event
awslocal sns create-topic --name rewards-service-fingerprint-upserted-event
awslocal sns create-topic --name rewards-service-location-funding-account-updated-event
awslocal sns create-topic --name rewards-service-location-updated-event
awslocal sns create-topic --name rewards-service-non-partner-transaction-processed-event
awslocal sns create-topic --name rewards-service-region-updated-event
awslocal sns create-topic --name rewards-service-transaction-reevaluated-event
awslocal sns create-topic --name rewards-service-transaction-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name rewards-service-user-eligible-for-winback-event
awslocal sns create-topic --name rewards-service-user-rewards-data-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name rewards-service-user-rewards-scheme-updated-event
awslocal sns create-topic --name rewards-service-valid-offer-expiring-soon-event
awslocal sns create-topic --name rewards-store-service-order-created-event
awslocal sns create-topic --name rewards-store-service-order-upserted-event
awslocal sns create-topic --name rewards-wizard-service-user-wizard-data-upserted-event
awslocal sns create-topic --name savings-account-service-deposit-partner-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name savings-account-service-savings-program-arrangement-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name savings-account-service-savings-program-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name savings-onboarding-service-application-abandoned-event
awslocal sns create-topic --name savings-onboarding-service-approved-savings-application-completed-event
awslocal sns create-topic --name savings-onboarding-service-baas-savings-application-created-event
awslocal sns create-topic --name savings-onboarding-service-prepaid-card-application-completed-event
awslocal sns create-topic --name savings-onboarding-service-prepaid-card-application-created-event
awslocal sns create-topic --name savings-onboarding-service-prepaid-card-creation-initialized-event
awslocal sns create-topic --name savings-onboarding-service-savings-application-decision-updated-event
awslocal sns create-topic --name savings-onboarding-service-savings-application-ops-reviewed-event
awslocal sns create-topic --name savings-onboarding-service-savings-application-status-updated-event
awslocal sns create-topic --name savings-onboarding-service-user-information-reviewed-event
awslocal sns create-topic --name savings-transaction-service-interest-payment-attempted-event
awslocal sns create-topic --name savings-transaction-service-savings-account-balance-summary-generated
awslocal sns create-topic --name savings-transaction-service-savings-transaction-upserted-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name sendy-service-credit-account-balance-requested
awslocal sns create-topic --name sendy-service-user-notification-preferences-upserted-event
awslocal sns create-topic --name smpplesaurus-mastercard-3d-secure
awslocal sns create-topic --name spend-analytics-service-fingerprint-spend-group-updated-event
awslocal sns create-topic --name spend-analytics-service-spend-summary-generated-event
awslocal sns create-topic --name spend-analytics-service-threshold-met-event
awslocal sns create-topic --name statement-gen-charged-off-account-interest-calculated-event
awslocal sns create-topic --name statement-gen-credit-card-statement-upserted-event
awslocal sns create-topic --name statement-gen-credit-data-processed-event
awslocal sns create-topic --name statement-gen-credit-pdf-processed-event
awslocal sns create-topic --name statement-gen-interest-processed-event
awslocal sns create-topic --name statement-gen-printed-statement-requested-event
awslocal sns create-topic --name statement-gen-saving-interest-processed-event
awslocal sns create-topic --name statement-gen-saving-pdf-processed-event
awslocal sns create-topic --name statement-gen-savings-data-processed-event
awslocal sns create-topic --name statement-gen-t5-slip-data-processed-event
awslocal sns create-topic --name statement-service-credit-account-balance-evaluated
awslocal sns create-topic --name statement-service-credit-account-statement-revealed-event
awslocal sns create-topic --name statement-service-credit-card-statement-upserted-event
awslocal sns create-topic --name statement-service-printed-statements-processed-event
awslocal sns create-topic --name statement-service-savings-account-statement-interest-settled-event
awslocal sns create-topic --name statement-service-savings-account-statement-requested-event
awslocal sns create-topic --name statement-service-savings-account-statement-revealed-event
awslocal sns create-topic --name statement-service-savings-statement-generation-failed
awslocal sns create-topic --name statement-service-savings-t5-slip-revealed-event
awslocal sns create-topic --name term-loan-service-installment-plan-balance-updated-event
awslocal sns create-topic --name term-loan-service-installment-plan-repayment-method-invalidated-event
awslocal sns create-topic --name term-loan-service-instant-tax-refund-balance-updated-event
awslocal sns create-topic --name term-loan-service-itr-repayment-method-invalidated-event
awslocal sns create-topic --name term-loan-service-term-loan-charged-off-event
awslocal sns create-topic --name term-loan-service-term-loan-nsf-charged-event
awslocal sns create-topic --name term-loan-service-term-loan-payment-successful-event
awslocal sns create-topic --name term-loan-service-term-loan-schedule-created-event
awslocal sns create-topic --name term-loan-service-term-loan-transfer-failed-event
awslocal sns create-topic --name unified-onboarding-service-address-module-updated-event
awslocal sns create-topic --name unified-onboarding-service-annual-income-module-updated-event
awslocal sns create-topic --name unified-onboarding-service-application-metadata-created-event
awslocal sns create-topic --name unified-onboarding-service-asset-information-module-upserted-event
awslocal sns create-topic --name unified-onboarding-service-block-completed-event
awslocal sns create-topic --name unified-onboarding-service-cashflow-information-module-upserted-event
awslocal sns create-topic --name unified-onboarding-service-citizenship-module-upserted-event
awslocal sns create-topic --name unified-onboarding-service-contact-information-module-updated-event
awslocal sns create-topic --name unified-onboarding-service-date-of-birth-module-updated-event
awslocal sns create-topic --name unified-onboarding-service-employer-information-module-updated-event
awslocal sns create-topic --name unified-onboarding-service-employment-module-updated-event
awslocal sns create-topic --name unified-onboarding-service-foreign-tax-information-module-updated-event
awslocal sns create-topic --name unified-onboarding-service-hashed-sin-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name unified-onboarding-service-housing-info-module-updated-event
awslocal sns create-topic --name unified-onboarding-service-id-verification-synced-event
awslocal sns create-topic --name unified-onboarding-service-id-verification-unsynced-event
awslocal sns create-topic --name unified-onboarding-service-investment-account-completion-synced-event
awslocal sns create-topic --name unified-onboarding-service-investment-agreements-data-populated-event
awslocal sns create-topic --name unified-onboarding-service-investment-annual-reassessment-data-populated-event
awslocal sns create-topic --name unified-onboarding-service-investment-portfolio-data-populated-event
awslocal sns create-topic --name unified-onboarding-service-investment-questionnaire-block-started-event
awslocal sns create-topic --name unified-onboarding-service-marital-information-module-upserted-event
awslocal sns create-topic --name unified-onboarding-service-metadata-upserted-event
awslocal sns create-topic --name unified-onboarding-service-monthly-debt-module-upserted-event
awslocal sns create-topic --name unified-onboarding-service-name-module-updated-event
awslocal sns create-topic --name unified-onboarding-service-prepaid-card-creation-initialized-event
awslocal sns create-topic --name unified-onboarding-service-property-and-assets-module-upserted-event
awslocal sns create-topic --name unified-onboarding-service-secondary-checks-information-retrieved-event
awslocal sns create-topic --name unified-onboarding-service-sin-module-updated-event
awslocal sns create-topic --name unified-onboarding-service-total-debt-module-upserted-event
awslocal sns create-topic --name unified-onboarding-service-total-savings-module-upserted-event
awslocal sns create-topic --name unified-onboarding-service-user-personal-information-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name user-service-admin-user-upserted-event
awslocal sns create-topic --name user-service-credit-product-updated-event
awslocal sns create-topic --name user-service-device-registration-requested-event
awslocal sns create-topic --name user-service-email-verification-code-requested-event
awslocal sns create-topic --name user-service-email-verification-requested-event
awslocal sns create-topic --name user-service-investment-product-updated-event
awslocal sns create-topic --name user-service-login-verification-requested-event
awslocal sns create-topic --name user-service-merchant-email-verification-requested-event
awslocal sns create-topic --name user-service-merchant-password-reset-requested-event
awslocal sns create-topic --name user-service-new-device-flagged-for-iovation-event
awslocal sns create-topic --name user-service-new-device-login-event
awslocal sns create-topic --name user-service-password-changed-event
awslocal sns create-topic --name user-service-password-existence-checked-event
awslocal sns create-topic --name user-service-password-reset-failed-event
awslocal sns create-topic --name user-service-password-reset-requested-event
awslocal sns create-topic --name user-service-password-reset-sms-verification-requested-event
awslocal sns create-topic --name user-service-password-setup-requested-event
awslocal sns create-topic --name user-service-phone-verification-completed-event
awslocal sns create-topic --name user-service-phone-verification-requested-event
awslocal sns create-topic --name user-service-savings-product-updated-event
awslocal sns create-topic --name user-service-security-questions-update-requested-event
awslocal sns create-topic --name user-service-security-questions-updated-event
awslocal sns create-topic --name user-service-user-account-unusual-activity-detected-event
awslocal sns create-topic --name user-service-user-annual-income-upserted-event
awslocal sns create-topic --name user-service-user-details-changed-event
awslocal sns create-topic --name user-service-user-email-verification-requested-event
awslocal sns create-topic --name user-service-user-hashed-sin-upserted-event
awslocal sns create-topic --name user-service-user-initialized-event
awslocal sns create-topic --name user-service-user-logged-in-event
awslocal sns create-topic --name user-service-user-replication-event.fifo --attributes FifoTopic=true
awslocal sns create-topic --name user-service-user-tax-information-upserted-event
awslocal sns create-topic --name user-service-user-upserted-event
awslocal sns create-topic --name webhook-complyadvantage-response-received-event
awslocal sns create-topic --name webhook-fingerprintjs-visitor-identified-event
awslocal sns create-topic --name webhook-flinks-get-accounts-details-response-received-event
awslocal sns create-topic --name webhook-flinks-response-received-event
awslocal sns create-topic --name webhook-fraud-vendor-fraud-signal-received-event
awslocal sns create-topic --name webhook-iterable-feed-in-app-message-sent-event
awslocal sns create-topic --name webhook-one-vest-account-status-updated-event
awslocal sns create-topic --name webhook-one-vest-transfer-status-updated-event
awslocal sns create-topic --name webhook-one-vest-user-status-updated-event
awslocal sns create-topic --name webhook-one-vest-user-suitability-review-due-updated-event
awslocal sns create-topic --name webhook-salesforce-mortgage-application-received-event
awslocal sns create-topic --name sendy
awslocal sns create-topic --name whodunnit-service-ezra-updated-event
awslocal sqs create-queue --queue-name bank-service-bin-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-vault-bin-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/bank-service-bin-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name bank-service-dispute-hold-applied-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:dispute-service-dispute-hold-applied-event --notification-endpoint http://localhost:4566/000000000000/bank-service-dispute-hold-applied-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-savings-program-settings-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-account-service-savings-program-settings-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/bank-service-savings-program-settings-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name bank-service-telpay-bill-payment-processed-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-telpay-bill-payment-processed-event.fifo --notification-endpoint http://localhost:4566/000000000000/bank-service-telpay-bill-payment-processed-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name card-scammer-service-partner-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:partner-configuration-service-partner-upserted-event --notification-endpoint http://localhost:4566/000000000000/card-scammer-service-partner-created-event --protocol sqs
awslocal sqs create-queue --queue-name card-scammer-service-partner-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:partner-configuration-service-partner-upserted-event --notification-endpoint http://localhost:4566/000000000000/card-scammer-service-partner-created-event --protocol sqs
awslocal sqs create-queue --queue-name card-service-bin-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-vault-bin-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/card-service-bin-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name card-vault-temp-card-backfill-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-temp-card-backfill-event --notification-endpoint http://localhost:4566/000000000000/card-vault-temp-card-backfill-event --protocol sqs
awslocal sqs create-queue --queue-name cash-management-service-savings-account-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/cash-management-service-savings-account-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name cash-management-service-savings-account-transaction-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-transaction-upserted-event --notification-endpoint http://localhost:4566/000000000000/cash-management-service-savings-account-transaction-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name client-risk-rating-service-comply-advantage-report-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-comply-advantage-report-upserted-event --notification-endpoint http://localhost:4566/000000000000/client-risk-rating-service-comply-advantage-report-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name dispute-service-mcd-dispute-message-received-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:mcd-chargeback-service-mcd-dispute-message-received-event.fifo --notification-endpoint http://localhost:4566/000000000000/dispute-service-mcd-dispute-message-received-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name dtr-service-billing-cycle-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-billing-cycle-upserted-event --notification-endpoint http://localhost:4566/000000000000/dtr-service-billing-cycle-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name eft-service-inbound-eft-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-inbound-eft-upserted-event --notification-endpoint http://localhost:4566/000000000000/eft-service-inbound-eft-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name eft-service-savings-program-settings-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-account-service-savings-program-settings-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/eft-service-savings-program-settings-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name eft-service-user-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/eft-service-user-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name iso-vault-chargeback-message-received-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:mcd-chargeback-service-chargeback-message-received-event.fifo --notification-endpoint http://localhost:4566/000000000000/iso-vault-chargeback-message-received-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name mcd-chargeback-service-chargeback-parent-message-found-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:iso-vault-chargeback-parent-message-found-event.fifo --notification-endpoint http://localhost:4566/000000000000/mcd-chargeback-service-chargeback-parent-message-found-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name mcd-decider-bin-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-vault-bin-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/mcd-decider-bin-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name mcd-decider-iso-message-log-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:decider-iso-message-log-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/mcd-decider-iso-message-log-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name notification-feed-ezra-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:whodunnit-service-ezra-updated-event --notification-endpoint http://localhost:4566/000000000000/notification-feed-ezra-updated-event --protocol sqs
awslocal sqs create-queue --queue-name notification-feed-ezra-second-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:whodunnit-service-ezra-updated-event --notification-endpoint http://localhost:4566/000000000000/notification-feed-ezra-second-updated-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-allow-credit-application-reapply --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-allow-application-reapply-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-allow-credit-application-reapply --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-allow-savings-application-reapply --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-onboarding-service-allow-application-reapply-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-allow-savings-application-reapply --protocol sqs
awslocal sqs create-queue --queue-name payment-token-service-bin-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-vault-bin-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/payment-token-service-bin-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name payment-token-service-card-program-template-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-service-card-program-template-upserted-event --notification-endpoint http://localhost:4566/000000000000/payment-token-service-card-program-template-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name payment-token-service-credit-account-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/payment-token-service-credit-account-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name payment-token-service-savings-account-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/payment-token-service-savings-account-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name payments-service-savings-program-settings-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-account-service-savings-program-settings-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/payments-service-savings-program-settings-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-credit-program-notification-scheduled-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-program-service-notification-scheduled-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-credit-program-notification-scheduled-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-password-reset-sms-verification-requested-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-password-reset-sms-verification-requested-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-password-reset-sms-verification-requested-event --protocol sqs
awslocal sqs create-queue --queue-name abu-service-card-account-changed-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-vault-card-account-changed-event.fifo --notification-endpoint http://localhost:4566/000000000000/abu-service-card-account-changed-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name adjudication-service-adjudication-report-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-adjudication-report-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/adjudication-service-adjudication-report-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name admin-authorization-service-admin-user-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-admin-user-upserted-event --notification-endpoint http://localhost:4566/000000000000/admin-authorization-service-admin-user-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name application-service-berbix-token-successfully-retried-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-berbix-token-successfully-retried-event --notification-endpoint http://localhost:4566/000000000000/application-service-berbix-token-successfully-retried-event --protocol sqs
awslocal sqs create-queue --queue-name application-service-credit-account-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-closed-event --notification-endpoint http://localhost:4566/000000000000/application-service-credit-account-closed-event --protocol sqs
awslocal sqs create-queue --queue-name application-service-credit-limit-increase-applied-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-limit-increase-applied-event --notification-endpoint http://localhost:4566/000000000000/application-service-credit-limit-increase-applied-event --protocol sqs
awslocal sqs create-queue --queue-name application-service-credit-limit-increase-offer-initiated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-limit-increase-offer-initiated-event --notification-endpoint http://localhost:4566/000000000000/application-service-credit-limit-increase-offer-initiated-event --protocol sqs
awslocal sqs create-queue --queue-name application-service-credit-product-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-credit-product-updated-event --notification-endpoint http://localhost:4566/000000000000/application-service-credit-product-updated-event --protocol sqs
awslocal sqs create-queue --queue-name application-service-jito-credit-application-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-credit-application-created-event --notification-endpoint http://localhost:4566/000000000000/application-service-jito-credit-application-created-event --protocol sqs
awslocal sqs create-queue --queue-name application-service-region-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-region-updated-event --notification-endpoint http://localhost:4566/000000000000/application-service-region-updated-event --protocol sqs
awslocal sqs create-queue --queue-name application-service-savings-product-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-savings-product-updated-event --notification-endpoint http://localhost:4566/000000000000/application-service-savings-product-updated-event --protocol sqs
awslocal sqs create-queue --queue-name application-service-secured-credit-fund-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-secured-credit-funds-completed-event --notification-endpoint http://localhost:4566/000000000000/application-service-secured-credit-fund-completed-event --protocol sqs
awslocal sqs create-queue --queue-name application-service-secured-credit-initial-funding-transfer-declined-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-secured-credit-initial-funding-transfer-declined-event --notification-endpoint http://localhost:4566/000000000000/application-service-secured-credit-initial-funding-transfer-declined-event --protocol sqs
awslocal sqs create-queue --queue-name application-service-user-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-upserted-event --notification-endpoint http://localhost:4566/000000000000/application-service-user-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name attestation-savings-transaction-service-balance-summary-generated-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:attestation-ledger-svc-savings-balance-summary-generated-event.fifo --notification-endpoint http://localhost:4566/000000000000/attestation-savings-transaction-service-balance-summary-generated-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name auto-transfer-service-credit-account-auto-payment-failed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-credit-account-auto-payment-failed-event --notification-endpoint http://localhost:4566/000000000000/auto-transfer-service-credit-account-auto-payment-failed-event --protocol sqs
awslocal sqs create-queue --queue-name auto-transfer-service-credit-account-auto-payment-transfer-processed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-credit-account-auto-payment-transfer-processed-event --notification-endpoint http://localhost:4566/000000000000/auto-transfer-service-credit-account-auto-payment-transfer-processed-event --protocol sqs
awslocal sqs create-queue --queue-name auto-transfer-service-credit-account-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-closed-event --notification-endpoint http://localhost:4566/000000000000/auto-transfer-service-credit-account-closed-event --protocol sqs
awslocal sqs create-queue --queue-name auto-transfer-service-credit-account-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-upserted-event --notification-endpoint http://localhost:4566/000000000000/auto-transfer-service-credit-account-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name auto-transfer-service-external-account-deleted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-external-account-deleted-event --notification-endpoint http://localhost:4566/000000000000/auto-transfer-service-external-account-deleted-event --protocol sqs
awslocal sqs create-queue --queue-name auto-transfer-service-external-account-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-external-account-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/auto-transfer-service-external-account-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name auto-transfer-service-external-account-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-external-account-upserted-event --notification-endpoint http://localhost:4566/000000000000/auto-transfer-service-external-account-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name auto-transfer-service-outbound-eft-rejected-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-outbound-eft-rejected-event --notification-endpoint http://localhost:4566/000000000000/auto-transfer-service-outbound-eft-rejected-event --protocol sqs
awslocal sqs create-queue --queue-name auto-transfer-service-savings-account-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-closed-event --notification-endpoint http://localhost:4566/000000000000/auto-transfer-service-savings-account-closed-event --protocol sqs
awslocal sqs create-queue --queue-name auto-transfer-service-savings-account-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-created-event --notification-endpoint http://localhost:4566/000000000000/auto-transfer-service-savings-account-created-event --protocol sqs
awslocal sqs create-queue --queue-name auto-transfer-service-savings-account-suspended-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-suspended-event --notification-endpoint http://localhost:4566/000000000000/auto-transfer-service-savings-account-suspended-event --protocol sqs
awslocal sqs create-queue --queue-name auto-transfer-service-savings-account-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-updated-event --notification-endpoint http://localhost:4566/000000000000/auto-transfer-service-savings-account-updated-event --protocol sqs
awslocal sqs create-queue --queue-name auto-transfer-service-statement-data-processed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-gen-credit-data-processed-event --notification-endpoint http://localhost:4566/000000000000/auto-transfer-service-statement-data-processed-event --protocol sqs
awslocal sqs create-queue --queue-name auto-transfer-service-term-loan-schedule-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:term-loan-service-term-loan-schedule-created-event --notification-endpoint http://localhost:4566/000000000000/auto-transfer-service-term-loan-schedule-created-event --protocol sqs
awslocal sqs create-queue --queue-name auto-transfer-service-transfer-contact-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-transfer-contact-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/auto-transfer-service-transfer-contact-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name auto-transfer-service-user-upsert-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-upserted-event --notification-endpoint http://localhost:4566/000000000000/auto-transfer-service-user-upsert-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-account-marked-critically-delinquent-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-delinquency-service-account-marked-critically-delinquent-event --notification-endpoint http://localhost:4566/000000000000/bank-service-account-marked-critically-delinquent-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-addon-purchased-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:plans-service-addon-purchased-event --notification-endpoint http://localhost:4566/000000000000/bank-service-addon-purchased-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-card-design-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-service-card-design-upserted-event --notification-endpoint http://localhost:4566/000000000000/bank-service-card-design-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-card-program-template-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-service-card-program-template-upserted-event --notification-endpoint http://localhost:4566/000000000000/bank-service-card-program-template-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-card-program-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-service-card-program-updated-event --notification-endpoint http://localhost:4566/000000000000/bank-service-card-program-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-charged-off-account-interest-calculated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-gen-charged-off-account-interest-calculated-event --notification-endpoint http://localhost:4566/000000000000/bank-service-charged-off-account-interest-calculated-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-cheque-bill-payment-processed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-cheque-bill-payment-processed-event --notification-endpoint http://localhost:4566/000000000000/bank-service-cheque-bill-payment-processed-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-complyadvantage-response-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:webhook-complyadvantage-response-received-event --notification-endpoint http://localhost:4566/000000000000/bank-service-complyadvantage-response-received-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-credit-account-charged-off-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:delinquency-service-credit-account-charged-off-event --notification-endpoint http://localhost:4566/000000000000/bank-service-credit-account-charged-off-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-credit-account-statement-revealed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-service-credit-account-statement-revealed-event --notification-endpoint http://localhost:4566/000000000000/bank-service-credit-account-statement-revealed-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-credit-application-abandoned-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-credit-application-abandoned-event --notification-endpoint http://localhost:4566/000000000000/bank-service-credit-application-abandoned-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-credit-application-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-credit-application-created-event --notification-endpoint http://localhost:4566/000000000000/bank-service-credit-application-created-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-credit-application-submitted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-credit-application-submitted-event --notification-endpoint http://localhost:4566/000000000000/bank-service-credit-application-submitted-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-credit-card-and-account-data-collected-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-credit-card-and-account-data-collected-event --notification-endpoint http://localhost:4566/000000000000/bank-service-credit-card-and-account-data-collected-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-credit-limit-increase-accepted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-credit-limit-increase-accepted-event --notification-endpoint http://localhost:4566/000000000000/bank-service-credit-limit-increase-accepted-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-credit-limit-replenished-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:installments-service-credit-limit-replenished-event --notification-endpoint http://localhost:4566/000000000000/bank-service-credit-limit-replenished-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-credit-pdf-processed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-gen-credit-pdf-processed-event --notification-endpoint http://localhost:4566/000000000000/bank-service-credit-pdf-processed-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-credit-program-scheduled-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-program-service-credit-program-scheduled-event --notification-endpoint http://localhost:4566/000000000000/bank-service-credit-program-scheduled-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-deposit-partner-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-account-service-deposit-partner-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/bank-service-deposit-partner-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name bank-service-dispute-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:dispute-service-dispute-closed-event --notification-endpoint http://localhost:4566/000000000000/bank-service-dispute-closed-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-dispute-opened-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:dispute-service-dispute-opened-event --notification-endpoint http://localhost:4566/000000000000/bank-service-dispute-opened-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-e-transfer-customer-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:e-transfer-service-e-transfer-customer-upserted-event --notification-endpoint http://localhost:4566/000000000000/bank-service-e-transfer-customer-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-e-transfer-fraud-check-response-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-scammer-service-e-transfer-fraud-check-response-event --notification-endpoint http://localhost:4566/000000000000/bank-service-e-transfer-fraud-check-response-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-external-account-rin-recieved-subscription --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-external-account-rin-recieved-event --notification-endpoint http://localhost:4566/000000000000/bank-service-external-account-rin-recieved-subscription --protocol sqs
awslocal sqs create-queue --queue-name bank-service-flinks-response-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:webhook-flinks-response-received-event --notification-endpoint http://localhost:4566/000000000000/bank-service-flinks-response-received-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-fresh-e-transfer-status-fetched-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:central-1-service-fresh-e-transfer-status-fetched-event --notification-endpoint http://localhost:4566/000000000000/bank-service-fresh-e-transfer-status-fetched-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-fund-secured-credit-with-external-account-initiated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-fund-secured-credit-with-external-account-initiated-event --notification-endpoint http://localhost:4566/000000000000/bank-service-fund-secured-credit-with-external-account-initiated-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-fund-secured-credit-with-savings-account-initiated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-fund-secured-credit-with-savings-account-initiated-event --notification-endpoint http://localhost:4566/000000000000/bank-service-fund-secured-credit-with-savings-account-initiated-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-get-accounts-details-response-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:webhook-flinks-get-accounts-details-response-received-event --notification-endpoint http://localhost:4566/000000000000/bank-service-get-accounts-details-response-received-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-i2c-card-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:i2c-service-i2c-card-created-event --notification-endpoint http://localhost:4566/000000000000/bank-service-i2c-card-created-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-inbound-eft-hold-processed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-inbound-eft-hold-processed-event --notification-endpoint http://localhost:4566/000000000000/bank-service-inbound-eft-hold-processed-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-inbound-eft-processed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-inbound-eft-processed-event --notification-endpoint http://localhost:4566/000000000000/bank-service-inbound-eft-processed-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-incoming-bill-payment-transaction-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bill-pay-job-incoming-bill-payment-transaction-event --notification-endpoint http://localhost:4566/000000000000/bank-service-incoming-bill-payment-transaction-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-installments-credit-limit-replenished-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:installments-service-installments-credit-limit-replenished-event --notification-endpoint http://localhost:4566/000000000000/bank-service-installments-credit-limit-replenished-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-interest-processed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-gen-interest-processed-event --notification-endpoint http://localhost:4566/000000000000/bank-service-interest-processed-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-jito-credit-application-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-credit-application-created-event --notification-endpoint http://localhost:4566/000000000000/bank-service-jito-credit-application-created-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-mcd-card-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-vault-mcd-card-created-event --notification-endpoint http://localhost:4566/000000000000/bank-service-mcd-card-created-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-mcd-transaction-processed-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:mcd-decider-transaction-processed-event.fifo --notification-endpoint http://localhost:4566/000000000000/bank-service-mcd-transaction-processed-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name bank-service-mobile-wallet-token-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:decider-mobile-wallet-token-updated-event --notification-endpoint http://localhost:4566/000000000000/bank-service-mobile-wallet-token-updated-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-outbound-eft-rejected-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-outbound-eft-rejected-event --notification-endpoint http://localhost:4566/000000000000/bank-service-outbound-eft-rejected-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-outbound-eft-release-funds-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-outbound-eft-release-funds-event --notification-endpoint http://localhost:4566/000000000000/bank-service-outbound-eft-release-funds-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-outgoing-bill-payment-download-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:central-1-service-outgoing-bill-payment-download-event --notification-endpoint http://localhost:4566/000000000000/bank-service-outgoing-bill-payment-download-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-outgoing-bill-payment-upload-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:central-1-service-outgoing-bill-payment-upload-event --notification-endpoint http://localhost:4566/000000000000/bank-service-outgoing-bill-payment-upload-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-payment-token-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payment-token-service-payment-token-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/bank-service-payment-token-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name bank-service-prepaid-card-application-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-onboarding-service-prepaid-card-application-created-event --notification-endpoint http://localhost:4566/000000000000/bank-service-prepaid-card-application-created-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-prepaid-card-creation-initialized-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-prepaid-card-creation-initialized-event --notification-endpoint http://localhost:4566/000000000000/bank-service-prepaid-card-creation-initialized-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-printed-statements-processed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-service-printed-statements-processed-event --notification-endpoint http://localhost:4566/000000000000/bank-service-printed-statements-processed-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-refund-reversal-debit-adjustment-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:decider-refund-reversal-debit-adjustment-event --notification-endpoint http://localhost:4566/000000000000/bank-service-refund-reversal-debit-adjustment-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-restriction-policy-association-changed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:restriction-policy-service-restriction-policy-association-changed-event --notification-endpoint http://localhost:4566/000000000000/bank-service-restriction-policy-association-changed-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-restriction-policy-changed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:restriction-policy-service-restriction-policy-changed-event --notification-endpoint http://localhost:4566/000000000000/bank-service-restriction-policy-changed-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-rewards-cash-out-to-credit-initiated-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:neo-mart-rewards-cash-out-to-credit-initiated-event.fifo --notification-endpoint http://localhost:4566/000000000000/bank-service-rewards-cash-out-to-credit-initiated-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name bank-service-rewards-cash-out-to-savings-initiated-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:neo-mart-rewards-cash-out-to-savings-initiated-event.fifo --notification-endpoint http://localhost:4566/000000000000/bank-service-rewards-cash-out-to-savings-initiated-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name bank-service-saving-pdf-processed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-gen-saving-pdf-processed-event --notification-endpoint http://localhost:4566/000000000000/bank-service-saving-pdf-processed-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-saving-interest-processed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-gen-saving-interest-processed-event --notification-endpoint http://localhost:4566/000000000000/bank-service-saving-interest-processed-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-savings-interest-payment-attempted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-transaction-service-interest-payment-attempted-event --notification-endpoint http://localhost:4566/000000000000/bank-service-savings-interest-payment-attempted-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-savings-program-arrangement-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-account-service-savings-program-arrangement-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/bank-service-savings-program-arrangement-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name bank-service-savings-program-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-account-service-savings-program-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/bank-service-savings-program-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name bank-service-savings-statement-interest-settled-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-service-savings-account-statement-interest-settled-event --notification-endpoint http://localhost:4566/000000000000/bank-service-savings-statement-interest-settled-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-savings-to-payee-auto-bill-pay-initiated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:auto-transfer-service-savings-to-payee-auto-bill-pay-initiated-event --notification-endpoint http://localhost:4566/000000000000/bank-service-savings-to-payee-auto-bill-pay-initiated-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-secured-credit-application-abandoned-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-secured-credit-application-abandoned-event --notification-endpoint http://localhost:4566/000000000000/bank-service-secured-credit-application-abandoned-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-secured-credit-application-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-secured-credit-application-created-event --notification-endpoint http://localhost:4566/000000000000/bank-service-secured-credit-application-created-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-secured-credit-external-transfer-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-secured-credit-external-transfer-completed-event --notification-endpoint http://localhost:4566/000000000000/bank-service-secured-credit-external-transfer-completed-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-secured-credit-funds-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-secured-credit-funds-completed-event --notification-endpoint http://localhost:4566/000000000000/bank-service-secured-credit-funds-completed-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-security-funds-external-transfer-initiated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-security-funds-external-transfer-initiated-event --notification-endpoint http://localhost:4566/000000000000/bank-service-security-funds-external-transfer-initiated-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-security-funds-savings-transfer-initiated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-security-funds-savings-transfer-initiated-event --notification-endpoint http://localhost:4566/000000000000/bank-service-security-funds-savings-transfer-initiated-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-settled-transaction-refunded-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:decider-settled-transaction-refunded-event --notification-endpoint http://localhost:4566/000000000000/bank-service-settled-transaction-refunded-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-store-item-refunded-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:neo-mart-store-item-refunded-event --notification-endpoint http://localhost:4566/000000000000/bank-service-store-item-refunded-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-telpay-bill-payment-processed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-telpay-bill-payment-processed-event --notification-endpoint http://localhost:4566/000000000000/bank-service-telpay-bill-payment-processed-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-transaction-processed-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:decider-transaction-processed-event.fifo --notification-endpoint http://localhost:4566/000000000000/bank-service-transaction-processed-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name bank-service-user-paid-off-amount-owing-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:delinquency-service-user-paid-off-amount-owing-event --notification-endpoint http://localhost:4566/000000000000/bank-service-user-paid-off-amount-owing-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-user-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-upserted-event --notification-endpoint http://localhost:4566/000000000000/bank-service-user-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name bank-service-vendor-details-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bill-pay-vendor-list-job-vendor-details-updated-event --notification-endpoint http://localhost:4566/000000000000/bank-service-vendor-details-updated-event --protocol sqs
awslocal sqs create-queue --queue-name card-scammer-service-credit-application-decision-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-credit-application-decision-updated-event --notification-endpoint http://localhost:4566/000000000000/card-scammer-service-credit-application-decision-updated-event --protocol sqs
awslocal sqs create-queue --queue-name card-scammer-service-declined-transaction-fraudnet-request-prepared-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:decider-declined-transaction-fraudnet-request-prepared-event --notification-endpoint http://localhost:4566/000000000000/card-scammer-service-declined-transaction-fraudnet-request-prepared-event --protocol sqs
awslocal sqs create-queue --queue-name card-scammer-service-declined-transaction-fraudnet-update-prepared-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:decider-declined-transaction-fraudnet-update-prepared-event --notification-endpoint http://localhost:4566/000000000000/card-scammer-service-declined-transaction-fraudnet-update-prepared-event --protocol sqs
awslocal sqs create-queue --queue-name card-scammer-service-e-transfer-fraud-check-request-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-e-transfer-fraud-check-request-event --notification-endpoint http://localhost:4566/000000000000/card-scammer-service-e-transfer-fraud-check-request-event --protocol sqs
awslocal sqs create-queue --queue-name card-scammer-service-etf-fraud-check-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-etf-fraud-check-event --notification-endpoint http://localhost:4566/000000000000/card-scammer-service-etf-fraud-check-event --protocol sqs
awslocal sqs create-queue --queue-name card-scammer-service-fraud-signal-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:webhook-fraud-vendor-fraud-signal-received-event --notification-endpoint http://localhost:4566/000000000000/card-scammer-service-fraud-signal-received-event --protocol sqs
awslocal sqs create-queue --queue-name card-scammer-service-fraudnet-response-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:decider-fraudnet-response-received-event --notification-endpoint http://localhost:4566/000000000000/card-scammer-service-fraudnet-response-received-event --protocol sqs
awslocal sqs create-queue --queue-name card-scammer-svc-merchant-invalid-transaction-received --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:decider-merchant-invalid-transaction-received-event --notification-endpoint http://localhost:4566/000000000000/card-scammer-svc-merchant-invalid-transaction-received --protocol sqs
awslocal sqs create-queue --queue-name card-scammer-service-restriction-policy-association-changed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:restriction-policy-service-restriction-policy-association-changed-event --notification-endpoint http://localhost:4566/000000000000/card-scammer-service-restriction-policy-association-changed-event --protocol sqs
awslocal sqs create-queue --queue-name card-scammer-service-restriction-policy-changed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:restriction-policy-service-restriction-policy-changed-event --notification-endpoint http://localhost:4566/000000000000/card-scammer-service-restriction-policy-changed-event --protocol sqs
awslocal sqs create-queue --queue-name card-scammer-service-savings-application-decision-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-onboarding-service-savings-application-decision-updated-event --notification-endpoint http://localhost:4566/000000000000/card-scammer-service-savings-application-decision-updated-event --protocol sqs
awslocal sqs create-queue --queue-name card-scammer-service-secondary-checks-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-secondary-checks-completed-event --notification-endpoint http://localhost:4566/000000000000/card-scammer-service-secondary-checks-completed-event --protocol sqs
awslocal sqs create-queue --queue-name card-scammer-service-user-logged-in-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-logged-in-event --notification-endpoint http://localhost:4566/000000000000/card-scammer-service-user-logged-in-event --protocol sqs
awslocal sqs create-queue --queue-name card-service-card-block-attempt-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:mcd-decider-card-block-attempt-upserted-event --notification-endpoint http://localhost:4566/000000000000/card-service-card-block-attempt-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name card-service-card-replacement-sent-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-card-replacement-sent-event --notification-endpoint http://localhost:4566/000000000000/card-service-card-replacement-sent-event --protocol sqs
awslocal sqs create-queue --queue-name card-service-card-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-card-upserted-event --notification-endpoint http://localhost:4566/000000000000/card-service-card-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name card-service-credit-account-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-closed-event --notification-endpoint http://localhost:4566/000000000000/card-service-credit-account-closed-event --protocol sqs
awslocal sqs create-queue --queue-name card-service-credit-application-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-credit-application-created-event --notification-endpoint http://localhost:4566/000000000000/card-service-credit-application-created-event --protocol sqs
awslocal sqs create-queue --queue-name card-service-secured-credit-application-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-secured-credit-application-created-event --notification-endpoint http://localhost:4566/000000000000/card-service-secured-credit-application-created-event --protocol sqs
awslocal sqs create-queue --queue-name card-vault-card-account-changed-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-card-account-changed-event.fifo --notification-endpoint http://localhost:4566/000000000000/card-vault-card-account-changed-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name card-vault-card-design-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-service-card-design-upserted-event --notification-endpoint http://localhost:4566/000000000000/card-vault-card-design-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name card-vault-card-program-template-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-service-card-program-template-upserted-event --notification-endpoint http://localhost:4566/000000000000/card-vault-card-program-template-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name card-vault-mcd-card-creation-initialized-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-mcd-card-creation-initialized-event --notification-endpoint http://localhost:4566/000000000000/card-vault-mcd-card-creation-initialized-event --protocol sqs
awslocal sqs create-queue --queue-name card-vault-mcd-card-suspension-status-changed-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-mcd-card-suspension-status-changed-event.fifo --notification-endpoint http://localhost:4566/000000000000/card-vault-mcd-card-suspension-status-changed-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name card-vault-user-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/card-vault-user-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name cardinal-service-card-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-card-upserted-event --notification-endpoint http://localhost:4566/000000000000/cardinal-service-card-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name cardinal-service-user-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-upserted-event --notification-endpoint http://localhost:4566/000000000000/cardinal-service-user-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name central-1-service-e-transfer-customer-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:e-transfer-service-e-transfer-customer-upserted-event --notification-endpoint http://localhost:4566/000000000000/central-1-service-e-transfer-customer-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name central-1-service-outgoing-bill-payment-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-outgoing-bill-payment-created-event --notification-endpoint http://localhost:4566/000000000000/central-1-service-outgoing-bill-payment-created-event --protocol sqs
awslocal sqs create-queue --queue-name central-1-service-payee-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-payee-upserted-event --notification-endpoint http://localhost:4566/000000000000/central-1-service-payee-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name central-1-service-stale-e-transfer-status-fetched-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-stale-e-transfer-status-fetched-event --notification-endpoint http://localhost:4566/000000000000/central-1-service-stale-e-transfer-status-fetched-event --protocol sqs
awslocal sqs create-queue --queue-name cra-service-approved-loan-application-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:loan-onboarding-service-approved-loan-application-completed-event --notification-endpoint http://localhost:4566/000000000000/cra-service-approved-loan-application-completed-event --protocol sqs
awslocal sqs create-queue --queue-name cra-service-savings-account-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-created-event --notification-endpoint http://localhost:4566/000000000000/cra-service-savings-account-created-event --protocol sqs
awslocal sqs create-queue --queue-name cra-service-user-tax-information-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-tax-information-upserted-event --notification-endpoint http://localhost:4566/000000000000/cra-service-user-tax-information-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name cra-service-user-upserted-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/cra-service-user-upserted-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name credit-delinquency-service-credit-account-charged-off-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-charged-off-event --notification-endpoint http://localhost:4566/000000000000/credit-delinquency-service-credit-account-charged-off-event --protocol sqs
awslocal sqs create-queue --queue-name credit-delinquency-service-credit-account-statement-revealed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-service-credit-account-statement-revealed-event --notification-endpoint http://localhost:4566/000000000000/credit-delinquency-service-credit-account-statement-revealed-event --protocol sqs
awslocal sqs create-queue --queue-name credit-delinquency-service-payment-credit-allocated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:ledger-service-payment-credit-allocated-event --notification-endpoint http://localhost:4566/000000000000/credit-delinquency-service-payment-credit-allocated-event --protocol sqs
awslocal sqs create-queue --queue-name credit-delinquency-service-series-snapshot-upserted-subscription --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-delinquency-service-series-snapshot-upserted-event --notification-endpoint http://localhost:4566/000000000000/credit-delinquency-service-series-snapshot-upserted-subscription --protocol sqs
awslocal sqs create-queue --queue-name credit-delinquency-service-transunion-creditvision-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:data-transunion-credit-report-updated --notification-endpoint http://localhost:4566/000000000000/credit-delinquency-service-transunion-creditvision-received-event --protocol sqs
awslocal sqs create-queue --queue-name credit-facility-service-account-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-closed-event --notification-endpoint http://localhost:4566/000000000000/credit-facility-service-account-closed-event --protocol sqs
awslocal sqs create-queue --queue-name credit-facility-service-account-opened-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-opened-event --notification-endpoint http://localhost:4566/000000000000/credit-facility-service-account-opened-event --protocol sqs
awslocal sqs create-queue --queue-name credit-facility-service-credit-account-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-created-event --notification-endpoint http://localhost:4566/000000000000/credit-facility-service-credit-account-created-event --protocol sqs
awslocal sqs create-queue --queue-name credit-facility-service-hbc-employee-credit-declined-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-hbc-employee-credit-declined-event --notification-endpoint http://localhost:4566/000000000000/credit-facility-service-hbc-employee-credit-declined-event --protocol sqs
awslocal sqs create-queue --queue-name credit-facility-service-maximum-dti-for-concentra-exceeded-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-maximum-dti-for-concentra-exceeded-event --notification-endpoint http://localhost:4566/000000000000/credit-facility-service-maximum-dti-for-concentra-exceeded-event --protocol sqs
awslocal sqs create-queue --queue-name credit-facility-service-secured-credit-application-abandoned-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-secured-credit-application-abandoned-event --notification-endpoint http://localhost:4566/000000000000/credit-facility-service-secured-credit-application-abandoned-event --protocol sqs
awslocal sqs create-queue --queue-name credit-facility-service-secured-credit-application-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-secured-credit-application-created-event --notification-endpoint http://localhost:4566/000000000000/credit-facility-service-secured-credit-application-created-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-address-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-address-module-updated-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-address-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-annual-income-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-annual-income-module-updated-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-annual-income-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-application-metadata-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-application-metadata-created-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-application-metadata-created-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-berbix-retry-triggered-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-berbix-retry-triggered-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-berbix-retry-triggered-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-berbix-transaction-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-berbix-transaction-created-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-berbix-transaction-created-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-block-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-block-completed-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-block-completed-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-card-program-template-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-service-card-program-template-upserted-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-card-program-template-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-contact-information-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-contact-information-module-updated-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-contact-information-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-credit-account-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-credit-account-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-credit-product-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-credit-product-updated-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-credit-product-updated-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-date-of-birth-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-date-of-birth-module-updated-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-date-of-birth-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-employment-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-employment-module-updated-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-employment-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-encrypted-pin-stored-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-encrypted-pin-stored-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-encrypted-pin-stored-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-housing-info-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-housing-info-module-updated-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-housing-info-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-id-verification-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-id-verification-completed-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-id-verification-completed-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-id-verification-synced-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-id-verification-synced-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-id-verification-synced-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-id-verification-unsynced-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-id-verification-unsynced-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-id-verification-unsynced-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-legacy-credit-application-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-credit-application-created-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-legacy-credit-application-created-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-name-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-name-module-updated-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-name-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-partner-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:partner-configuration-service-partner-upserted-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-partner-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-primary-checks-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-primary-checks-completed-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-primary-checks-completed-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-primary-checks-retry-succeeded-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-primary-checks-retry-succeeded-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-primary-checks-retry-succeeded-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-secondary-checks-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-secondary-checks-completed-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-secondary-checks-completed-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-secured-credit-funds-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-secured-credit-funds-completed-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-secured-credit-funds-completed-event --protocol sqs
awslocal sqs create-queue --queue-name credit-onboarding-service-secured-credit-ini-funding-transfer-declined-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-secured-credit-initial-funding-transfer-declined-event --notification-endpoint http://localhost:4566/000000000000/credit-onboarding-service-secured-credit-ini-funding-transfer-declined-event --protocol sqs
awslocal sqs create-queue --queue-name credit-program-service-credit-program-requested-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-program-requested-event --notification-endpoint http://localhost:4566/000000000000/credit-program-service-credit-program-requested-event --protocol sqs
awslocal sqs create-queue --queue-name credit-reporting-service-credit-card-statement-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-gen-credit-card-statement-upserted-event --notification-endpoint http://localhost:4566/000000000000/credit-reporting-service-credit-card-statement-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name credit-reporting-service-secured-balance-summary-replicated-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:ledger-service-secured-credit-balance-summary-replicated-event.fifo --notification-endpoint http://localhost:4566/000000000000/credit-reporting-service-secured-balance-summary-replicated-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name statement-gen-credit-data-processed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-gen-credit-data-processed-event --notification-endpoint http://localhost:4566/000000000000/statement-gen-credit-data-processed-event --protocol sqs
awslocal sqs create-queue --queue-name credit-transaction-balance-summary-generated-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:core-ledger-service-credit-balance-summary-generated-event.fifo --notification-endpoint http://localhost:4566/000000000000/credit-transaction-balance-summary-generated-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name customer-support-service-user-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/customer-support-service-user-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name decider-card-cancelled-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-card-cancelled-event --notification-endpoint http://localhost:4566/000000000000/decider-card-cancelled-event --protocol sqs
awslocal sqs create-queue --queue-name decider-card-program-template-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-service-card-program-template-upserted-event --notification-endpoint http://localhost:4566/000000000000/decider-card-program-template-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name decider-card-replacement-sent-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-card-replacement-sent-event --notification-endpoint http://localhost:4566/000000000000/decider-card-replacement-sent-event --protocol sqs
awslocal sqs create-queue --queue-name decider-card-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-card-upserted-event --notification-endpoint http://localhost:4566/000000000000/decider-card-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name decider-credit-account-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-closed-event --notification-endpoint http://localhost:4566/000000000000/decider-credit-account-closed-event --protocol sqs
awslocal sqs create-queue --queue-name decider-credit-account-opened-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-opened-event --notification-endpoint http://localhost:4566/000000000000/decider-credit-account-opened-event --protocol sqs
awslocal sqs create-queue --queue-name decider-credit-delinquency-block-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-delinquency-service-credit-delinquency-block-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/decider-credit-delinquency-block-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name decider-fingerprint-manually-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-fingerprint-manually-created-event --notification-endpoint http://localhost:4566/000000000000/decider-fingerprint-manually-created-event --protocol sqs
awslocal sqs create-queue --queue-name decider-merchant-fingerprint-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:merchant-fingerprint-service-fingerprint-upserted-event --notification-endpoint http://localhost:4566/000000000000/decider-merchant-fingerprint-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name decider-transaction-manually-reversed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-transaction-manually-reversed-event --notification-endpoint http://localhost:4566/000000000000/decider-transaction-manually-reversed-event --protocol sqs
awslocal sqs create-queue --queue-name decider-user-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-upserted-event --notification-endpoint http://localhost:4566/000000000000/decider-user-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name delinquency-service-credit-account-charged-off-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-charged-off-event --notification-endpoint http://localhost:4566/000000000000/delinquency-service-credit-account-charged-off-event --protocol sqs
awslocal sqs create-queue --queue-name delinquency-service-credit-account-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-closed-event --notification-endpoint http://localhost:4566/000000000000/delinquency-service-credit-account-closed-event --protocol sqs
awslocal sqs create-queue --queue-name delinquency-service-credit-account-opened-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-opened-event --notification-endpoint http://localhost:4566/000000000000/delinquency-service-credit-account-opened-event --protocol sqs
awslocal sqs create-queue --queue-name delinquency-service-payment-credit-allocated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:ledger-service-payment-credit-allocated-event --notification-endpoint http://localhost:4566/000000000000/delinquency-service-payment-credit-allocated-event --protocol sqs
awslocal sqs create-queue --queue-name delinquency-service-statement-data-processed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-gen-credit-data-processed-event --notification-endpoint http://localhost:4566/000000000000/delinquency-service-statement-data-processed-event --protocol sqs
awslocal sqs create-queue --queue-name delinquency-service-transunion-credit-vision-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:data-transunion-credit-report-updated --notification-endpoint http://localhost:4566/000000000000/delinquency-service-transunion-credit-vision-received-event --protocol sqs
awslocal sqs create-queue --queue-name dispute-service-billing-cycle-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-billing-cycle-upserted-event --notification-endpoint http://localhost:4566/000000000000/dispute-service-billing-cycle-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name dispute-service-dispute-message-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:decider-dispute-message-received-event --notification-endpoint http://localhost:4566/000000000000/dispute-service-dispute-message-received-event --protocol sqs
awslocal sqs create-queue --queue-name dtr-service-adjudication-report-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-adjudication-report-upserted-event --notification-endpoint http://localhost:4566/000000000000/dtr-service-adjudication-report-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name dtr-service-card-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-card-upserted-event --notification-endpoint http://localhost:4566/000000000000/dtr-service-card-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name dtr-service-charged-off-account-interest-calculated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-gen-charged-off-account-interest-calculated-event --notification-endpoint http://localhost:4566/000000000000/dtr-service-charged-off-account-interest-calculated-event --protocol sqs
awslocal sqs create-queue --queue-name dtr-service-credit-account-balance-summary-generated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:ledger-service-credit-account-balance-summary-generated-event --notification-endpoint http://localhost:4566/000000000000/dtr-service-credit-account-balance-summary-generated-event --protocol sqs
awslocal sqs create-queue --queue-name dtr-service-credit-account-transaction-changed-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-transaction-changed-event.fifo --notification-endpoint http://localhost:4566/000000000000/dtr-service-credit-account-transaction-changed-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name dtr-service-credit-account-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-upserted-event --notification-endpoint http://localhost:4566/000000000000/dtr-service-credit-account-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name dtr-service-credit-card-statement-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-gen-credit-card-statement-upserted-event --notification-endpoint http://localhost:4566/000000000000/dtr-service-credit-card-statement-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name dtr-service-credit-facility-account-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-facility-service-credit-facility-account-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/dtr-service-credit-facility-account-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name dtr-service-credit-limit-adjustment-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-limit-adjustment-upserted-event --notification-endpoint http://localhost:4566/000000000000/dtr-service-credit-limit-adjustment-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name dtr-service-delinquency-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:delinquency-service-delinquency-upserted-event --notification-endpoint http://localhost:4566/000000000000/dtr-service-delinquency-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name dtr-service-installment-plan-initialized-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:installments-service-installment-plan-initialized-event --notification-endpoint http://localhost:4566/000000000000/dtr-service-installment-plan-initialized-event --protocol sqs
awslocal sqs create-queue --queue-name dtr-service-series-snapshot-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-delinquency-service-series-snapshot-upserted-event --notification-endpoint http://localhost:4566/000000000000/dtr-service-series-snapshot-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name dtr-service-transunion-credit-vision-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:data-transunion-credit-report-updated --notification-endpoint http://localhost:4566/000000000000/dtr-service-transunion-credit-vision-received-event --protocol sqs
awslocal sqs create-queue --queue-name dtr-service-user-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-upserted-event --notification-endpoint http://localhost:4566/000000000000/dtr-service-user-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name e-transfer-service-savings-account-opened-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-opened-event --notification-endpoint http://localhost:4566/000000000000/e-transfer-service-savings-account-opened-event --protocol sqs
awslocal sqs create-queue --queue-name e-transfer-service-user-upserted-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/e-transfer-service-user-upserted-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name eft-service-external-account-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-external-account-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/eft-service-external-account-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name eft-service-savings-account-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/eft-service-savings-account-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name eft-service-savings-program-arrangement-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-account-service-savings-program-arrangement-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/eft-service-savings-program-arrangement-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name eft-service-savings-program-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-account-service-savings-program-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/eft-service-savings-program-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name external-plan-benefits-service-benefit-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:plans-service-benefit-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/external-plan-benefits-service-benefit-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name external-plan-benefits-service-user-benefit-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:plans-service-user-benefit-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/external-plan-benefits-service-user-benefit-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name external-plan-benefits-service-user-benefits-updated-event-v2 --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:plans-service-user-benefits-updated-event --notification-endpoint http://localhost:4566/000000000000/external-plan-benefits-service-user-benefits-updated-event-v2 --protocol sqs
awslocal sqs create-queue --queue-name external-plan-benefits-service-user-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-upserted-event --notification-endpoint http://localhost:4566/000000000000/external-plan-benefits-service-user-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name i2c-service-card-creation-initialized-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-card-creation-initialized-event --notification-endpoint http://localhost:4566/000000000000/i2c-service-card-creation-initialized-event --protocol sqs
awslocal sqs create-queue --queue-name i2c-service-mastercard-3d-secure --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:smpplesaurus-mastercard-3d-secure --notification-endpoint http://localhost:4566/000000000000/i2c-service-mastercard-3d-secure --protocol sqs
awslocal sqs create-queue --queue-name i2c-service-update-card-attributes-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-update-card-attributes-event --notification-endpoint http://localhost:4566/000000000000/i2c-service-update-card-attributes-event --protocol sqs
awslocal sqs create-queue --queue-name i2c-service-user-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-upserted-event --notification-endpoint http://localhost:4566/000000000000/i2c-service-user-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-adjudication-report-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-adjudication-report-upserted-event --notification-endpoint http://localhost:4566/000000000000/identity-service-adjudication-report-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-application-metadata-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-application-metadata-created-event --notification-endpoint http://localhost:4566/000000000000/identity-service-application-metadata-created-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-approved-credit-application-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-approved-credit-application-completed-event --notification-endpoint http://localhost:4566/000000000000/identity-service-approved-credit-application-completed-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-approved-credit-card-application-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-approved-credit-card-application-completed-event --notification-endpoint http://localhost:4566/000000000000/identity-service-approved-credit-card-application-completed-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-approved-investment-application-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-onboarding-service-approved-investment-application-completed-event --notification-endpoint http://localhost:4566/000000000000/identity-service-approved-investment-application-completed-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-approved-loan-application-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:loan-onboarding-service-approved-loan-application-completed-event --notification-endpoint http://localhost:4566/000000000000/identity-service-approved-loan-application-completed-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-approved-savings-application-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-onboarding-service-approved-savings-application-completed-event --notification-endpoint http://localhost:4566/000000000000/identity-service-approved-savings-application-completed-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-secondary-checks-information-retrieved-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-secondary-checks-information-retrieved-event --notification-endpoint http://localhost:4566/000000000000/identity-service-secondary-checks-information-retrieved-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-berbix-id-verification-report-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-berbix-id-verification-report-upserted-event --notification-endpoint http://localhost:4566/000000000000/identity-service-berbix-id-verification-report-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-berbix-metadata-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-berbix-metadata-updated-event --notification-endpoint http://localhost:4566/000000000000/identity-service-berbix-metadata-updated-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-comply-advantage-report-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-comply-advantage-report-upserted-event --notification-endpoint http://localhost:4566/000000000000/identity-service-comply-advantage-report-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-credit-application-decision-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-credit-application-decision-updated-event --notification-endpoint http://localhost:4566/000000000000/identity-service-credit-application-decision-updated-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-enstream-account-integrity-report-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-enstream-account-integrity-report-upserted-event --notification-endpoint http://localhost:4566/000000000000/identity-service-enstream-account-integrity-report-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-enstream-report-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-enstream-report-upserted-event --notification-endpoint http://localhost:4566/000000000000/identity-service-enstream-report-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-fpjs-visitor-identified-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:webhook-fingerprintjs-visitor-identified-event --notification-endpoint http://localhost:4566/000000000000/identity-service-fpjs-visitor-identified-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-hbc-point-of-sale-identification-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-hbc-point-of-sale-indentification-upserted-event --notification-endpoint http://localhost:4566/000000000000/identity-service-hbc-point-of-sale-identification-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-investment-account-completion-synced-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-investment-account-completion-synced-event --notification-endpoint http://localhost:4566/000000000000/identity-service-investment-account-completion-synced-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-investment-application-decision-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-onboarding-service-investment-application-decision-updated-event --notification-endpoint http://localhost:4566/000000000000/identity-service-investment-application-decision-updated-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-iovation-digital-fraud-report-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-iovation-digital-fraud-report-upserted-event --notification-endpoint http://localhost:4566/000000000000/identity-service-iovation-digital-fraud-report-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-manual-id-verification-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-manual-id-verification-completed-event --notification-endpoint http://localhost:4566/000000000000/identity-service-manual-id-verification-completed-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-neo-in-store-manual-identification-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-neo-in-store-manual-identification-upserted-event --notification-endpoint http://localhost:4566/000000000000/identity-service-neo-in-store-manual-identification-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-prequalification-claimed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:prequalification-service-prequalification-claimed-event --notification-endpoint http://localhost:4566/000000000000/identity-service-prequalification-claimed-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-prequalification-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:prequalification-service-prequalification-upserted-event --notification-endpoint http://localhost:4566/000000000000/identity-service-prequalification-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-savings-application-decision-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-onboarding-service-savings-application-decision-updated-event --notification-endpoint http://localhost:4566/000000000000/identity-service-savings-application-decision-updated-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-transunion-credit-vision-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:data-transunion-credit-report-updated --notification-endpoint http://localhost:4566/000000000000/identity-service-transunion-credit-vision-received-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-transunion-hard-credit-report-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-transunion-hard-credit-report-upserted-event --notification-endpoint http://localhost:4566/000000000000/identity-service-transunion-hard-credit-report-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-transunion-kyc-report-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-transunion-kyc-report-upserted-event --notification-endpoint http://localhost:4566/000000000000/identity-service-transunion-kyc-report-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-transunion-personal-fraud-report-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-transunion-personal-fraud-report-upserted-event --notification-endpoint http://localhost:4566/000000000000/identity-service-transunion-personal-fraud-report-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-transunion-soft-credit-check-report-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-transunion-soft-credit-check-report-upserted-event --notification-endpoint http://localhost:4566/000000000000/identity-service-transunion-soft-credit-check-report-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name identity-service-user-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-upserted-event --notification-endpoint http://localhost:4566/000000000000/identity-service-user-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name installments-service-user-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/installments-service-user-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name installments-service-card-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-card-upserted-event --notification-endpoint http://localhost:4566/000000000000/installments-service-card-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name installments-service-credit-account-transaction-changed-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-transaction-changed-event.fifo --notification-endpoint http://localhost:4566/000000000000/installments-service-credit-account-transaction-changed-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name installments-service-credit-account-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-upserted-event --notification-endpoint http://localhost:4566/000000000000/installments-service-credit-account-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name installments-service-credit-information-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-credit-information-updated-event --notification-endpoint http://localhost:4566/000000000000/installments-service-credit-information-updated-event --protocol sqs
awslocal sqs create-queue --queue-name installments-service-fingerprint-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-fingerprint-upserted-event --notification-endpoint http://localhost:4566/000000000000/installments-service-fingerprint-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name installments-service-installment-plan-balance-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:term-loan-service-installment-plan-balance-updated-event --notification-endpoint http://localhost:4566/000000000000/installments-service-installment-plan-balance-updated-event --protocol sqs
awslocal sqs create-queue --queue-name installments-service-installment-plan-repayment-method-invalidated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:term-loan-service-installment-plan-repayment-method-invalidated-event --notification-endpoint http://localhost:4566/000000000000/installments-service-installment-plan-repayment-method-invalidated-event --protocol sqs
awslocal sqs create-queue --queue-name installments-service-term-loan-charged-off-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:term-loan-service-term-loan-charged-off-event --notification-endpoint http://localhost:4566/000000000000/installments-service-term-loan-charged-off-event --protocol sqs
awslocal sqs create-queue --queue-name installments-service-term-loan-payment-successful-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:term-loan-service-term-loan-payment-successful-event --notification-endpoint http://localhost:4566/000000000000/installments-service-term-loan-payment-successful-event --protocol sqs
awslocal sqs create-queue --queue-name installments-service-term-loan-transfer-failed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:term-loan-service-term-loan-transfer-failed-event --notification-endpoint http://localhost:4566/000000000000/installments-service-term-loan-transfer-failed-event --protocol sqs
awslocal sqs create-queue --queue-name installments-service-transunion-creditvision-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:data-transunion-credit-report-updated --notification-endpoint http://localhost:4566/000000000000/installments-service-transunion-creditvision-received-event --protocol sqs
awslocal sqs create-queue --queue-name instant-tax-refund-service-approved-loan-application-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:loan-onboarding-service-approved-loan-application-completed-event --notification-endpoint http://localhost:4566/000000000000/instant-tax-refund-service-approved-loan-application-completed-event --protocol sqs
awslocal sqs create-queue --queue-name instant-tax-refund-service-inbound-eft-credit-txn-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-incoming-aft-credit-txn-created-event --notification-endpoint http://localhost:4566/000000000000/instant-tax-refund-service-inbound-eft-credit-txn-created-event --protocol sqs
awslocal sqs create-queue --queue-name instant-tax-refund-service-instant-tax-refund-balance-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:term-loan-service-instant-tax-refund-balance-updated-event --notification-endpoint http://localhost:4566/000000000000/instant-tax-refund-service-instant-tax-refund-balance-updated-event --protocol sqs
awslocal sqs create-queue --queue-name instant-tax-refund-service-itr-repayment-method-invalidated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:term-loan-service-itr-repayment-method-invalidated-event --notification-endpoint http://localhost:4566/000000000000/instant-tax-refund-service-itr-repayment-method-invalidated-event --protocol sqs
awslocal sqs create-queue --queue-name instant-tax-refund-service-loan-link-account-block-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:loan-onboarding-service-loan-link-account-block-completed-event --notification-endpoint http://localhost:4566/000000000000/instant-tax-refund-service-loan-link-account-block-completed-event --protocol sqs
awslocal sqs create-queue --queue-name instant-tax-refund-service-prequalification-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:prequalification-service-prequalification-completed-event --notification-endpoint http://localhost:4566/000000000000/instant-tax-refund-service-prequalification-completed-event --protocol sqs
awslocal sqs create-queue --queue-name instant-tax-refund-service-prequalification-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:prequalification-service-prequalification-created-event --notification-endpoint http://localhost:4566/000000000000/instant-tax-refund-service-prequalification-created-event --protocol sqs
awslocal sqs create-queue --queue-name instant-tax-refund-service-savings-account-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-created-event --notification-endpoint http://localhost:4566/000000000000/instant-tax-refund-service-savings-account-created-event --protocol sqs
awslocal sqs create-queue --queue-name instant-tax-refund-service-savings-account-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-updated-event --notification-endpoint http://localhost:4566/000000000000/instant-tax-refund-service-savings-account-updated-event --protocol sqs
awslocal sqs create-queue --queue-name instant-tax-refund-service-term-loan-charged-off-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:term-loan-service-term-loan-charged-off-event --notification-endpoint http://localhost:4566/000000000000/instant-tax-refund-service-term-loan-charged-off-event --protocol sqs
awslocal sqs create-queue --queue-name instant-tax-refund-service-term-loan-nsf-charged-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:term-loan-service-term-loan-nsf-charged-event --notification-endpoint http://localhost:4566/000000000000/instant-tax-refund-service-term-loan-nsf-charged-event --protocol sqs
awslocal sqs create-queue --queue-name instant-tax-refund-service-term-loan-payment-successful-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:term-loan-service-term-loan-payment-successful-event --notification-endpoint http://localhost:4566/000000000000/instant-tax-refund-service-term-loan-payment-successful-event --protocol sqs
awslocal sqs create-queue --queue-name instant-tax-refund-service-term-loan-transfer-failed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:term-loan-service-term-loan-transfer-failed-event --notification-endpoint http://localhost:4566/000000000000/instant-tax-refund-service-term-loan-transfer-failed-event --protocol sqs
awslocal sqs create-queue --queue-name instant-tax-refund-service-user-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/instant-tax-refund-service-user-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-address-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-address-module-updated-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-address-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-annual-income-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-annual-income-module-updated-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-annual-income-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-annual-reassessment-synced-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-service-annual-reassessment-synced-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-annual-reassessment-synced-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-application-flagged-for-review-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-service-application-flagged-for-review-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-application-flagged-for-review-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-application-metadata-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-application-metadata-created-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-application-metadata-created-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-berbix-retry-triggered-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-berbix-retry-triggered-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-berbix-retry-triggered-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-berbix-transaction-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-berbix-transaction-created-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-berbix-transaction-created-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-block-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-block-completed-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-block-completed-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-citizenship-module-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-citizenship-module-upserted-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-citizenship-module-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-contact-information-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-contact-information-module-updated-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-contact-information-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-date-of-birth-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-date-of-birth-module-updated-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-date-of-birth-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-employment-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-employment-module-updated-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-employment-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-foreign-tax-information-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-foreign-tax-information-module-updated-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-foreign-tax-information-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-housing-info-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-housing-info-module-updated-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-housing-info-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-id-verification-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-id-verification-completed-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-id-verification-completed-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-id-verification-synced-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-id-verification-synced-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-id-verification-synced-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-id-verification-unsynced-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-id-verification-unsynced-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-id-verification-unsynced-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-investment-agreement-previews-synced-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-service-investment-agreement-previews-synced-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-investment-agreement-previews-synced-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-investment-application-reviewed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-service-investment-application-reviewed-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-investment-application-reviewed-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-investment-portfolio-changes-synced-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-service-investment-portfolio-changes-synced-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-investment-portfolio-changes-synced-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-investment-product-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-investment-product-updated-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-investment-product-updated-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-marital-information-module-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-marital-information-module-upserted-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-marital-information-module-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-monthly-debt-module-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-monthly-debt-module-upserted-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-monthly-debt-module-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-name-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-name-module-updated-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-name-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-primary-checks-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-primary-checks-completed-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-primary-checks-completed-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-primary-checks-retry-succeeded-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-primary-checks-retry-succeeded-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-primary-checks-retry-succeeded-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-property-and-assets-module-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-property-and-assets-module-upserted-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-property-and-assets-module-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-questionnaire-reset-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-service-questionnaire-reset-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-questionnaire-reset-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-sin-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-sin-module-updated-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-sin-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-total-debt-module-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-total-debt-module-upserted-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-total-debt-module-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name investment-onboarding-service-total-savings-module-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-total-savings-module-upserted-event --notification-endpoint http://localhost:4566/000000000000/investment-onboarding-service-total-savings-module-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name investment-service-berbix-id-verification-report-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-berbix-report-upserted-event --notification-endpoint http://localhost:4566/000000000000/investment-service-berbix-id-verification-report-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name investment-service-external-account-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-external-account-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/investment-service-external-account-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name investment-service-external-account-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-external-account-upserted-event --notification-endpoint http://localhost:4566/000000000000/investment-service-external-account-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name investment-service-hbc-point-of-sale-indentification-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-hbc-point-of-sale-indentification-upserted-event --notification-endpoint http://localhost:4566/000000000000/investment-service-hbc-point-of-sale-indentification-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name investment-service-investment-account-completion-data-populated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-investment-account-completion-data-populated-event --notification-endpoint http://localhost:4566/000000000000/investment-service-investment-account-completion-data-populated-event --protocol sqs
awslocal sqs create-queue --queue-name investment-service-investment-agreements-data-populated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-investment-agreements-data-populated-event --notification-endpoint http://localhost:4566/000000000000/investment-service-investment-agreements-data-populated-event --protocol sqs
awslocal sqs create-queue --queue-name investment-service-investment-annual-reassessment-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-onboarding-service-annual-reassessment-completed-event --notification-endpoint http://localhost:4566/000000000000/investment-service-investment-annual-reassessment-completed-event --protocol sqs
awslocal sqs create-queue --queue-name investment-service-investment-annual-reassessment-data-populated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-investment-annual-reassessment-data-populated-event --notification-endpoint http://localhost:4566/000000000000/investment-service-investment-annual-reassessment-data-populated-event --protocol sqs
awslocal sqs create-queue --queue-name investment-service-investment-portfolio-data-populated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-investment-portfolio-data-populated-event --notification-endpoint http://localhost:4566/000000000000/investment-service-investment-portfolio-data-populated-event --protocol sqs
awslocal sqs create-queue --queue-name investment-service-investment-product-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-investment-product-updated-event --notification-endpoint http://localhost:4566/000000000000/investment-service-investment-product-updated-event --protocol sqs
awslocal sqs create-queue --queue-name investment-service-investment-questionnaire-block-started-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-investment-questionnaire-block-started-event --notification-endpoint http://localhost:4566/000000000000/investment-service-investment-questionnaire-block-started-event --protocol sqs
awslocal sqs create-queue --queue-name investment-service-neo-in-store-manual-identification-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-neo-in-store-manual-identification-upserted-event --notification-endpoint http://localhost:4566/000000000000/investment-service-neo-in-store-manual-identification-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name investment-service-one-vest-account-status-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:webhook-one-vest-account-status-updated-event --notification-endpoint http://localhost:4566/000000000000/investment-service-one-vest-account-status-updated-event --protocol sqs
awslocal sqs create-queue --queue-name investment-service-one-vest-transfer-status-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:webhook-one-vest-transfer-status-updated-event --notification-endpoint http://localhost:4566/000000000000/investment-service-one-vest-transfer-status-updated-event --protocol sqs
awslocal sqs create-queue --queue-name investment-service-one-vest-user-status-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:webhook-one-vest-user-status-updated-event --notification-endpoint http://localhost:4566/000000000000/investment-service-one-vest-user-status-updated-event --protocol sqs
awslocal sqs create-queue --queue-name investment-service-one-vest-user-suitability-review-due-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:webhook-one-vest-user-suitability-review-due-updated-event --notification-endpoint http://localhost:4566/000000000000/investment-service-one-vest-user-suitability-review-due-updated-event --protocol sqs
awslocal sqs create-queue --queue-name investment-service-savings-account-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-closed-event --notification-endpoint http://localhost:4566/000000000000/investment-service-savings-account-closed-event --protocol sqs
awslocal sqs create-queue --queue-name investment-service-savings-account-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-created-event --notification-endpoint http://localhost:4566/000000000000/investment-service-savings-account-created-event --protocol sqs
awslocal sqs create-queue --queue-name investment-service-savings-account-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/investment-service-savings-account-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name investment-service-savings-account-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-updated-event --notification-endpoint http://localhost:4566/000000000000/investment-service-savings-account-updated-event --protocol sqs
awslocal sqs create-queue --queue-name investment-service-user-annual-income-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-annual-income-upserted-event --notification-endpoint http://localhost:4566/000000000000/investment-service-user-annual-income-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name investment-service-user-tax-information-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-tax-information-upserted-event --notification-endpoint http://localhost:4566/000000000000/investment-service-user-tax-information-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name investment-service-user-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-upserted-event --notification-endpoint http://localhost:4566/000000000000/investment-service-user-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name iso-vault-iso-message-reference-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:mcd-decider-iso-message-reference-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/iso-vault-iso-message-reference-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name ledger-service-dispute-exchange-rate-variance-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:dispute-service-dispute-exchange-rate-variance-event --notification-endpoint http://localhost:4566/000000000000/ledger-service-dispute-exchange-rate-variance-event --protocol sqs
awslocal sqs create-queue --queue-name ledger-service-exchange-rate-discrepancy-identified-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:decider-exchange-rate-discrepancy-identified-event --notification-endpoint http://localhost:4566/000000000000/ledger-service-exchange-rate-discrepancy-identified-event --protocol sqs
awslocal sqs create-queue --queue-name ledger-service-outgoing-bill-payment-reversed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-outgoing-bill-payment-reversed-event --notification-endpoint http://localhost:4566/000000000000/ledger-service-outgoing-bill-payment-reversed-event --protocol sqs
awslocal sqs create-queue --queue-name ledger-service-user-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-upserted-event --notification-endpoint http://localhost:4566/000000000000/ledger-service-user-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name loan-credit-facility-service-balance-summary-generated-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:core-ledger-service-loan-credit-facility-balance-summary-generated-event.fifo --notification-endpoint http://localhost:4566/000000000000/loan-credit-facility-service-balance-summary-generated-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name loan-credit-facility-service-instant-tax-refund-initialized-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:instant-tax-refund-service-instant-tax-refund-initialized-event --notification-endpoint http://localhost:4566/000000000000/loan-credit-facility-service-instant-tax-refund-initialized-event --protocol sqs
awslocal sqs create-queue --queue-name loan-credit-facility-service-term-loan-payment-successful-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:term-loan-service-term-loan-payment-successful-event --notification-endpoint http://localhost:4566/000000000000/loan-credit-facility-service-term-loan-payment-successful-event --protocol sqs
awslocal sqs create-queue --queue-name loan-credit-facility-service-user-reports-metadata-snapshot-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-user-reports-metadata-snapshot-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/loan-credit-facility-service-user-reports-metadata-snapshot-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name loan-onboarding-service-address-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-address-module-updated-event --notification-endpoint http://localhost:4566/000000000000/loan-onboarding-service-address-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name loan-onboarding-service-application-metadata-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-application-metadata-created-event --notification-endpoint http://localhost:4566/000000000000/loan-onboarding-service-application-metadata-created-event --protocol sqs
awslocal sqs create-queue --queue-name loan-onboarding-service-approved-savings-application-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-onboarding-service-approved-savings-application-completed-event --notification-endpoint http://localhost:4566/000000000000/loan-onboarding-service-approved-savings-application-completed-event --protocol sqs
awslocal sqs create-queue --queue-name loan-onboarding-service-berbix-retry-triggered-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-berbix-retry-triggered-event --notification-endpoint http://localhost:4566/000000000000/loan-onboarding-service-berbix-retry-triggered-event --protocol sqs
awslocal sqs create-queue --queue-name loan-onboarding-service-berbix-transaction-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-berbix-transaction-created-event --notification-endpoint http://localhost:4566/000000000000/loan-onboarding-service-berbix-transaction-created-event --protocol sqs
awslocal sqs create-queue --queue-name loan-onboarding-service-block-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-block-completed-event --notification-endpoint http://localhost:4566/000000000000/loan-onboarding-service-block-completed-event --protocol sqs
awslocal sqs create-queue --queue-name loan-onboarding-service-date-of-birth-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-date-of-birth-module-updated-event --notification-endpoint http://localhost:4566/000000000000/loan-onboarding-service-date-of-birth-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name loan-onboarding-service-employer-information-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-employer-information-module-updated-event --notification-endpoint http://localhost:4566/000000000000/loan-onboarding-service-employer-information-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name loan-onboarding-service-employment-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-employment-module-updated-event --notification-endpoint http://localhost:4566/000000000000/loan-onboarding-service-employment-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name loan-onboarding-service-id-verification-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-id-verification-completed-event --notification-endpoint http://localhost:4566/000000000000/loan-onboarding-service-id-verification-completed-event --protocol sqs
awslocal sqs create-queue --queue-name loan-onboarding-service-id-verification-synced-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-id-verification-synced-event --notification-endpoint http://localhost:4566/000000000000/loan-onboarding-service-id-verification-synced-event --protocol sqs
awslocal sqs create-queue --queue-name loan-onboarding-service-id-verification-unsynced-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-id-verification-unsynced-event --notification-endpoint http://localhost:4566/000000000000/loan-onboarding-service-id-verification-unsynced-event --protocol sqs
awslocal sqs create-queue --queue-name loan-onboarding-service-name-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-name-module-updated-event --notification-endpoint http://localhost:4566/000000000000/loan-onboarding-service-name-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name loan-onboarding-service-prequalification-claimed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:prequalification-service-prequalification-claimed-event --notification-endpoint http://localhost:4566/000000000000/loan-onboarding-service-prequalification-claimed-event --protocol sqs
awslocal sqs create-queue --queue-name loan-onboarding-service-primary-checks-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-primary-checks-completed-event --notification-endpoint http://localhost:4566/000000000000/loan-onboarding-service-primary-checks-completed-event --protocol sqs
awslocal sqs create-queue --queue-name loan-onboarding-service-primary-checks-retry-succeeded-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-primary-checks-retry-succeeded-event --notification-endpoint http://localhost:4566/000000000000/loan-onboarding-service-primary-checks-retry-succeeded-event --protocol sqs
awslocal sqs create-queue --queue-name loan-onboarding-service-savings-account-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/loan-onboarding-service-savings-account-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name loyalty-service-credit-account-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-closed-event --notification-endpoint http://localhost:4566/000000000000/loyalty-service-credit-account-closed-event --protocol sqs
awslocal sqs create-queue --queue-name loyalty-service-credit-application-abandoned-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-credit-application-abandoned-event --notification-endpoint http://localhost:4566/000000000000/loyalty-service-credit-application-abandoned-event --protocol sqs
awslocal sqs create-queue --queue-name loyalty-service-hbc-card-payment-prepared-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-hbc-card-payment-prepared-event --notification-endpoint http://localhost:4566/000000000000/loyalty-service-hbc-card-payment-prepared-event --protocol sqs
awslocal sqs create-queue --queue-name loyalty-service-hbc-card-reissued-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-service-unlink-hbc-subscription-event --notification-endpoint http://localhost:4566/000000000000/loyalty-service-hbc-card-reissued-event --protocol sqs
awslocal sqs create-queue --queue-name loyalty-service-hbc-credit-application-abandoned-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-hbc-credit-application-abandoned-event --notification-endpoint http://localhost:4566/000000000000/loyalty-service-hbc-credit-application-abandoned-event --protocol sqs
awslocal sqs create-queue --queue-name loyalty-service-hbc-credit-application-declined-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-hbc-credit-application-declined-event --notification-endpoint http://localhost:4566/000000000000/loyalty-service-hbc-credit-application-declined-event --protocol sqs
awslocal sqs create-queue --queue-name loyalty-service-hbc-credit-application-relinked-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-hbc-credit-application-relinked-event --notification-endpoint http://localhost:4566/000000000000/loyalty-service-hbc-credit-application-relinked-event --protocol sqs
awslocal sqs create-queue --queue-name mcd-decider-billing-cycle-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-billing-cycle-upserted-event --notification-endpoint http://localhost:4566/000000000000/mcd-decider-billing-cycle-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name mcd-decider-card-program-template-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-service-card-program-template-upserted-event --notification-endpoint http://localhost:4566/000000000000/mcd-decider-card-program-template-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name mcd-decider-card-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-card-upserted-event --notification-endpoint http://localhost:4566/000000000000/mcd-decider-card-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name mcd-decider-credit-account-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-upserted-event --notification-endpoint http://localhost:4566/000000000000/mcd-decider-credit-account-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name mcd-decider-delinquency-block-updated-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-delinquency-service-delinquency-block-updated-event.fifo --notification-endpoint http://localhost:4566/000000000000/mcd-decider-delinquency-block-updated-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name mcd-decider-mcd-card-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-vault-mcd-card-upserted-event --notification-endpoint http://localhost:4566/000000000000/mcd-decider-mcd-card-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name mcd-decider-merchant-fingerprint-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:merchant-fingerprint-service-fingerprint-upserted-event --notification-endpoint http://localhost:4566/000000000000/mcd-decider-merchant-fingerprint-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name mcd-decider-payment-token-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payment-token-service-payment-token-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/mcd-decider-payment-token-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name mcd-decider-pin-block-generated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-vault-pin-block-generated-event --notification-endpoint http://localhost:4566/000000000000/mcd-decider-pin-block-generated-event --protocol sqs
awslocal sqs create-queue --queue-name mcd-decider-savings-account-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-created-event --notification-endpoint http://localhost:4566/000000000000/mcd-decider-savings-account-created-event --protocol sqs
awslocal sqs create-queue --queue-name mcd-decider-savings-account-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-updated-event --notification-endpoint http://localhost:4566/000000000000/mcd-decider-savings-account-updated-event --protocol sqs
awslocal sqs create-queue --queue-name mcd-decider-token-provisioning-card-block-attempted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payment-token-service-token-provisioning-card-block-attempted-event --notification-endpoint http://localhost:4566/000000000000/mcd-decider-token-provisioning-card-block-attempted-event --protocol sqs
awslocal sqs create-queue --queue-name mcd-decider-transaction-manually-reversed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-transaction-manually-reversed-event --notification-endpoint http://localhost:4566/000000000000/mcd-decider-transaction-manually-reversed-event --protocol sqs
awslocal sqs create-queue --queue-name mcd-decider-user-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/mcd-decider-user-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name merchant-analytics-service-redemption-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:redemption-service-redemption-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/merchant-analytics-service-redemption-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name merchant-analytics-service-rewards-transaction-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-transaction-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/merchant-analytics-service-rewards-transaction-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name merchant-analytics-service-user-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/merchant-analytics-service-user-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name merchant-billing-service-applied-bounty-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:referral-service-applied-bounty-upserted-event --notification-endpoint http://localhost:4566/000000000000/merchant-billing-service-applied-bounty-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name merchant-billing-location-funding-account-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-location-funding-account-updated-event --notification-endpoint http://localhost:4566/000000000000/merchant-billing-location-funding-account-updated-event --protocol sqs
awslocal sqs create-queue --queue-name merchant-billing-reward-redeemed-to-account-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:redemption-service-reward-redeemed-to-account-event.fifo --notification-endpoint http://localhost:4566/000000000000/merchant-billing-reward-redeemed-to-account-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name merchant-billing-balance-summary-generated-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:core-ledger-service-rewards-merchant-balance-summary-generated-event.fifo --notification-endpoint http://localhost:4566/000000000000/merchant-billing-balance-summary-generated-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name merchant-billing-service-incoming-merchant-pad-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:atb-pre-authorized-debit-download-job-incoming-merchant-pad-event --notification-endpoint http://localhost:4566/000000000000/merchant-billing-service-incoming-merchant-pad-event --protocol sqs
awslocal sqs create-queue --queue-name merchant-fingerprint-service-decider-fingerprint-upsert-failed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:decider-fingerprint-upsert-failed-event --notification-endpoint http://localhost:4566/000000000000/merchant-fingerprint-service-decider-fingerprint-upsert-failed-event --protocol sqs
awslocal sqs create-queue --queue-name merchant-fingerprint-service-fingerprint-manually-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-fingerprint-manually-created-event --notification-endpoint http://localhost:4566/000000000000/merchant-fingerprint-service-fingerprint-manually-created-event --protocol sqs
awslocal sqs create-queue --queue-name merchant-fingerprint-service-fingerprint-upsert-failed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:mcd-decider-fingerprint-upsert-failed-event --notification-endpoint http://localhost:4566/000000000000/merchant-fingerprint-service-fingerprint-upsert-failed-event --protocol sqs
awslocal sqs create-queue --queue-name mortgage-onboarding-service-address-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-address-module-updated-event --notification-endpoint http://localhost:4566/000000000000/mortgage-onboarding-service-address-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name mortgage-onboarding-service-asset-information-module-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-asset-information-module-upserted-event --notification-endpoint http://localhost:4566/000000000000/mortgage-onboarding-service-asset-information-module-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name mortgage-onboarding-service-block-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-block-completed-event --notification-endpoint http://localhost:4566/000000000000/mortgage-onboarding-service-block-completed-event --protocol sqs
awslocal sqs create-queue --queue-name mortgage-onboarding-service-cashflow-information-module-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-cashflow-information-module-upserted-event --notification-endpoint http://localhost:4566/000000000000/mortgage-onboarding-service-cashflow-information-module-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name mortgage-onboarding-service-date-of-birth-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-date-of-birth-module-updated-event --notification-endpoint http://localhost:4566/000000000000/mortgage-onboarding-service-date-of-birth-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name mortgage-onboarding-service-employment-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-employment-module-updated-event --notification-endpoint http://localhost:4566/000000000000/mortgage-onboarding-service-employment-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name mortgage-onboarding-service-marital-information-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-marital-information-module-upserted-event --notification-endpoint http://localhost:4566/000000000000/mortgage-onboarding-service-marital-information-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name mortgage-onboarding-service-name-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-name-module-updated-event --notification-endpoint http://localhost:4566/000000000000/mortgage-onboarding-service-name-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name mortgage-service-applied-bounty-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:referral-service-applied-bounty-upserted-event --notification-endpoint http://localhost:4566/000000000000/mortgage-service-applied-bounty-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name mortgage-service-mortgage-application-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:webhook-salesforce-mortgage-application-received-event --notification-endpoint http://localhost:4566/000000000000/mortgage-service-mortgage-application-received-event --protocol sqs
awslocal sqs create-queue --queue-name mortgage-service-transunion-credit-vision-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:data-transunion-credit-report-updated --notification-endpoint http://localhost:4566/000000000000/mortgage-service-transunion-credit-vision-received-event --protocol sqs
awslocal sqs create-queue --queue-name mortgage-service-transunion-soft-credit-check-report-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-transunion-soft-credit-check-report-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/mortgage-service-transunion-soft-credit-check-report-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name mortgage-service-user-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/mortgage-service-user-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name neo-mart-applied-bonus-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:referral-service-applied-bonus-upserted-event --notification-endpoint http://localhost:4566/000000000000/neo-mart-applied-bonus-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name neo-mart-applied-bounty-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:referral-service-applied-bounty-upserted-event --notification-endpoint http://localhost:4566/000000000000/neo-mart-applied-bounty-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name neo-mart-benefit-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:plans-service-benefit-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/neo-mart-benefit-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name neo-mart-brand-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-brand-updated-event --notification-endpoint http://localhost:4566/000000000000/neo-mart-brand-updated-event --protocol sqs
awslocal sqs create-queue --queue-name neo-mart-card-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-card-upserted-event --notification-endpoint http://localhost:4566/000000000000/neo-mart-card-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name neo-mart-credit-account-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-closed-event --notification-endpoint http://localhost:4566/000000000000/neo-mart-credit-account-closed-event --protocol sqs
awslocal sqs create-queue --queue-name neo-mart-credit-account-transaction-changed-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-transaction-changed-event.fifo --notification-endpoint http://localhost:4566/000000000000/neo-mart-credit-account-transaction-changed-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name neo-mart-non-partner-transaction-processed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-non-partner-transaction-processed-event --notification-endpoint http://localhost:4566/000000000000/neo-mart-non-partner-transaction-processed-event --protocol sqs
awslocal sqs create-queue --queue-name neo-mart-order-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-store-service-order-created-event --notification-endpoint http://localhost:4566/000000000000/neo-mart-order-created-event --protocol sqs
awslocal sqs create-queue --queue-name neo-mart-reward-redeemed-to-account-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:redemption-service-reward-redeemed-to-account-event.fifo --notification-endpoint http://localhost:4566/000000000000/neo-mart-reward-redeemed-to-account-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name neo-mart-rewards-cash-out-to-credit-failed-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-rewards-cash-out-to-credit-failed-event.fifo --notification-endpoint http://localhost:4566/000000000000/neo-mart-rewards-cash-out-to-credit-failed-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name neo-mart-rewards-cash-out-to-credit-succeeded-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-rewards-cash-out-to-credit-succeeded-event.fifo --notification-endpoint http://localhost:4566/000000000000/neo-mart-rewards-cash-out-to-credit-succeeded-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name neo-mart-rewards-cash-out-to-savings-failed-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-rewards-cash-out-to-savings-failed-event.fifo --notification-endpoint http://localhost:4566/000000000000/neo-mart-rewards-cash-out-to-savings-failed-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name neo-mart-rewards-cash-out-to-savings-succeeded-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-rewards-cash-out-to-savings-succeeded-event.fifo --notification-endpoint http://localhost:4566/000000000000/neo-mart-rewards-cash-out-to-savings-succeeded-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name neo-mart-savings-account-transaction-changed-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-transaction-changed-event.fifo --notification-endpoint http://localhost:4566/000000000000/neo-mart-savings-account-transaction-changed-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name neo-mart-spend-summary-generated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:spend-analytics-service-spend-summary-generated-event --notification-endpoint http://localhost:4566/000000000000/neo-mart-spend-summary-generated-event --protocol sqs
awslocal sqs create-queue --queue-name neo-mart-transaction-processed-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:decider-transaction-processed-event.fifo --notification-endpoint http://localhost:4566/000000000000/neo-mart-transaction-processed-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name neo-mart-user-benefit-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:plans-service-user-benefit-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/neo-mart-user-benefit-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name neo-mart-user-benefits-updated-event-v2 --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:plans-service-user-benefits-updated-event --notification-endpoint http://localhost:4566/000000000000/neo-mart-user-benefits-updated-event-v2 --protocol sqs
awslocal sqs create-queue --queue-name neo-mart-user-rewards-data-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-user-rewards-data-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/neo-mart-user-rewards-data-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name neo-mart-user-rewards-scheme-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-user-rewards-scheme-updated-event --notification-endpoint http://localhost:4566/000000000000/neo-mart-user-rewards-scheme-updated-event --protocol sqs
awslocal sqs create-queue --queue-name neo-mart-user-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-upserted-event --notification-endpoint http://localhost:4566/000000000000/neo-mart-user-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name notification-feed-service-applied-bonus-expiring-soon-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:referral-service-applied-bonus-expiring-soon-event --notification-endpoint http://localhost:4566/000000000000/notification-feed-service-applied-bonus-expiring-soon-event --protocol sqs
awslocal sqs create-queue --queue-name notification-feed-service-applied-bonus-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:referral-service-applied-bonus-upserted-event --notification-endpoint http://localhost:4566/000000000000/notification-feed-service-applied-bonus-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name notification-feed-service-basket-bump-spend-amount-condition-not-met-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:redemption-service-basket-bump-spend-amount-condition-not-met-event --notification-endpoint http://localhost:4566/000000000000/notification-feed-service-basket-bump-spend-amount-condition-not-met-event --protocol sqs
awslocal sqs create-queue --queue-name notification-feed-service-brand-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-brand-updated-event --notification-endpoint http://localhost:4566/000000000000/notification-feed-service-brand-updated-event --protocol sqs
awslocal sqs create-queue --queue-name notification-feed-service-credit-account-auto-payment-disabled-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:auto-transfer-service-credit-account-auto-payment-disabled-event --notification-endpoint http://localhost:4566/000000000000/notification-feed-service-credit-account-auto-payment-disabled-event --protocol sqs
awslocal sqs create-queue --queue-name notification-feed-service-credit-account-auto-payment-failed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-credit-account-auto-payment-failed-event --notification-endpoint http://localhost:4566/000000000000/notification-feed-service-credit-account-auto-payment-failed-event --protocol sqs
awslocal sqs create-queue --queue-name notification-feed-service-credit-auto-payment-fallback-successful-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:auto-transfer-service-credit-auto-payment-fallback-successful-event --notification-endpoint http://localhost:4566/000000000000/notification-feed-service-credit-auto-payment-fallback-successful-event --protocol sqs
awslocal sqs create-queue --queue-name notification-feed-service-external-to-savings-transfer-overlimit-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-external-to-savings-transfer-overlimit-event --notification-endpoint http://localhost:4566/000000000000/notification-feed-service-external-to-savings-transfer-overlimit-event --protocol sqs
awslocal sqs create-queue --queue-name notification-feed-service-in-app-message-sent-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:webhook-iterable-feed-in-app-message-sent-event --notification-endpoint http://localhost:4566/000000000000/notification-feed-service-in-app-message-sent-event --protocol sqs
awslocal sqs create-queue --queue-name notification-feed-service-in-progress-offer-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:redemption-service-in-progress-offer-event --notification-endpoint http://localhost:4566/000000000000/notification-feed-service-in-progress-offer-event --protocol sqs
awslocal sqs create-queue --queue-name notification-feed-service-installment-plan-payment-successful-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:installments-service-installment-plan-payment-successful-event --notification-endpoint http://localhost:4566/000000000000/notification-feed-service-installment-plan-payment-successful-event --protocol sqs
awslocal sqs create-queue --queue-name notification-feed-service-top-up-processing-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:neo-mart-top-up-processing-completed-event --notification-endpoint http://localhost:4566/000000000000/notification-feed-service-top-up-processing-completed-event --protocol sqs
awslocal sqs create-queue --queue-name notification-feed-service-user-eligible-for-winback-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-user-eligible-for-winback-event --notification-endpoint http://localhost:4566/000000000000/notification-feed-service-user-eligible-for-winback-event --protocol sqs
awslocal sqs create-queue --queue-name notification-feed-service-user-notification-preferences-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:sendy-service-user-notification-preferences-upserted-event --notification-endpoint http://localhost:4566/000000000000/notification-feed-service-user-notification-preferences-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name notification-feed-service-user-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-upserted-event --notification-endpoint http://localhost:4566/000000000000/notification-feed-service-user-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name notification-feed-service-valid-offer-expiring-soon-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-valid-offer-expiring-soon-event --notification-endpoint http://localhost:4566/000000000000/notification-feed-service-valid-offer-expiring-soon-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-credit-account-balance-evaluated --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-service-credit-account-balance-evaluated --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-credit-account-balance-evaluated --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-authentication-requested-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:customer-support-service-authentication-requested-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-authentication-requested-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-card-pin-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-card-pin-updated-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-card-pin-updated-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-card-replacement-sent-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-card-replacement-sent-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-card-replacement-sent-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-card-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-card-upserted-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-card-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-credit-account-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-closed-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-credit-account-closed-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-credit-account-opened-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-opened-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-credit-account-opened-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-credit-account-statement-revealed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-service-credit-account-statement-revealed-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-credit-account-statement-revealed-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-credit-account-transaction-changed-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-transaction-changed-event.fifo --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-credit-account-transaction-changed-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-credit-application-decision-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-credit-application-decision-updated-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-credit-application-decision-updated-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-credit-application-status-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-credit-application-status-updated-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-credit-application-status-updated-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-credit-delinquency-block-updated-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-delinquency-service-credit-delinquency-block-updated-event.fifo --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-credit-delinquency-block-updated-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-credit-limit-increase-applied-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-limit-increase-applied-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-credit-limit-increase-applied-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-dispute-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:dispute-service-dispute-closed-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-dispute-closed-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-dispute-opened-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:dispute-service-dispute-opened-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-dispute-opened-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-incoming-bill-payment-transaction-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-incoming-bill-payment-transaction-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-incoming-bill-payment-transaction-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-mcd-3ds-otp-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:cardinal-service-mcd-3ds-otp-received-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-mcd-3ds-otp-received-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-savings-account-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-closed-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-savings-account-closed-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-savings-account-opened-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-opened-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-savings-account-opened-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-savings-account-statement-revealed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-service-savings-account-statement-revealed-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-savings-account-statement-revealed-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-savings-account-suspended-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-suspended-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-savings-account-suspended-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-savings-account-transaction-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-transaction-upserted-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-savings-account-transaction-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-savings-account-unsuspended-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-unsuspended-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-savings-account-unsuspended-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-savings-application-decision-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-onboarding-service-savings-application-decision-updated-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-savings-application-decision-updated-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-savings-application-status-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-onboarding-service-savings-application-status-updated-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-savings-application-status-updated-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-secured-credit-application-funding-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-secured-credit-application-funding-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-secured-credit-application-funding-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-secured-credit-external-transfer-declined-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-secured-credit-external-transfer-declined-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-secured-credit-external-transfer-declined-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-secured-credit-funds-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-secured-credit-funds-completed-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-secured-credit-funds-completed-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-secured-credit-limit-increased-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-secured-credit-limit-increased-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-secured-credit-limit-increased-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-token-activation-code-notification-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payment-token-service-token-activation-code-notification-received-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-token-activation-code-notification-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-transaction-authorized-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-transaction-authorized-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-transaction-authorized-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-transaction-declined-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-transaction-declined-event --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-transaction-declined-event --protocol sqs
awslocal sqs create-queue --queue-name partner-event-relay-service-user-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/partner-event-relay-service-user-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name payments-service-complyadvantage-response-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:webhook-complyadvantage-response-received-event --notification-endpoint http://localhost:4566/000000000000/payments-service-complyadvantage-response-received-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-external-account-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-external-account-upserted-event --notification-endpoint http://localhost:4566/000000000000/payments-service-external-account-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name payment-token-service-card-account-changed-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-vault-card-account-changed-event.fifo --notification-endpoint http://localhost:4566/000000000000/payment-token-service-card-account-changed-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name payment-token-service-card-block-attempt-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:mcd-decider-card-block-attempt-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/payment-token-service-card-block-attempt-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name payment-token-service-mcd-card-suspension-status-changed-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-vault-mcd-card-suspension-status-changed-event.fifo --notification-endpoint http://localhost:4566/000000000000/payment-token-service-mcd-card-suspension-status-changed-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name payment-token-service-card-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-card-upserted-event --notification-endpoint http://localhost:4566/000000000000/payment-token-service-card-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name payment-token-service-mcd-card-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-vault-mcd-card-upserted-event --notification-endpoint http://localhost:4566/000000000000/payment-token-service-mcd-card-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name payment-token-service-user-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/payment-token-service-user-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name payments-service-addon-purchased-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:plans-service-addon-purchased-event --notification-endpoint http://localhost:4566/000000000000/payments-service-addon-purchased-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-card-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-card-upserted-event --notification-endpoint http://localhost:4566/000000000000/payments-service-card-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-credit-account-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-upserted-event --notification-endpoint http://localhost:4566/000000000000/payments-service-credit-account-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-credit-application-abandoned-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-credit-application-abandoned-event --notification-endpoint http://localhost:4566/000000000000/payments-service-credit-application-abandoned-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-e-transfer-customer-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:e-transfer-service-e-transfer-customer-upserted-event --notification-endpoint http://localhost:4566/000000000000/payments-service-e-transfer-customer-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-e-transfer-customer-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-e-transfer-customer-upserted-event --notification-endpoint http://localhost:4566/000000000000/payments-service-e-transfer-customer-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-eft-manually-reviewed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-scammer-service-eft-manually-reviewed-event --notification-endpoint http://localhost:4566/000000000000/payments-service-eft-manually-reviewed-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-external-acc-verif-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-external-acc-verif-upserted-event --notification-endpoint http://localhost:4566/000000000000/payments-service-external-acc-verif-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-external-account-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-external-account-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/payments-service-external-account-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name payments-service-external-account-to-secured-credit-funding-initiated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-external-account-to-secured-credit-funding-initiated-event --notification-endpoint http://localhost:4566/000000000000/payments-service-external-account-to-secured-credit-funding-initiated-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-external-to-savings-auto-transfer-initiated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:auto-transfer-service-external-to-savings-auto-transfer-initiated-event --notification-endpoint http://localhost:4566/000000000000/payments-service-external-to-savings-auto-transfer-initiated-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-inbound-eft-declined-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-inbound-eft-declined-event --notification-endpoint http://localhost:4566/000000000000/payments-service-inbound-eft-declined-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-initiate-tax-refund-funding-transfer-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-initiate-tax-refund-funding-transfer-event --notification-endpoint http://localhost:4566/000000000000/payments-service-initiate-tax-refund-funding-transfer-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-installment-plan-external-transfer-ivf-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:atb-pad-download-job-installment-plan-external-transfer-ivf-received-event --notification-endpoint http://localhost:4566/000000000000/payments-service-installment-plan-external-transfer-ivf-received-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-installment-plan-external-transfer-rin-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:atb-pad-download-job-installment-plan-external-transfer-rin-received-event --notification-endpoint http://localhost:4566/000000000000/payments-service-installment-plan-external-transfer-rin-received-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-loan-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:loan-credit-facility-service-loan-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/payments-service-loan-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name payments-service-restriction-policy-association-changed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:restriction-policy-service-restriction-policy-association-changed-event --notification-endpoint http://localhost:4566/000000000000/payments-service-restriction-policy-association-changed-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-restriction-policy-changed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:restriction-policy-service-restriction-policy-changed-event --notification-endpoint http://localhost:4566/000000000000/payments-service-restriction-policy-changed-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-rewards-cashout-to-savings-transaction-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-rewards-cashout-to-savings-transaction-created-event --notification-endpoint http://localhost:4566/000000000000/payments-service-rewards-cashout-to-savings-transaction-created-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-savings-account-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-closed-event --notification-endpoint http://localhost:4566/000000000000/payments-service-savings-account-closed-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-savings-account-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-created-event --notification-endpoint http://localhost:4566/000000000000/payments-service-savings-account-created-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-savings-account-opened-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-opened-event --notification-endpoint http://localhost:4566/000000000000/payments-service-savings-account-opened-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-savings-account-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-updated-event --notification-endpoint http://localhost:4566/000000000000/payments-service-savings-account-updated-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-savings-program-arrangement-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-account-service-savings-program-arrangement-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/payments-service-savings-program-arrangement-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name payments-service-savings-program-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-account-service-savings-program-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/payments-service-savings-program-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name payments-service-savings-to-credit-auto-payment-triggered-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:auto-transfer-service-savings-to-credit-auto-payment-triggered-event --notification-endpoint http://localhost:4566/000000000000/payments-service-savings-to-credit-auto-payment-triggered-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-savings-to-secured-credit-funding-initiated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-to-secured-credit-funding-initiated-event --notification-endpoint http://localhost:4566/000000000000/payments-service-savings-to-secured-credit-funding-initiated-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-secured-credit-account-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-secured-credit-account-closed-event --notification-endpoint http://localhost:4566/000000000000/payments-service-secured-credit-account-closed-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-secured-credit-application-abandoned-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-secured-credit-application-abandoned-event --notification-endpoint http://localhost:4566/000000000000/payments-service-secured-credit-application-abandoned-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-secured-credit-deposit-account-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-secured-credit-deposit-account-upserted-event --notification-endpoint http://localhost:4566/000000000000/payments-service-secured-credit-deposit-account-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-secured-credit-external-transfer-ivf-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:atb-pad-download-job-secured-credit-external-transfer-ivf-received-event --notification-endpoint http://localhost:4566/000000000000/payments-service-secured-credit-external-transfer-ivf-received-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-secured-credit-external-transfer-rin-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:atb-pad-download-job-secured-credit-external-transfer-rin-received-event --notification-endpoint http://localhost:4566/000000000000/payments-service-secured-credit-external-transfer-rin-received-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-tax-refund-repayment-external-transfer-ivf-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:atb-pad-download-job-tax-refund-repayment-external-transfer-ivf-received-event --notification-endpoint http://localhost:4566/000000000000/payments-service-tax-refund-repayment-external-transfer-ivf-received-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-tax-refund-repayment-external-transfer-rin-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:atb-pad-download-job-tax-refund-repayment-external-transfer-rin-received-event --notification-endpoint http://localhost:4566/000000000000/payments-service-tax-refund-repayment-external-transfer-rin-received-event --protocol sqs
awslocal sqs create-queue --queue-name payments-service-user-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-upserted-event --notification-endpoint http://localhost:4566/000000000000/payments-service-user-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name plans-service-applied-bonus-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:referral-service-applied-bonus-upserted-event --notification-endpoint http://localhost:4566/000000000000/plans-service-applied-bonus-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name plans-service-credit-account-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-upserted-event --notification-endpoint http://localhost:4566/000000000000/plans-service-credit-account-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name plans-service-instant-tax-refund-initialized-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:instant-tax-refund-service-instant-tax-refund-initialized-event --notification-endpoint http://localhost:4566/000000000000/plans-service-instant-tax-refund-initialized-event --protocol sqs
awslocal sqs create-queue --queue-name plans-service-savings-account-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/plans-service-savings-account-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name plans-service-user-rewards-data-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-user-rewards-data-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/plans-service-user-rewards-data-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name plans-service-user-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-upserted-event --notification-endpoint http://localhost:4566/000000000000/plans-service-user-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name prequalification-service-hashed-sin-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-hashed-sin-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/prequalification-service-hashed-sin-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name prequalification-service-loan-prequalification-fee-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:instant-tax-refund-service-loan-prequalification-fee-created-event --notification-endpoint http://localhost:4566/000000000000/prequalification-service-loan-prequalification-fee-created-event --protocol sqs
awslocal sqs create-queue --queue-name prequalification-service-savings-application-abandoned-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-onboarding-service-application-abandoned-event --notification-endpoint http://localhost:4566/000000000000/prequalification-service-savings-application-abandoned-event --protocol sqs
awslocal sqs create-queue --queue-name prequalification-service-user-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/prequalification-service-user-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name redemption-service-brand-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-brand-updated-event --notification-endpoint http://localhost:4566/000000000000/redemption-service-brand-updated-event --protocol sqs
awslocal sqs create-queue --queue-name redemption-service-eligible-offer-for-transaction-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-eligible-offer-for-transaction-event --notification-endpoint http://localhost:4566/000000000000/redemption-service-eligible-offer-for-transaction-event --protocol sqs
awslocal sqs create-queue --queue-name redemption-service-mcd-transaction-processed-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:mcd-decider-transaction-processed-event.fifo --notification-endpoint http://localhost:4566/000000000000/redemption-service-mcd-transaction-processed-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name redemption-service-transaction-manually-reversed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-transaction-manually-reversed-event --notification-endpoint http://localhost:4566/000000000000/redemption-service-transaction-manually-reversed-event --protocol sqs
awslocal sqs create-queue --queue-name redemption-service-transaction-processed-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:decider-transaction-processed-event.fifo --notification-endpoint http://localhost:4566/000000000000/redemption-service-transaction-processed-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name redemption-service-user-rewards-data-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-user-rewards-data-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/redemption-service-user-rewards-data-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name referral-analytics-service-applied-bounty-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:referral-service-applied-bounty-upserted-event --notification-endpoint http://localhost:4566/000000000000/referral-analytics-service-applied-bounty-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name referral-service-approved-investment-application-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-onboarding-service-approved-investment-application-completed-event --notification-endpoint http://localhost:4566/000000000000/referral-service-approved-investment-application-completed-event --protocol sqs
awslocal sqs create-queue --queue-name referral-service-credit-account-opened-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-opened-event --notification-endpoint http://localhost:4566/000000000000/referral-service-credit-account-opened-event --protocol sqs
awslocal sqs create-queue --queue-name referral-service-credit-application-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-credit-application-created-event --notification-endpoint http://localhost:4566/000000000000/referral-service-credit-application-created-event --protocol sqs
awslocal sqs create-queue --queue-name referral-service-credit-application-user-information-reviewed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-user-information-reviewed-event --notification-endpoint http://localhost:4566/000000000000/referral-service-credit-application-user-information-reviewed-event --protocol sqs
awslocal sqs create-queue --queue-name referral-service-credit-application-user-preliminary-data-collected-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-credit-application-user-preliminary-data-collected-event --notification-endpoint http://localhost:4566/000000000000/referral-service-credit-application-user-preliminary-data-collected-event --protocol sqs
awslocal sqs create-queue --queue-name referral-service-jito-credit-application-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-credit-application-created-event --notification-endpoint http://localhost:4566/000000000000/referral-service-jito-credit-application-created-event --protocol sqs
awslocal sqs create-queue --queue-name referral-service-location-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-location-updated-event --notification-endpoint http://localhost:4566/000000000000/referral-service-location-updated-event --protocol sqs
awslocal sqs create-queue --queue-name referral-service-mortgage-account-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:mortgage-service-mortgage-account-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/referral-service-mortgage-account-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name referral-service-mortgage-lead-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:mortgage-service-mortgage-lead-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/referral-service-mortgage-lead-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name referral-service-prepaid-card-application-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-onboarding-service-prepaid-card-application-completed-event --notification-endpoint http://localhost:4566/000000000000/referral-service-prepaid-card-application-completed-event --protocol sqs
awslocal sqs create-queue --queue-name referral-service-rewards-account-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:neo-mart-rewards-account-created-event --notification-endpoint http://localhost:4566/000000000000/referral-service-rewards-account-created-event --protocol sqs
awslocal sqs create-queue --queue-name referral-service-savings-account-opened-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-opened-event --notification-endpoint http://localhost:4566/000000000000/referral-service-savings-account-opened-event --protocol sqs
awslocal sqs create-queue --queue-name referral-service-threshold-met-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:spend-analytics-service-threshold-met-event --notification-endpoint http://localhost:4566/000000000000/referral-service-threshold-met-event --protocol sqs
awslocal sqs create-queue --queue-name referral-service-user-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-upserted-event --notification-endpoint http://localhost:4566/000000000000/referral-service-user-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name rewards-service-applied-bonus-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:referral-service-applied-bonus-upserted-event --notification-endpoint http://localhost:4566/000000000000/rewards-service-applied-bonus-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name rewards-service-benefit-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:plans-service-benefit-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/rewards-service-benefit-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name rewards-service-brand-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-brand-updated-event --notification-endpoint http://localhost:4566/000000000000/rewards-service-brand-updated-event --protocol sqs
awslocal sqs create-queue --queue-name rewards-service-card-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-card-upserted-event --notification-endpoint http://localhost:4566/000000000000/rewards-service-card-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name rewards-service-fingerprint-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-fingerprint-upserted-event --notification-endpoint http://localhost:4566/000000000000/rewards-service-fingerprint-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name rewards-service-location-freeze-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:merchant-billing-service-location-freeze-event --notification-endpoint http://localhost:4566/000000000000/rewards-service-location-freeze-event --protocol sqs
awslocal sqs create-queue --queue-name rewards-service-location-funding-account-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:merchant-billing-service-location-funding-account-updated-event --notification-endpoint http://localhost:4566/000000000000/rewards-service-location-funding-account-updated-event --protocol sqs
awslocal sqs create-queue --queue-name rewards-service-mcd-transaction-processed-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:mcd-decider-transaction-processed-event.fifo --notification-endpoint http://localhost:4566/000000000000/rewards-service-mcd-transaction-processed-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name rewards-service-redemption-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:redemption-service-redemption-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/rewards-service-redemption-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name rewards-service-offer-expiring-soon-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:redemption-service-offer-expiring-soon-event --notification-endpoint http://localhost:4566/000000000000/rewards-service-offer-expiring-soon-event --protocol sqs
awslocal sqs create-queue --queue-name rewards-service-transaction-processed-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:decider-transaction-processed-event.fifo --notification-endpoint http://localhost:4566/000000000000/rewards-service-transaction-processed-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name rewards-service-user-benefit-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:plans-service-user-benefit-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/rewards-service-user-benefit-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name rewards-service-user-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-upserted-event --notification-endpoint http://localhost:4566/000000000000/rewards-service-user-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name rewards-service-user-wizard-data-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-wizard-service-user-wizard-data-upserted-event --notification-endpoint http://localhost:4566/000000000000/rewards-service-user-wizard-data-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name rewards-store-service-order-processed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:neo-mart-order-processed-event --notification-endpoint http://localhost:4566/000000000000/rewards-store-service-order-processed-event --protocol sqs
awslocal sqs create-queue --queue-name rewards-store-service-order-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-store-service-order-upserted-event --notification-endpoint http://localhost:4566/000000000000/rewards-store-service-order-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name rewards-store-service-region-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-region-updated-event --notification-endpoint http://localhost:4566/000000000000/rewards-store-service-region-updated-event --protocol sqs
awslocal sqs create-queue --queue-name rewards-store-service-rewards-account-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:neo-mart-rewards-account-upserted-event --notification-endpoint http://localhost:4566/000000000000/rewards-store-service-rewards-account-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name rewards-store-service-user-rewards-data-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-user-rewards-data-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/rewards-store-service-user-rewards-data-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name rewards-store-service-user-rewards-scheme-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-user-rewards-scheme-updated-event --notification-endpoint http://localhost:4566/000000000000/rewards-store-service-user-rewards-scheme-updated-event --protocol sqs
awslocal sqs create-queue --queue-name rewards-store-service-user-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-upserted-event --notification-endpoint http://localhost:4566/000000000000/rewards-store-service-user-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name rewards-wizard-service-brand-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-brand-updated-event --notification-endpoint http://localhost:4566/000000000000/rewards-wizard-service-brand-updated-event --protocol sqs
awslocal sqs create-queue --queue-name savings-account-service-savings-account-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/savings-account-service-savings-account-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name savings-account-t5-slip-generator-t5-slip-data-processed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-gen-t5-slip-data-processed-event --notification-endpoint http://localhost:4566/000000000000/savings-account-t5-slip-generator-t5-slip-data-processed-event --protocol sqs
awslocal sqs create-queue --queue-name savings-onboarding-service-address-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-address-module-updated-event --notification-endpoint http://localhost:4566/000000000000/savings-onboarding-service-address-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name savings-onboarding-service-application-metadata-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-application-metadata-created-event --notification-endpoint http://localhost:4566/000000000000/savings-onboarding-service-application-metadata-created-event --protocol sqs
awslocal sqs create-queue --queue-name savings-onboarding-service-berbix-retry-triggered-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-berbix-retry-triggered-event --notification-endpoint http://localhost:4566/000000000000/savings-onboarding-service-berbix-retry-triggered-event --protocol sqs
awslocal sqs create-queue --queue-name savings-onboarding-service-berbix-transaction-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-berbix-transaction-created-event --notification-endpoint http://localhost:4566/000000000000/savings-onboarding-service-berbix-transaction-created-event --protocol sqs
awslocal sqs create-queue --queue-name savings-onboarding-service-block-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-block-completed-event --notification-endpoint http://localhost:4566/000000000000/savings-onboarding-service-block-completed-event --protocol sqs
awslocal sqs create-queue --queue-name savings-onboarding-service-date-of-birth-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-date-of-birth-module-updated-event --notification-endpoint http://localhost:4566/000000000000/savings-onboarding-service-date-of-birth-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name savings-onboarding-service-employment-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-employment-module-updated-event --notification-endpoint http://localhost:4566/000000000000/savings-onboarding-service-employment-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name savings-onboarding-service-foreign-tax-information-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-foreign-tax-information-module-updated-event --notification-endpoint http://localhost:4566/000000000000/savings-onboarding-service-foreign-tax-information-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name savings-onboarding-service-id-verification-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-id-verification-completed-event --notification-endpoint http://localhost:4566/000000000000/savings-onboarding-service-id-verification-completed-event --protocol sqs
awslocal sqs create-queue --queue-name savings-onboarding-service-id-verification-synced-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-id-verification-synced-event --notification-endpoint http://localhost:4566/000000000000/savings-onboarding-service-id-verification-synced-event --protocol sqs
awslocal sqs create-queue --queue-name savings-onboarding-service-id-verification-unsynced-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-id-verification-unsynced-event --notification-endpoint http://localhost:4566/000000000000/savings-onboarding-service-id-verification-unsynced-event --protocol sqs
awslocal sqs create-queue --queue-name savings-onboarding-service-name-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-name-module-updated-event --notification-endpoint http://localhost:4566/000000000000/savings-onboarding-service-name-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name savings-onboarding-service-prepaid-card-application-pin-set-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-prepaid-card-application-pin-set-completed-event --notification-endpoint http://localhost:4566/000000000000/savings-onboarding-service-prepaid-card-application-pin-set-completed-event --protocol sqs
awslocal sqs create-queue --queue-name savings-onboarding-service-prepaid-card-creation-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-prepaid-card-creation-completed-event --notification-endpoint http://localhost:4566/000000000000/savings-onboarding-service-prepaid-card-creation-completed-event --protocol sqs
awslocal sqs create-queue --queue-name savings-onboarding-service-prequalification-claimed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:prequalification-service-prequalification-claimed-event --notification-endpoint http://localhost:4566/000000000000/savings-onboarding-service-prequalification-claimed-event --protocol sqs
awslocal sqs create-queue --queue-name savings-onboarding-service-primary-checks-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-primary-checks-completed-event --notification-endpoint http://localhost:4566/000000000000/savings-onboarding-service-primary-checks-completed-event --protocol sqs
awslocal sqs create-queue --queue-name savings-onboarding-service-primary-checks-retry-succeeded-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:identity-service-primary-checks-retry-succeeded-event --notification-endpoint http://localhost:4566/000000000000/savings-onboarding-service-primary-checks-retry-succeeded-event --protocol sqs
awslocal sqs create-queue --queue-name savings-onboarding-service-savings-account-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-closed-event --notification-endpoint http://localhost:4566/000000000000/savings-onboarding-service-savings-account-closed-event --protocol sqs
awslocal sqs create-queue --queue-name savings-onboarding-service-savings-account-replication-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-replication-event.fifo --notification-endpoint http://localhost:4566/000000000000/savings-onboarding-service-savings-account-replication-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name savings-onboarding-service-savings-product-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-savings-product-updated-event --notification-endpoint http://localhost:4566/000000000000/savings-onboarding-service-savings-product-updated-event --protocol sqs
awslocal sqs create-queue --queue-name savings-onboarding-service-sin-module-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-sin-module-updated-event --notification-endpoint http://localhost:4566/000000000000/savings-onboarding-service-sin-module-updated-event --protocol sqs
awslocal sqs create-queue --queue-name savings-statement-pdf-generator-data-processed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-gen-savings-data-processed-event --notification-endpoint http://localhost:4566/000000000000/savings-statement-pdf-generator-data-processed-event --protocol sqs
awslocal sqs create-queue --queue-name savings-transaction-service-balance-summary-generated-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:core-ledger-service-savings-balance-summary-generated-event.fifo --notification-endpoint http://localhost:4566/000000000000/savings-transaction-service-balance-summary-generated-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name savings-transaction-service-savings-interest-cutoff-calculated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-interest-cutoff-calculated-event --notification-endpoint http://localhost:4566/000000000000/savings-transaction-service-savings-interest-cutoff-calculated-event --protocol sqs
awslocal sqs create-queue --queue-name savings-transaction-service-savings-statement-period-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-statement-period-upserted-event --notification-endpoint http://localhost:4566/000000000000/savings-transaction-service-savings-statement-period-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name savings-transaction-service-savings-transaction-upserted-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-transaction-service-savings-transaction-upserted-event.fifo --notification-endpoint http://localhost:4566/000000000000/savings-transaction-service-savings-transaction-upserted-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-3d-secure-message-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:i2c-service-3d-secure-message-received-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-3d-secure-message-received-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-mcd-3ds-otp-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:cardinal-service-mcd-3ds-otp-received-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-mcd-3ds-otp-received-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-applied-bonus-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:referral-service-applied-bonus-upserted-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-applied-bonus-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-applied-bounty-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:referral-service-applied-bounty-upserted-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-applied-bounty-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-approved-credit-application-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-approved-credit-application-completed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-approved-credit-application-completed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-approved-savings-application-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-onboarding-service-approved-savings-application-completed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-approved-savings-application-completed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-card-activated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-card-activated-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-card-activated-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-card-pin-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-card-pin-updated-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-card-pin-updated-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-card-reissuance-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-card-reissuance-completed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-card-reissuance-completed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-card-reissuance-requested-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-service-card-reissuance-requested-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-card-reissuance-requested-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-card-reissued-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-service-card-reissued-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-card-reissued-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-credit-account-auto-payment-disabled-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:auto-transfer-service-credit-account-auto-payment-disabled-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-credit-account-auto-payment-disabled-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-credit-account-auto-payment-failed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-credit-account-auto-payment-failed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-credit-account-auto-payment-failed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-credit-account-balance-evaluated --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-service-credit-account-balance-evaluated --notification-endpoint http://localhost:4566/000000000000/sendy-service-credit-account-balance-evaluated --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-credit-account-statement-revealed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-service-credit-account-statement-revealed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-credit-account-statement-revealed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-credit-application-auto-declined-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-credit-application-auto-declined-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-credit-application-auto-declined-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-credit-application-manually-approved-for-secured-credit-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-credit-application-manually-approved-for-secured-credit-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-credit-application-manually-approved-for-secured-credit-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-credit-application-manually-reviewed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-credit-application-manually-reviewed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-credit-application-manually-reviewed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-credit-application-ops-reviewed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-credit-application-ops-reviewed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-credit-application-ops-reviewed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-credit-auto-payment-successful-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:auto-transfer-service-credit-auto-payment-successful-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-credit-auto-payment-successful-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-credit-card-account-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-credit-card-account-created-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-credit-card-account-created-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-credit-card-fail-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:merchant-billing-service-credit-card-payment-fail-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-credit-card-fail-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-credit-delinquency-block-updated-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-delinquency-service-credit-delinquency-block-updated-event.fifo --notification-endpoint http://localhost:4566/000000000000/sendy-service-credit-delinquency-block-updated-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-credit-limit-increase-applied-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-limit-increase-applied-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-credit-limit-increase-applied-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-credit-limit-restriction-applied-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-limit-restriction-applied-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-credit-limit-restriction-applied-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-delinquency-block-updated-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-delinquency-service-delinquency-block-updated-event.fifo --notification-endpoint http://localhost:4566/000000000000/sendy-service-delinquency-block-updated-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-device-registration-requested-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-device-registration-requested-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-device-registration-requested-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-direct-deposit-registration-uploaded-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:cra-service-direct-deposit-registration-uploaded-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-direct-deposit-registration-uploaded-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-disposition-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:customer-support-service-disposition-received-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-disposition-received-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-email-verification-code-requested-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-email-verification-code-requested-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-email-verification-code-requested-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-email-verification-requested-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-email-verification-requested-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-email-verification-requested-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-external-to-savings-subscription-auto-disabled-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:auto-transfer-service-external-to-savings-subscription-auto-disabled-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-external-to-savings-subscription-auto-disabled-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-fingerprint-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-fingerprint-upserted-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-fingerprint-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-fraudnet-response-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:decider-fraudnet-response-received-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-fraudnet-response-received-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-fund-secured-account-external-funds-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-fund-secured-external-funds-completed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-fund-secured-account-external-funds-completed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-fund-secured-account-external-funds-rejected-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-fund-secured-account-external-funds-rejected-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-fund-secured-account-external-funds-rejected-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-funding-account-credit-card-fail-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:merchant-billing-service-funding-account-credit-card-payment-fail-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-funding-account-credit-card-fail-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-habit-builder-entry-earned-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:redemption-service-habit-builder-entry-earned-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-habit-builder-entry-earned-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-in-store-credit-application-declined-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-in-store-credit-application-declined-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-in-store-credit-application-declined-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-incoming-aft-credit-txn-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-incoming-aft-credit-txn-created-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-incoming-aft-credit-txn-created-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-incoming-bill-payment-failed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-incoming-bill-payment-failed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-incoming-bill-payment-failed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-incoming-bill-payment-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-incoming-bill-payment-transaction-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-incoming-bill-payment-received-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-installment-plan-external-payment-rejected-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:installments-service-installment-plan-external-payment-rejected-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-installment-plan-external-payment-rejected-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-installment-plan-initialized-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:installments-service-installment-plan-initialized-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-installment-plan-initialized-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-installment-plan-savings-insufficient-funds-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:installments-service-installment-plan-savings-insufficient-funds-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-installment-plan-savings-insufficient-funds-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-installment-repayment-method-invalidated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:installments-service-installment-repayment-method-invalidated-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-installment-repayment-method-invalidated-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-instant-tax-refund-nsf-charged-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:instant-tax-refund-service-instant-tax-refund-nsf-charged-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-instant-tax-refund-nsf-charged-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-instant-tax-refund-payment-failed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:instant-tax-refund-service-instant-tax-refund-payment-failed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-instant-tax-refund-payment-failed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-instant-tax-refund-payment-successful-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:instant-tax-refund-service-instant-tax-refund-payment-successful-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-instant-tax-refund-payment-successful-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-instant-tax-refund-repayment-method-invalidated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:instant-tax-refund-service-instant-tax-refund-repayment-method-invalidated-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-instant-tax-refund-repayment-method-invalidated-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-investment-application-ops-reviewed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-onboarding-service-investment-application-ops-reviewed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-investment-application-ops-reviewed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-investment-user-annual-reassessment-notification-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-service-annual-reassessment-notification-created-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-investment-user-annual-reassessment-notification-created-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-investment-user-annual-reassessment-notification-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-service-annual-reassessment-notification-updated-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-investment-user-annual-reassessment-notification-updated-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-loan-agreement-generated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:instant-tax-refund-service-loan-agreement-generated-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-loan-agreement-generated-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-loan-application-ops-reviewed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:loan-onboarding-service-loan-application-ops-reviewed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-loan-application-ops-reviewed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-login-verification-requested-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-login-verification-requested-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-login-verification-requested-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-mcd-wallet-activated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payment-token-service-mcd-wallet-activated-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-mcd-wallet-activated-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-merchant-email-verification-requested-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-merchant-email-verification-requested-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-merchant-email-verification-requested-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-merchant-location-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-location-updated-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-merchant-location-updated-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-merchant-password-reset-requested-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-merchant-password-reset-requested-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-merchant-password-reset-requested-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-new-device-login-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-new-device-login-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-new-device-login-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-new-investment-account-type-opened-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-service-new-investment-account-type-opened-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-new-investment-account-type-opened-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-order-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-store-service-order-created-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-order-created-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-order-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-store-service-order-upserted-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-order-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-outbound-eft-transaction-rejected-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-outbound-eft-transaction-rejected-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-outbound-eft-transaction-rejected-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-outbound-eft-transaction-settled-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-outbound-eft-transaction-settled-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-outbound-eft-transaction-settled-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-outgoing-etransfer-failed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-outgoing-etransfer-failed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-outgoing-etransfer-failed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-password-changed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-password-changed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-password-changed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-password-existence-checked-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-password-existence-checked-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-password-existence-checked-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-password-reset-failed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-password-reset-failed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-password-reset-failed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-password-reset-requested-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-password-reset-requested-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-password-reset-requested-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-password-setup-requested-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-password-setup-requested-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-password-setup-requested-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-phone-verification-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-phone-verification-completed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-phone-verification-completed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-phone-verification-requested-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-phone-verification-requested-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-phone-verification-requested-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-plan-subscription-changed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:neo-mart-plan-subscription-changed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-plan-subscription-changed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-plan-subscription-renewed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:neo-mart-plan-subscription-renewed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-plan-subscription-renewed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-prepaid-card-application-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-onboarding-service-prepaid-card-application-completed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-prepaid-card-application-completed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-prepaid-settled-transaction-authorized-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-prepaid-settled-transaction-authorized-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-prepaid-settled-transaction-authorized-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-prepaid-transaction-authorized-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-prepaid-transaction-authorized-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-prepaid-transaction-authorized-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-prepaid-transaction-declined-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-prepaid-transaction-declined-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-prepaid-transaction-declined-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-prepaid-transaction-reversed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-prepaid-transaction-reversed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-prepaid-transaction-reversed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-prequalification-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:prequalification-service-prequalification-completed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-prequalification-completed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-prequalification-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:prequalification-service-prequalification-created-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-prequalification-created-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-prequalification-url-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:prequalification-service-prequalification-url-updated-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-prequalification-url-updated-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-punch-earned-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:redemption-service-punch-earned-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-punch-earned-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-replacement-card-shipped-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-replacement-card-shipped-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-replacement-card-shipped-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-restriction-policy-association-changed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:restriction-policy-service-restriction-policy-association-changed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-restriction-policy-association-changed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-restriction-policy-changed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:restriction-policy-service-restriction-policy-changed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-restriction-policy-changed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-reward-redeemed-to-account-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:redemption-service-reward-redeemed-to-account-event.fifo --notification-endpoint http://localhost:4566/000000000000/sendy-service-reward-redeemed-to-account-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-rewards-cash-out-to-credit-failed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:neo-mart-rewards-cash-out-to-credit-failed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-rewards-cash-out-to-credit-failed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-rewards-cash-out-to-savings-failed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:neo-mart-rewards-cash-out-to-savings-failed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-rewards-cash-out-to-savings-failed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-savings-account-opened-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-savings-account-opened-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-savings-account-opened-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-savings-account-statement-revealed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-service-savings-account-statement-revealed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-savings-account-statement-revealed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-savings-application-manual-reviewed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-savings-application-manual-reviewed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-savings-application-manual-reviewed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-savings-application-ops-reviewed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-onboarding-service-savings-application-ops-reviewed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-savings-application-ops-reviewed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-savings-t5-slip-revealed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-service-savings-t5-slip-revealed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-savings-t5-slip-revealed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-savings-to-payee-subscription-auto-disabled-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:auto-transfer-service-savings-to-payee-subscription-auto-disabled-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-savings-to-payee-subscription-auto-disabled-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-secured-credit-application-manually-reviewed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-secured-credit-application-manually-reviewed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-secured-credit-application-manually-reviewed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-secured-credit-limit-decrease-unsuccessful-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-secured-credit-limit-decrease-unsuccessful-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-secured-credit-limit-decrease-unsuccessful-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-secured-credit-limit-decreased-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-secured-credit-limit-decreased-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-secured-credit-limit-decreased-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-secured-credit-limit-increase-unsuccessful-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-secured-credit-limit-increase-unsuccessful-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-secured-credit-limit-increase-unsuccessful-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-secured-credit-limit-increased-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-secured-credit-limit-increased-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-secured-credit-limit-increased-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-security-funds-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-security-funds-completed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-security-funds-completed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-security-questions-update-requested-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-security-questions-update-requested-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-security-questions-update-requested-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-security-questions-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-security-questions-updated-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-security-questions-updated-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-settled-transaction-authorized-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-settled-transaction-authorized-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-settled-transaction-authorized-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-spend-entry-earned-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:redemption-service-spend-entry-earned-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-spend-entry-earned-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-sts-savings-account-balance-summary-generated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-transaction-service-savings-account-balance-summary-generated --notification-endpoint http://localhost:4566/000000000000/sendy-service-sts-savings-account-balance-summary-generated-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-telpay-bill-payment-failed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-telpay-bill-payment-failed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-telpay-bill-payment-failed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-token-activation-code-notification-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payment-token-service-token-activation-code-notification-received-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-token-activation-code-notification-received-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-top-up-processing-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:neo-mart-top-up-processing-completed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-top-up-processing-completed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-transaction-authorized-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-transaction-authorized-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-transaction-authorized-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-transaction-declined-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-transaction-declined-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-transaction-declined-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-transaction-reevaluated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-transaction-reevaluated-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-transaction-reevaluated-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-transaction-reversed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-transaction-reversed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-transaction-reversed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-user-account-unusual-activity-detected-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-account-unusual-activity-detected-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-user-account-unusual-activity-detected-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-user-details-changed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-details-changed-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-user-details-changed-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-user-email-verification-requested-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-email-verification-requested-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-user-email-verification-requested-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-user-initialized-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-initialized-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-user-initialized-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-user-membership-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:external-plan-benefits-service-user-membership-updated-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-user-membership-updated-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-user-rewards-plan-actions-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:plans-service-user-rewards-plan-actions-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-user-rewards-plan-actions-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-user-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-upserted-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-user-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-wallet-activated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:decider-wallet-activated-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-wallet-activated-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-wallet-otp-requested-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:decider-wallet-otp-requested-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-wallet-otp-requested-event --protocol sqs
awslocal sqs create-queue --queue-name sendy-service-web-to-app-deep-link-requested-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:loan-onboarding-service-web-to-app-deep-link-requested-event --notification-endpoint http://localhost:4566/000000000000/sendy-service-web-to-app-deep-link-requested-event --protocol sqs
awslocal sqs create-queue --queue-name spend-analytics-rewards-account-transaction-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:neo-mart-rewards-account-transaction-upserted-event --notification-endpoint http://localhost:4566/000000000000/spend-analytics-rewards-account-transaction-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name spend-analytics-rewards-service-credit-transaction-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-credit-transaction-upserted-event --notification-endpoint http://localhost:4566/000000000000/spend-analytics-rewards-service-credit-transaction-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name spend-analytics-service-applied-bonus-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:referral-service-applied-bonus-upserted-event --notification-endpoint http://localhost:4566/000000000000/spend-analytics-service-applied-bonus-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name spend-analytics-service-applied-bounty-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:referral-service-applied-bounty-upserted-event --notification-endpoint http://localhost:4566/000000000000/spend-analytics-service-applied-bounty-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name spend-analytics-service-bill-pay-vendor-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-bill-pay-vendor-upserted-event --notification-endpoint http://localhost:4566/000000000000/spend-analytics-service-bill-pay-vendor-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name spend-analytics-service-brand-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-brand-updated-event --notification-endpoint http://localhost:4566/000000000000/spend-analytics-service-brand-updated-event --protocol sqs
awslocal sqs create-queue --queue-name spend-analytics-service-card-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-card-upserted-event --notification-endpoint http://localhost:4566/000000000000/spend-analytics-service-card-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name spend-analytics-service-credit-account-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-secured-credit-account-closed-event --notification-endpoint http://localhost:4566/000000000000/spend-analytics-service-credit-account-closed-event --protocol sqs
awslocal sqs create-queue --queue-name spend-analytics-service-credit-account-opened-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-opened-event --notification-endpoint http://localhost:4566/000000000000/spend-analytics-service-credit-account-opened-event --protocol sqs
awslocal sqs create-queue --queue-name spend-analytics-service-credit-account-transaction-deleted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-transaction-deleted-event --notification-endpoint http://localhost:4566/000000000000/spend-analytics-service-credit-account-transaction-deleted-event --protocol sqs
awslocal sqs create-queue --queue-name spend-analytics-service-credit-account-transaction-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-transaction-upserted-event --notification-endpoint http://localhost:4566/000000000000/spend-analytics-service-credit-account-transaction-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name spend-analytics-service-fingerprint-spend-group-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:spend-analytics-service-fingerprint-spend-group-updated-event --notification-endpoint http://localhost:4566/000000000000/spend-analytics-service-fingerprint-spend-group-updated-event --protocol sqs
awslocal sqs create-queue --queue-name spend-analytics-service-fingerprint-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:rewards-service-fingerprint-upserted-event --notification-endpoint http://localhost:4566/000000000000/spend-analytics-service-fingerprint-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name spend-analytics-service-guaranteed-cashback-cycle-ended-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:neo-mart-guaranteed-cashback-cycle-ended-event --notification-endpoint http://localhost:4566/000000000000/spend-analytics-service-guaranteed-cashback-cycle-ended-event --protocol sqs
awslocal sqs create-queue --queue-name spend-analytics-service-rewards-account-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:neo-mart-rewards-account-created-event --notification-endpoint http://localhost:4566/000000000000/spend-analytics-service-rewards-account-created-event --protocol sqs
awslocal sqs create-queue --queue-name spend-analytics-service-savings-account-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-closed-event --notification-endpoint http://localhost:4566/000000000000/spend-analytics-service-savings-account-closed-event --protocol sqs
awslocal sqs create-queue --queue-name spend-analytics-service-savings-account-opened-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-opened-event --notification-endpoint http://localhost:4566/000000000000/spend-analytics-service-savings-account-opened-event --protocol sqs
awslocal sqs create-queue --queue-name spend-analytics-service-savings-account-transaction-deleted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-transaction-deleted-event --notification-endpoint http://localhost:4566/000000000000/spend-analytics-service-savings-account-transaction-deleted-event --protocol sqs
awslocal sqs create-queue --queue-name spend-analytics-service-savings-account-transaction-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-transaction-upserted-event --notification-endpoint http://localhost:4566/000000000000/spend-analytics-service-savings-account-transaction-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name statement-gen-billing-cycle-processed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-billing-cycle-processed-event --notification-endpoint http://localhost:4566/000000000000/statement-gen-billing-cycle-processed-event --protocol sqs
awslocal sqs create-queue --queue-name statement-gen-card-program-template-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:card-service-card-program-template-upserted-event --notification-endpoint http://localhost:4566/000000000000/statement-gen-card-program-template-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name statement-gen-credit-account-charged-off-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-charged-off-event --notification-endpoint http://localhost:4566/000000000000/statement-gen-credit-account-charged-off-event --protocol sqs
awslocal sqs create-queue --queue-name statement-gen-credit-limit-increase-applied-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-limit-increase-applied-event --notification-endpoint http://localhost:4566/000000000000/statement-gen-credit-limit-increase-applied-event --protocol sqs
awslocal sqs create-queue --queue-name statement-gen-interest-payment-evaluated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-interest-payment-evaluated-event --notification-endpoint http://localhost:4566/000000000000/statement-gen-interest-payment-evaluated-event --protocol sqs
awslocal sqs create-queue --queue-name statement-gen-savings-account-statement-requested-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-service-savings-account-statement-requested-event --notification-endpoint http://localhost:4566/000000000000/statement-gen-savings-account-statement-requested-event --protocol sqs
awslocal sqs create-queue --queue-name statement-service-credit-account-balance-requested --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:sendy-service-credit-account-balance-requested --notification-endpoint http://localhost:4566/000000000000/statement-service-credit-account-balance-requested --protocol sqs
awslocal sqs create-queue --queue-name statement-service-credit-application-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-credit-application-completed-event --notification-endpoint http://localhost:4566/000000000000/statement-service-credit-application-completed-event --protocol sqs
awslocal sqs create-queue --queue-name statement-service-jito-approved-credit-application-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-approved-credit-application-completed-event --notification-endpoint http://localhost:4566/000000000000/statement-service-jito-approved-credit-application-completed-event --protocol sqs
awslocal sqs create-queue --queue-name statement-service-payment-credit-allocated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:ledger-service-payment-credit-allocated-event --notification-endpoint http://localhost:4566/000000000000/statement-service-payment-credit-allocated-event --protocol sqs
awslocal sqs create-queue --queue-name statement-service-printed-statement-requested --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:statement-gen-printed-statement-requested-event --notification-endpoint http://localhost:4566/000000000000/statement-service-printed-statement-requested --protocol sqs
awslocal sqs create-queue --queue-name term-loan-service-balance-summary-generated-event.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:core-ledger-service-term-loan-balance-summary-generated-event.fifo --notification-endpoint http://localhost:4566/000000000000/term-loan-service-balance-summary-generated-event.fifo --protocol sqs
awslocal sqs create-queue --queue-name term-loan-service-external-account-deleted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-external-account-deleted-event --notification-endpoint http://localhost:4566/000000000000/term-loan-service-external-account-deleted-event --protocol sqs
awslocal sqs create-queue --queue-name term-loan-service-external-to-term-loan-late-decline-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:payments-service-external-to-term-loan-late-decline-received-event --notification-endpoint http://localhost:4566/000000000000/term-loan-service-external-to-term-loan-late-decline-received-event --protocol sqs
awslocal sqs create-queue --queue-name term-loan-service-installment-plan-initialized-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:installments-service-installment-plan-initialized-event --notification-endpoint http://localhost:4566/000000000000/term-loan-service-installment-plan-initialized-event --protocol sqs
awslocal sqs create-queue --queue-name term-loan-service-instant-tax-refund-cra-deposit-received-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:instant-tax-refund-service-instant-tax-refund-cra-deposit-received-event --notification-endpoint http://localhost:4566/000000000000/term-loan-service-instant-tax-refund-cra-deposit-received-event --protocol sqs
awslocal sqs create-queue --queue-name term-loan-service-instant-tax-refund-initialized-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:instant-tax-refund-service-instant-tax-refund-initialized-event --notification-endpoint http://localhost:4566/000000000000/term-loan-service-instant-tax-refund-initialized-event --protocol sqs
awslocal sqs create-queue --queue-name term-loan-service-savings-account-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-closed-event --notification-endpoint http://localhost:4566/000000000000/term-loan-service-savings-account-closed-event --protocol sqs
awslocal sqs create-queue --queue-name term-loan-service-savings-account-suspended-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-suspended-event --notification-endpoint http://localhost:4566/000000000000/term-loan-service-savings-account-suspended-event --protocol sqs
awslocal sqs create-queue --queue-name term-loan-service-term-loan-auto-payment-triggered-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:auto-transfer-service-term-loan-auto-payment-triggered-event --notification-endpoint http://localhost:4566/000000000000/term-loan-service-term-loan-auto-payment-triggered-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-approved-credit-application-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-approved-credit-application-completed-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-approved-credit-application-completed-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-approved-credit-card-application-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-approved-credit-card-application-completed-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-approved-credit-card-application-completed-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-approved-investment-application-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-onboarding-service-approved-investment-application-completed-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-approved-investment-application-completed-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-approved-loan-application-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:loan-onboarding-service-approved-loan-application-completed-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-approved-loan-application-completed-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-approved-savings-application-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-onboarding-service-approved-savings-application-completed-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-approved-savings-application-completed-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-baas-credit-application-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-baas-credit-application-created-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-baas-credit-application-created-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-baas-savings-application-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-onboarding-service-baas-savings-application-created-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-baas-savings-application-created-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-baas-secured-credit-application-created-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-baas-secured-credit-application-created-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-baas-secured-credit-application-created-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-citizenship-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-service-citizenship-upserted-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-citizenship-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-credit-application-decision-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-credit-application-decision-updated-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-credit-application-decision-updated-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-credit-disclosure-accepted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-credit-disclosure-accepted-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-credit-disclosure-accepted-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-credit-product-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-credit-product-updated-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-credit-product-updated-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-credit-user-information-reviewed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-user-information-reviewed-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-credit-user-information-reviewed-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-investment-account-completion-synced-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-onboarding-service-investment-account-completion-synced-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-investment-account-completion-synced-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-investment-agreements-block-started-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-onboarding-service-investment-agreements-block-started-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-investment-agreements-block-started-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-investment-annual-reassessment-started-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-onboarding-service-annual-reassessment-started-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-investment-annual-reassessment-started-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-investment-application-abandoned-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-onboarding-service-investment-application-abandoned-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-investment-application-abandoned-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-investment-application-decision-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-onboarding-service-investment-application-decision-updated-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-investment-application-decision-updated-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-investment-portfolio-block-started-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-onboarding-service-investment-portfolio-block-started-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-investment-portfolio-block-started-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-investment-product-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-investment-product-updated-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-investment-product-updated-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-investment-questionnaire-block-started-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-onboarding-service-investment-questionnaire-block-started-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-investment-questionnaire-block-started-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-investment-user-information-reviewed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-onboarding-service-investment-user-information-reviewed-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-investment-user-information-reviewed-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-loan-application-decision-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:loan-onboarding-service-loan-application-decision-updated-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-loan-application-decision-updated-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-loan-user-information-reviewed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:loan-onboarding-service-user-information-reviewed-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-loan-user-information-reviewed-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-marital-information-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-service-marital-information-upserted-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-marital-information-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-prepaid-card-creation-initialized-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-onboarding-service-prepaid-card-creation-initialized-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-prepaid-card-creation-initialized-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-risk-capacity-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-service-risk-capacity-upserted-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-risk-capacity-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-savings-application-abandoned-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-onboarding-service-application-abandoned-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-savings-application-abandoned-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-savings-application-decision-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-onboarding-service-savings-application-decision-updated-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-savings-application-decision-updated-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-savings-product-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-savings-product-updated-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-savings-product-updated-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-savings-user-information-reviewed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-onboarding-service-user-information-reviewed-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-savings-user-information-reviewed-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-sin-income-tax-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-sin-income-tax-updated-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-sin-income-tax-updated-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-user-tax-information-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-tax-information-upserted-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-user-tax-information-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name unified-onboarding-service-user-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:user-service-user-upserted-event --notification-endpoint http://localhost:4566/000000000000/unified-onboarding-service-user-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name user-service-admin-user-roles-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:admin-authorization-service-admin-user-roles-updated-event --notification-endpoint http://localhost:4566/000000000000/user-service-admin-user-roles-updated-event --protocol sqs
awslocal sqs create-queue --queue-name user-service-block-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-block-completed-event --notification-endpoint http://localhost:4566/000000000000/user-service-block-completed-event --protocol sqs
awslocal sqs create-queue --queue-name user-service-credit-account-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-closed-event --notification-endpoint http://localhost:4566/000000000000/user-service-credit-account-closed-event --protocol sqs
awslocal sqs create-queue --queue-name user-service-credit-account-opened-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-credit-account-opened-event --notification-endpoint http://localhost:4566/000000000000/user-service-credit-account-opened-event --protocol sqs
awslocal sqs create-queue --queue-name user-service-credit-card-application-completed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-credit-card-application-completed-event --notification-endpoint http://localhost:4566/000000000000/user-service-credit-card-application-completed-event --protocol sqs
awslocal sqs create-queue --queue-name user-service-hbc-in-store-setup-password-reminder-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-hbc-in-store-setup-password-reminder-event --notification-endpoint http://localhost:4566/000000000000/user-service-hbc-in-store-setup-password-reminder-event --protocol sqs
awslocal sqs create-queue --queue-name user-service-in-store-application-credit-reason-declined-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:application-service-in-store-application-credit-reason-declined-event --notification-endpoint http://localhost:4566/000000000000/user-service-in-store-application-credit-reason-declined-event --protocol sqs
awslocal sqs create-queue --queue-name user-service-investment-account-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-service-investment-account-closed-event --notification-endpoint http://localhost:4566/000000000000/user-service-investment-account-closed-event --protocol sqs
awslocal sqs create-queue --queue-name user-service-investment-account-opened-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-service-investment-account-opened-event --notification-endpoint http://localhost:4566/000000000000/user-service-investment-account-opened-event --protocol sqs
awslocal sqs create-queue --queue-name user-service-investment-suitability-annual-income-updated-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:investment-service-suitability-annual-income-updated-event --notification-endpoint http://localhost:4566/000000000000/user-service-investment-suitability-annual-income-updated-event --protocol sqs
awslocal sqs create-queue --queue-name user-service-jito-in-store-application-credit-reason-declined-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-in-store-application-credit-reason-declined-event --notification-endpoint http://localhost:4566/000000000000/user-service-jito-in-store-application-credit-reason-declined-event --protocol sqs
awslocal sqs create-queue --queue-name user-service-metadata-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:unified-onboarding-service-metadata-upserted-event --notification-endpoint http://localhost:4566/000000000000/user-service-metadata-upserted-event --protocol sqs
awslocal sqs create-queue --queue-name user-service-mortgage-account-opened-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:mortgage-service-mortgage-account-opened-event --notification-endpoint http://localhost:4566/000000000000/user-service-mortgage-account-opened-event --protocol sqs
awslocal sqs create-queue --queue-name user-service-prequalification-claimed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:prequalification-service-prequalification-claimed-event --notification-endpoint http://localhost:4566/000000000000/user-service-prequalification-claimed-event --protocol sqs
awslocal sqs create-queue --queue-name user-service-reminder-claim-profile-instore-applications-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:credit-onboarding-service-reminder-claim-profile-instore-applications-event --notification-endpoint http://localhost:4566/000000000000/user-service-reminder-claim-profile-instore-applications-event --protocol sqs
awslocal sqs create-queue --queue-name user-service-restriction-policy-association-changed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:restriction-policy-service-restriction-policy-association-changed-event --notification-endpoint http://localhost:4566/000000000000/user-service-restriction-policy-association-changed-event --protocol sqs
awslocal sqs create-queue --queue-name user-service-restriction-policy-changed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:restriction-policy-service-restriction-policy-changed-event --notification-endpoint http://localhost:4566/000000000000/user-service-restriction-policy-changed-event --protocol sqs
awslocal sqs create-queue --queue-name user-service-savings-account-closed-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-closed-event --notification-endpoint http://localhost:4566/000000000000/user-service-savings-account-closed-event --protocol sqs
awslocal sqs create-queue --queue-name user-service-savings-account-opened-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:bank-service-savings-account-opened-event --notification-endpoint http://localhost:4566/000000000000/user-service-savings-account-opened-event --protocol sqs
awslocal sqs create-queue --queue-name user-service-savings-application-abandoned-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:savings-onboarding-service-application-abandoned-event --notification-endpoint http://localhost:4566/000000000000/user-service-savings-application-abandoned-event --protocol sqs
awslocal sqs create-queue --queue-name user-service-user-authorized-support-event --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:customer-support-service-user-authorized-support-event --notification-endpoint http://localhost:4566/000000000000/user-service-user-authorized-support-event --protocol sqs
awslocal sqs create-queue --queue-name sendy --attributes MessageRetentionPeriod=86400
awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:sendy --notification-endpoint http://localhost:4566/000000000000/sendy --protocol sqs
awslocal sqs create-queue --queue-name bank-service-bin-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-dispute-hold-applied-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-savings-program-settings-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-telpay-bill-payment-processed-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-expire-card-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-expire-card-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-temp-card-backfill-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-temp-card-backfill-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-scammer-service-partner-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-scammer-service-partner-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-service-bin-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name card-service-reissue-card-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-service-reissue-card-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-vault-temp-card-backfill-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-vault-i2c-to-mcd-card-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-vault-i2c-to-mcd-card-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name cash-management-service-savings-account-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name cash-management-service-savings-account-transaction-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name cash-management-service-process-funds-sweep-transfer-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name cash-management-service-process-funds-sweep-transfer-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name client-risk-rating-service-comply-advantage-report-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name client-risk-rating-service-batch-risk-recalculation-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name client-risk-rating-service-batch-risk-recalculation-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name client-risk-rating-service-execute-risk-calculations-fifo-task-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name client-risk-rating-service-execute-risk-calculations-fifo-task.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name client-risk-rating-service-update-client-risk-snapshot-fifo-task-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name client-risk-rating-service-update-client-risk-snapshot-fifo-task.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name credit-program-service-credit-program-creation-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-program-service-credit-program-creation-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-reporting-service-generate-file-group-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-reporting-service-generate-file-group-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name dispute-service-mcd-dispute-message-received-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name dtr-service-billing-cycle-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name eft-service-inbound-eft-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name eft-service-savings-program-settings-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name eft-service-user-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name eft-service-process-inbound-eft-validation-task-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name eft-service-process-inbound-eft-validation-task.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name eft-service-process-outbound-eft-creation-task-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name eft-service-process-outbound-eft-creation-task.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name eft-service-process-outbound-eft-release-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name eft-service-process-outbound-eft-release-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name iso-vault-chargeback-message-received-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name iso-vault-replicated-iso-message-reference-upserted-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name iso-vault-replicated-iso-message-reference-upserted-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name loan-credit-facility-service-process-loan-credit-facility-interest-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name loan-credit-facility-service-process-loan-credit-facility-interest-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-chargeback-service-chargeback-parent-message-found-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name mcd-chargeback-service-tqr4-file-upload-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-chargeback-service-tqr4-file-upload-received-event --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-decider-bin-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name mcd-decider-iso-message-log-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name notification-feed-ezra-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name notification-feed-ezra-second-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-allow-credit-application-reapply-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-allow-savings-application-reapply-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payment-token-service-bin-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payment-token-service-card-program-template-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payment-token-service-credit-account-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payment-token-service-savings-account-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payment-token-service-deactivate-token-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payment-token-service-deactivate-token-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-savings-program-settings-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payments-service-process-tax-refund-external-repayment-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-process-tax-refund-external-repayment-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-service-match-fingerprint-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-service-match-fingerprint-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-credit-program-notification-scheduled-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-password-reset-sms-verification-requested-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name abu-service-card-account-changed-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name abu-service-process-issuer-confirmation-error-record-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name abu-service-process-issuer-confirmation-error-record-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name adjudication-service-adjudication-report-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name adjudication-service-store-adjudication-vendor-request-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name adjudication-service-store-adjudication-vendor-request-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name adjudication-service-store-adjudication-vendor-response-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name adjudication-service-store-adjudication-vendor-response-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name admin-authorization-service-admin-user-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name admin-authorization-service-sync-permission-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name application-service-berbix-fetch-retry-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name application-service-berbix-token-retry-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name application-service-berbix-token-successfully-retried-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name application-service-credit-account-closed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name application-service-credit-limit-increase-applied-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name application-service-credit-limit-increase-offer-initiated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name application-service-credit-vendor-checks-retry-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name application-service-jito-credit-application-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name application-service-process-credit-app-soft-credit-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name application-service-process-credit-vendor-checks-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name application-service-process-preliminary-credit-vendor-checks-retry-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name application-service-process-preliminary-credit-vendor-checks-retry-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name application-service-process-savings-vendor-checks-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name application-service-savings-vendor-checks-retry-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name application-service-secured-credit-fund-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name application-service-secured-credit-initial-funding-transfer-declined-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name application-service-upd-auto-declined-credit-app-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name attestation-ledger-service-process-balance-summary-task-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name attestation-ledger-service-process-balance-summary-task.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name attestation-savings-transaction-service-balance-summary-generated-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name auto-transfer-service-create-or-cancel-ext-to-savings-auto-transfer-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name auto-transfer-service-create-or-cancel-ext-to-savings-auto-transfer.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name auto-transfer-service-create-or-cancel-s2c-auto-payment-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name auto-transfer-service-create-or-cancel-s2c-auto-payment.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name auto-transfer-service-create-or-cancel-savings-to-payee-auto-bill-pay-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-create-or-cancel-savings-to-payee-auto-bill-pay-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-credit-account-auto-payment-failed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-credit-account-auto-payment-transfer-processed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-credit-account-closed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-credit-account-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-execute-savings-to-credit-auto-payment-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-execute-savings-to-credit-auto-payment-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-execute-term-loan-auto-transfer-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-execute-term-loan-auto-transfer-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-ext-to-savings-auto-transfer-stepfn-executed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-ext-to-savings-auto-transfer-stepfn-executed-event --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-external-account-deleted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-external-account-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name auto-transfer-service-external-account-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-outbound-eft-rejected-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-savings-account-closed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-savings-account-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-savings-account-suspended-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-savings-account-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-savings-to-payee-auto-bill-pay-stepfn-executed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-savings-to-payee-auto-bill-pay-stepfn-executed-event --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-schedule-term-loan-auto-transfer-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-schedule-term-loan-auto-transfer-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-statement-data-processed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-term-loan-schedule-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name auto-transfer-service-transfer-contact-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name auto-transfer-service-user-upsert-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-account-marked-critically-delinquent-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-bill-split-requested-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-bill-split-requested-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-bill-split-resolved-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-bill-split-resolved-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-cancel-credit-card-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-cancel-credit-card-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-card-design-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-card-program-template-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-card-program-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-charged-off-account-interest-calculated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-cheque-bill-payment-processed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-credit-account-charged-off-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-credit-account-statement-revealed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-credit-application-abandoned-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-credit-application-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-credit-card-and-account-data-collected-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-credit-limit-increase-accepted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-credit-limit-replenished-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-credit-limit-restriction-query-generated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-credit-limit-restriction-query-generated-event --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-credit-program-scheduled-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-deposit-partner-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-dispute-closed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-dispute-opened-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-e-transfer-customer-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-e-transfer-fraud-check-response-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-execute-peer-to-peer-expiration-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-execute-peer-to-peer-expiration-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-external-account-rin-recieved-subscription-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-fraud-check-e-transfer-fulfillment-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-fraud-check-outgoing-e-transfer-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-fraud-vendor-postback-action-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-fraud-vendor-postback-action-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-fulfill-e-transfer-money-request-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-fund-secured-credit-with-external-account-initiated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-fund-secured-credit-with-savings-account-initiated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-get-accounts-details-response-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-hbc-card-created-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-hbc-card-created-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-inbound-eft-hold-processed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-inbound-eft-processed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-initiate-manual-mcd-replacement-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-initiate-manual-mcd-replacement-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-installments-credit-limit-replenished-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-jito-credit-application-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-mark-transaction-as-fraudulent-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-mark-transaction-as-fraudulent-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-mcd-card-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-mcd-transaction-processed-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-open-savings-account-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-outbound-eft-rejected-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-outbound-eft-release-funds-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-payment-token-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-prepaid-card-application-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-prepaid-card-creation-initialized-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-printed-statements-processed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-process-cdic-operations-task-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-process-cdic-operations-task.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-process-comply-advantage-fraud-check-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-process-comply-advantage-fraud-check-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-process-eft-transaction-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-process-eft-transaction.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-process-savings-account-cdic-hold-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-process-savings-account-cdic-hold-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-process-savings-to-term-loan-transfer-res-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payments-service-process-savings-to-term-loan-transfer-res.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-process-savings-to-term-loan-transfer-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-process-savings-to-term-loan-transfer.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name instant-tax-refund-service-process-tax-refund-and-charge-bundle-fee-res-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name instant-tax-refund-service-process-tax-refund-and-charge-bundle-fee-res.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-process-tax-refund-and-charge-bundle-fee-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-process-tax-refund-and-charge-bundle-fee.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-reclaim-outgoing-e-transfer-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-refund-reversal-debit-adjustment-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-reject-external-account-transfer-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-restriction-policy-association-changed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-restriction-policy-changed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-restriction-policy-triggered-action-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-restriction-policy-triggered-action-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-rewards-cash-out-to-credit-initiated-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-rewards-cash-out-to-savings-initiated-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-savings-interest-payment-attempted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-savings-program-arrangement-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-savings-program-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-savings-to-payee-auto-bill-pay-initiated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-secured-credit-application-abandoned-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-secured-credit-application-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-secured-credit-external-transfer-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-secured-credit-funds-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-security-funds-external-transfer-initiated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-security-funds-savings-transfer-initiated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-send-flinks-create-account-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-send-flinks-create-account-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-send-outgoing-aft-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-send-outgoing-e-transfer-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-settle-aft-money-request-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-telpay-bill-payment-processed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-transaction-processed-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-upload-outgoing-aft-file-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-user-paid-off-amount-owing-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name bank-service-user-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-scammer-service-credit-application-decision-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-scammer-service-credit-transaction-detection-response-received-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-scammer-service-credit-transaction-detection-response-received-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-scammer-service-credit-transaction-fraud-check-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-scammer-service-credit-transaction-fraud-check-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-scammer-service-declined-transaction-fraudnet-request-prepared-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-scammer-service-declined-transaction-fraudnet-update-prepared-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-scammer-service-e-transfer-fraud-check-request-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-scammer-service-etf-fraud-check-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-scammer-service-fraud-signal-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-scammer-service-restriction-policy-association-changed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-scammer-service-restriction-policy-changed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-scammer-service-savings-application-decision-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-scammer-service-secondary-checks-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-scammer-service-temp-dow-jones-back-fill-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-scammer-service-temp-dow-jones-back-fill-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-scammer-service-transaction-updated-task.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name card-scammer-service-user-logged-in-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-service-card-block-attempt-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-service-card-replacement-sent-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-service-card-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-service-complete-card-reissuance-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-service-complete-card-reissuance-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-service-credit-account-closed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-service-credit-application-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-service-reissue-card-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-service-reissue-card-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-service-secured-credit-application-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-vault-card-account-changed-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name card-vault-card-design-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-vault-card-program-template-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-vault-create-white-card-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-vault-create-white-card-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-vault-mcd-card-creation-initialized-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name card-vault-mcd-card-suspension-status-changed-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name card-vault-user-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name cardinal-service-card-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name cardinal-service-user-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name central-1-service-e-transfer-customer-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name central-1-service-handle-etransfer-commit-timeout-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name central-1-service-handle-etransfer-commit-timeout-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name central-1-service-process-outgoing-bill-payment-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name central-1-service-upload-outgoing-bill-payments-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name central-1-socket-iso-20022-logging-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name central-1-socket-iso-20022-logging-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name core-ledger-service-process-balance-summary-task-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name core-ledger-service-process-balance-summary-task.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name cra-service-approved-loan-application-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name cra-service-savings-account-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name cra-service-user-tax-information-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name cra-service-user-upserted-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name credit-delinquency-service-check-for-critically-delinquent-task-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name credit-delinquency-service-check-for-critically-delinquent-task.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name credit-delinquency-service-check-pending-credit-delinquency-block-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-delinquency-service-check-pending-credit-delinquency-block-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-delinquency-service-check-pending-delinquency-block-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-delinquency-service-check-pending-delinquency-block-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-delinquency-service-credit-account-charged-off-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-delinquency-service-credit-account-statement-revealed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-delinquency-service-evaluate-delinquency-block-task-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name credit-delinquency-service-evaluate-delinquency-block-task.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name credit-delinquency-service-evaluate-payments-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-delinquency-service-evaluate-payments-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-delinquency-service-payment-credit-allocated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-delinquency-service-regenerate-delinquency-data-for-account-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-delinquency-service-regenerate-delinquency-data-for-account-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-delinquency-service-regenerate-episode-snapshot-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-delinquency-service-regenerate-episode-snapshot-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-delinquency-service-regenerate-series-snapshot-task-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name credit-delinquency-service-regenerate-series-snapshot-task.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name credit-delinquency-service-resolve-delinquency-after-charge-off-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-delinquency-service-resolve-delinquency-after-charge-off-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-delinquency-service-series-snapshot-upserted-subscription-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-delinquency-service-transunion-creditvision-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-facility-service-credit-account-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-facility-service-hbc-employee-credit-declined-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-facility-service-maximum-dti-for-concentra-exceeded-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-facility-service-secured-credit-application-abandoned-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-facility-service-secured-credit-application-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-address-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-annual-income-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-application-metadata-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-berbix-retry-triggered-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-berbix-transaction-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-block-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-card-program-template-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-contact-information-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-credit-account-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name credit-onboarding-service-credit-product-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-date-of-birth-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-employment-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-encrypted-pin-stored-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-housing-info-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-id-verification-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-id-verification-synced-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-id-verification-unsynced-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-legacy-credit-application-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-name-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-partner-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-primary-checks-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-primary-checks-retry-succeeded-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-secondary-checks-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-secured-credit-funds-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-secured-credit-ini-funding-transfer-declined-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-update-pending-decline-application-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-onboarding-service-update-pending-decline-application-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-program-service-credit-program-requested-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-reporting-service-credit-card-statement-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-reporting-service-backfill-reports-task-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name credit-reporting-service-backfill-reports-task.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name credit-reporting-service-process-accounts-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-reporting-service-process-accounts-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name credit-reporting-service-secured-balance-summary-replicated-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name credit-transaction-balance-summary-generated-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name customer-support-service-user-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name decider-card-program-template-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name decider-credit-delinquency-block-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name decider-credit-transaction-fraud-check-request-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name decider-expire-transaction-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name decider-fraud-transaction-create-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name decider-fraud-transaction-create-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name decider-fraud-transaction-update-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name decider-fraud-transaction-update-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name decider-merchant-fingerprint-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name delinquency-service-credit-account-charged-off-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name delinquency-service-evaluate-debts-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name delinquency-service-execute-delinquency-block-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name delinquency-service-execute-delinquency-block-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name delinquency-service-resolve-delinquency-block-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name delinquency-service-resolve-delinquency-block-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name delinquency-service-schedule-delinquency-block-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name delinquency-service-schedule-delinquency-block-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name delinquency-service-transunion-credit-vision-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name dispute-service-billing-cycle-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name dispute-service-dispute-message-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name dtr-service-adjudication-report-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name dtr-service-card-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name dtr-service-charged-off-account-interest-calculated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name dtr-service-credit-account-balance-summary-generated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name dtr-service-credit-account-transaction-changed-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name dtr-service-credit-account-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name dtr-service-credit-card-statement-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name dtr-service-credit-facility-account-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name dtr-service-credit-limit-adjustment-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name dtr-service-delinquency-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name dtr-service-installment-plan-initialized-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name dtr-service-populate-report-records-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name dtr-service-populate-report-records-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name dtr-service-regenerate-report-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name dtr-service-regenerate-report-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name dtr-service-series-snapshot-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name dtr-service-transunion-credit-vision-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name dtr-service-user-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name e-transfer-service-savings-account-opened-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name e-transfer-service-user-upserted-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name eft-service-external-account-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name eft-service-handle-outbound-eft-fraud-check-webhook-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name eft-service-handle-outbound-eft-fraud-check-webhook.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name eft-service-outbound-eft-rejection-webhook-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name eft-service-outbound-eft-rejection-webhook-event --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name eft-service-savings-account-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name eft-service-savings-program-arrangement-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name eft-service-savings-program-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name external-plan-benefits-service-benefit-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name external-plan-benefits-service-user-benefit-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name external-plan-benefits-service-user-benefits-updated-event-v2-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name external-plan-benefits-service-user-membership-expiration-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name external-plan-benefits-service-user-membership-expiration-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name external-plan-benefits-service-user-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name i2c-service-update-card-attributes-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-adjudication-report-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-application-metadata-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-approved-credit-application-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-approved-credit-card-application-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-approved-investment-application-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-approved-loan-application-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-approved-savings-application-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-secondary-checks-information-retrieved-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-berbix-id-verification-report-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-berbix-metadata-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-berbix-token-retry-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-berbix-token-retry-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-comply-advantage-report-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-credit-application-decision-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-enstream-account-integrity-report-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-enstream-report-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-fpjs-visitor-identified-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-hbc-point-of-sale-identification-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-investment-account-completion-synced-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-investment-application-decision-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-iovation-digital-fraud-report-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-manual-id-verification-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-neo-in-store-manual-identification-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-prequalification-claimed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-prequalification-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-retry-primary-checks-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-retry-primary-checks-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-retry-secondary-checks-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-retry-secondary-checks-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-savings-application-decision-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-transunion-credit-vision-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-transunion-hard-credit-report-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-transunion-kyc-report-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-transunion-personal-fraud-report-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-transunion-soft-credit-check-report-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name identity-service-user-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name installments-service-user-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name installments-service-card-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name installments-service-credit-account-transaction-changed-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name installments-service-credit-account-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name installments-service-credit-information-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name installments-service-fingerprint-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name installments-service-installment-plan-balance-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name installments-service-installment-plan-repayment-method-invalidated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name installments-service-term-loan-charged-off-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name installments-service-term-loan-payment-successful-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name installments-service-term-loan-transfer-failed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name installments-service-transunion-creditvision-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name instant-tax-refund-service-approved-loan-application-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name instant-tax-refund-service-inbound-eft-credit-txn-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name instant-tax-refund-service-instant-tax-refund-balance-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name instant-tax-refund-service-instant-tax-refund-creation-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name instant-tax-refund-service-instant-tax-refund-creation-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name instant-tax-refund-service-itr-repayment-method-invalidated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name instant-tax-refund-service-loan-link-account-block-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name instant-tax-refund-service-prequalification-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name instant-tax-refund-service-prequalification-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name instant-tax-refund-service-savings-account-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name instant-tax-refund-service-savings-account-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name instant-tax-refund-service-term-loan-charged-off-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name instant-tax-refund-service-term-loan-nsf-charged-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name instant-tax-refund-service-term-loan-payment-successful-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name instant-tax-refund-service-term-loan-transfer-failed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name instant-tax-refund-service-user-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name investment-onboarding-service-address-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-annual-income-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-annual-reassessment-synced-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-application-flagged-for-review-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-application-metadata-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-berbix-retry-triggered-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-berbix-transaction-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-block-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-citizenship-module-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-contact-information-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-create-manual-review-ticket-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-create-manual-review-ticket-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-date-of-birth-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-employment-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-foreign-tax-information-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-housing-info-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-id-verification-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-id-verification-synced-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-id-verification-unsynced-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-investment-agreement-previews-synced-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-investment-application-reviewed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-investment-portfolio-changes-synced-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-investment-product-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-marital-information-module-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-monthly-debt-module-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-name-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-primary-checks-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-primary-checks-retry-succeeded-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-property-and-assets-module-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-questionnaire-reset-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-sin-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-total-debt-module-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-total-savings-module-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-update-investment-application-metadata-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-onboarding-service-update-investment-application-metadata-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-berbix-id-verification-report-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-close-accounts-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-close-accounts-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-close-incomplete-sub-account-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-close-incomplete-sub-account-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-complete-annual-risk-reassessment-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-complete-annual-risk-reassessment-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-complete-sub-account-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-complete-sub-account-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-create-manual-review-ticket-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-create-manual-review-ticket-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-create-new-sub-account-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-create-new-sub-account-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-create-user-id-verification-info-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-create-user-id-verification-info-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-external-account-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name investment-service-external-account-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-hbc-point-of-sale-indentification-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-initialize-new-goal-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-initialize-new-goal-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-investment-account-completion-data-populated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-investment-agreements-data-populated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-investment-annual-reassessment-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-investment-annual-reassessment-data-populated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-investment-portfolio-data-populated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-investment-product-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-investment-questionnaire-block-started-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-neo-in-store-manual-identification-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-account-status-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-cancel-order-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-cancel-order-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-complete-user-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-complete-user-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-create-deposit-order-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-create-deposit-order-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-create-full-withdraw-order-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-create-full-withdraw-order-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-create-partial-withdraw-order-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-create-partial-withdraw-order-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-create-user-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-create-user-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-delete-bank-account-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-delete-bank-account-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-transfer-status-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-transition-user-status-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-transition-user-status-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-update-scheduled-deposit-order-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-update-scheduled-deposit-order-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-update-tax-info-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-update-tax-info-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-update-user-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-update-user-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-user-status-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-one-vest-user-suitability-review-due-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-prepare-agreements-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-prepare-agreements-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-savings-account-closed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-savings-account-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-savings-account-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name investment-service-savings-account-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-sign-proactive-agreements-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-sign-proactive-agreements-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-update-goal-theme-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-update-goal-theme-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-update-suitability-agreements-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-update-suitability-agreements-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-update-suitability-goals-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-update-suitability-goals-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-update-suitability-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-update-suitability-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-update-user-id-verification-info-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-update-user-id-verification-info-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-user-annual-income-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-user-tax-information-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name investment-service-user-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name iso-vault-iso-message-reference-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name ledger-maintenance-service-aggregate-credit-entry-account-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name ledger-maintenance-service-aggregate-credit-entry-account.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name ledger-service-dispute-exchange-rate-variance-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name ledger-service-exchange-rate-discrepancy-identified-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name ledger-service-process-credit-account-balance-summary-fifo-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name ledger-service-process-credit-account-balance-summary-fifo.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name ledger-service-process-secured-credit-balance-summary-task-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name ledger-service-process-secured-credit-balance-summary-task.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name loan-credit-facility-service-balance-summary-generated-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name loan-credit-facility-service-instant-tax-refund-initialized-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name loan-credit-facility-service-term-loan-payment-successful-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name loan-credit-facility-service-user-reports-metadata-snapshot-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name loan-onboarding-service-address-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name loan-onboarding-service-application-metadata-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name loan-onboarding-service-approved-savings-application-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name loan-onboarding-service-berbix-retry-triggered-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name loan-onboarding-service-berbix-transaction-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name loan-onboarding-service-block-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name loan-onboarding-service-date-of-birth-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name loan-onboarding-service-employer-information-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name loan-onboarding-service-employment-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name loan-onboarding-service-id-verification-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name loan-onboarding-service-id-verification-synced-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name loan-onboarding-service-id-verification-unsynced-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name loan-onboarding-service-name-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name loan-onboarding-service-prequalification-claimed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name loan-onboarding-service-primary-checks-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name loan-onboarding-service-primary-checks-retry-succeeded-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name loan-onboarding-service-savings-account-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name loyalty-service-hbc-card-reissued-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name loyalty-service-hbc-credit-application-relinked-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-decider-billing-cycle-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-decider-card-program-template-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-decider-card-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-decider-credit-account-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-decider-delinquency-block-updated-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name mcd-decider-expire-dynamic-pin-encryption-key-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-decider-expire-dynamic-pin-encryption-key-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-decider-expire-transaction-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-decider-expire-transaction-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-decider-fraud-transaction-adjust-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-decider-fraud-transaction-adjust-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-decider-fraud-transaction-tell-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-decider-fraud-transaction-tell-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-decider-mcd-card-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-decider-merchant-fingerprint-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-decider-payment-token-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name mcd-decider-pin-block-generated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-decider-process-clearing-ipm-iso-message-fifo-task-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name mcd-decider-process-clearing-ipm-iso-message-fifo-task.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name mcd-decider-savings-account-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-decider-savings-account-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-decider-token-provisioning-card-block-attempted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-decider-transaction-manually-reversed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mcd-decider-user-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payment-token-service-send-network-message-res-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payment-token-service-send-network-message-res.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name mcd-socketron-send-network-message-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name mcd-socketron-send-network-message.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name mcd-socketron-send-network-message-task-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name mcd-socketron-send-network-message-task.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name merchant-analytics-service-redemption-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name merchant-analytics-service-rewards-transaction-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name merchant-analytics-service-user-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name merchant-billing-service-applied-bounty-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name merchant-billing-reward-redeemed-to-account-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name merchant-billing-balance-summary-generated-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name merchant-fingerprint-service-decider-fingerprint-upsert-failed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name merchant-fingerprint-service-fingerprint-manually-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name merchant-fingerprint-service-fingerprint-upsert-failed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mortgage-onboarding-service-address-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mortgage-onboarding-service-asset-information-module-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mortgage-onboarding-service-block-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mortgage-onboarding-service-cashflow-information-module-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mortgage-onboarding-service-date-of-birth-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mortgage-onboarding-service-employment-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mortgage-onboarding-service-marital-information-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mortgage-onboarding-service-name-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mortgage-service-applied-bounty-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mortgage-service-mortgage-application-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mortgage-service-process-mortgage-lead-request-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mortgage-service-process-mortgage-lead-request-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mortgage-service-process-webhook-mortgage-lead-request-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mortgage-service-process-webhook-mortgage-lead-request-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mortgage-service-transunion-credit-vision-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name mortgage-service-transunion-soft-credit-check-report-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name mortgage-service-user-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name neo-mart-applied-bonus-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name neo-mart-applied-bounty-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name neo-mart-benefit-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name neo-mart-calculate-lifetime-earnings-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name neo-mart-calculate-lifetime-earnings-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name neo-mart-card-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name neo-mart-credit-account-closed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name neo-mart-credit-account-transaction-changed-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name neo-mart-guaranteed-cashback-cycle-ended-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name neo-mart-guaranteed-cashback-cycle-ended-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name neo-mart-order-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name neo-mart-renew-subscription-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name neo-mart-renew-subscription-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name neo-mart-reward-redeemed-to-account-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name neo-mart-rewards-cash-out-to-credit-failed-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name neo-mart-rewards-cash-out-to-credit-succeeded-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name neo-mart-rewards-cash-out-to-savings-failed-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name neo-mart-rewards-cash-out-to-savings-succeeded-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name neo-mart-savings-account-transaction-changed-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name neo-mart-spend-summary-generated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name neo-mart-transaction-processed-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name neo-mart-user-benefit-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name neo-mart-user-rewards-data-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name notification-feed-service-applied-bonus-expiring-soon-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name notification-feed-service-applied-bonus-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name notification-feed-service-basket-bump-spend-amount-condition-not-met-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name notification-feed-service-brand-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name notification-feed-service-credit-account-auto-payment-disabled-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name notification-feed-service-credit-account-auto-payment-failed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name notification-feed-service-credit-auto-payment-fallback-successful-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name notification-feed-service-external-to-savings-transfer-overlimit-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name notification-feed-service-in-app-message-sent-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name notification-feed-service-in-progress-offer-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name notification-feed-service-installment-plan-payment-successful-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name notification-feed-service-top-up-processing-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name notification-feed-service-user-eligible-for-winback-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name notification-feed-service-user-notification-preferences-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name notification-feed-service-user-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name notification-feed-service-valid-offer-expiring-soon-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-credit-account-balance-evaluated-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-authentication-requested-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-card-pin-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-card-replacement-sent-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-card-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-credit-account-closed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-credit-account-opened-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-credit-account-statement-revealed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-credit-account-transaction-changed-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name partner-event-relay-service-credit-application-decision-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-credit-application-status-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-credit-delinquency-block-updated-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name partner-event-relay-service-credit-limit-increase-applied-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-dispute-closed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-dispute-opened-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-incoming-bill-payment-transaction-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-mcd-3ds-otp-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-partner-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-partner-upserted-event --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-savings-account-closed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-savings-account-opened-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-savings-account-statement-revealed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-savings-account-suspended-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-savings-account-transaction-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-savings-account-unsuspended-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-savings-application-decision-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-savings-application-status-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-secured-credit-application-funding-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-secured-credit-external-transfer-declined-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-secured-credit-funds-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-secured-credit-limit-increased-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-token-activation-code-notification-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-transaction-authorized-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-transaction-declined-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name partner-event-relay-service-user-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payments-service-external-account-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payment-token-service-card-account-changed-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payment-token-service-card-block-attempt-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payment-token-service-mcd-card-suspension-status-changed-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payment-token-service-card-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payment-token-service-handle-token-change-task-fifo-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payment-token-service-handle-token-change-task-fifo.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payment-token-service-issuer-file-update-response-task-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payment-token-service-issuer-file-update-response-task.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payment-token-service-mcd-card-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payment-token-service-user-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payment-token-service-verify-issuer-file-update-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payment-token-service-verify-issuer-file-update-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-addon-purchased-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-card-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-credit-account-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-credit-application-abandoned-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-delete-autodeposit-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-delete-autodeposit-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-e-transfer-customer-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-eft-manually-reviewed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-external-account-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payments-service-external-account-to-secured-credit-funding-initiated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-external-to-savings-auto-transfer-initiated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-inbound-eft-declined-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-initiate-tax-refund-funding-transfer-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-installment-plan-external-transfer-ivf-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-installment-plan-external-transfer-rin-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-loan-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name term-loan-service-process-external-to-term-loan-transfer-res-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name term-loan-service-process-external-to-term-loan-transfer-res.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payments-service-process-external-to-term-loan-transfer-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payments-service-process-external-to-term-loan-transfer.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payments-service-process-installment-plan-external-transfer-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-process-installment-plan-external-transfer-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-process-outbound-eft-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-process-outbound-eft-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-process-secured-credit-external-transfer-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-process-secured-credit-external-transfer-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-release-installment-plan-funds-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-release-installment-plan-funds-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-release-secured-credit-funds-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-release-secured-credit-funds-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-release-tax-refund-repayment-funds-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-release-tax-refund-repayment-funds-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-restriction-policy-association-changed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-restriction-policy-changed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-rewards-cashout-to-savings-transaction-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-savings-account-closed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-savings-account-opened-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-savings-program-arrangement-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payments-service-savings-program-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payments-service-savings-to-credit-auto-payment-triggered-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-savings-to-secured-credit-funding-initiated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-secured-credit-account-closed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-secured-credit-application-abandoned-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-secured-credit-deposit-account-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-secured-credit-external-transfer-ivf-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-secured-credit-external-transfer-rin-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-tax-refund-repayment-external-transfer-ivf-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-tax-refund-repayment-external-transfer-rin-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-telpay-bill-payments-file-uploaded-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-telpay-bill-payments-file-uploaded --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-update-autodeposit-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-update-autodeposit-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-update-e-transfer-customer-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-update-e-transfer-customer-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-upload-outbound-eft-file-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-upload-outbound-eft-file-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-upload-secured-credit-external-file-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-upload-secured-credit-external-file-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-upload-secured-credit-savings-eft-file-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-upload-secured-credit-savings-eft-file-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-upload-secured-credit-to-credit-eft-file-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name payments-service-upload-secured-credit-to-credit-eft-file-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name plans-service-applied-bonus-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name plans-service-credit-account-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name plans-service-instant-tax-refund-initialized-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name plans-service-renew-subscription-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name plans-service-renew-subscription-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name plans-service-savings-account-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name plans-service-user-rewards-data-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name plans-service-user-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name polly-service-async-notifier-for-unauthenticated-users-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name polly-service-async-notifier-for-unauthenticated-users-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name polly-service-async-notifier-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name user-service-claim-prequalification-res-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name user-service-claim-prequalification-res.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name prequalification-service-claim-prequalification-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name prequalification-service-claim-prequalification.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name prequalification-service-expire-prequalification-status-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name prequalification-service-expire-prequalification-status-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name prequalification-service-hashed-sin-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name prequalification-service-loan-prequalification-fee-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name prequalification-service-resend-prequalification-email-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name prequalification-service-resend-prequalification-email-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name prequalification-service-savings-application-abandoned-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name prequalification-service-user-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payments-service-process-savings-to-term-loan-transfer-res-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payments-service-process-savings-to-term-loan-transfer-res.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-process-savings-to-term-loan-transfer-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-process-savings-to-term-loan-transfer.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name term-loan-service-process-savings-to-term-loan-transfer-res-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name term-loan-service-process-savings-to-term-loan-transfer-res.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payments-service-process-savings-to-term-loan-transfer-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name payments-service-process-savings-to-term-loan-transfer.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name redemption-service-mcd-transaction-processed-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name redemption-service-process-transactions-processed-and-offers-task-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name redemption-service-process-transactions-processed-and-offers-task.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name redemption-service-settle-punch-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name redemption-service-settle-punch-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name redemption-service-settle-redemption-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name redemption-service-settle-redemption-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name redemption-service-settle-spend-entry-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name redemption-service-settle-spend-entry-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name redemption-service-transaction-processed-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name redemption-service-user-rewards-data-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name referral-analytics-service-applied-bounty-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name referral-analytics-service-evaluate-ambassador-bounty-period-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name referral-analytics-service-evaluate-ambassador-bounty-period-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name referral-service-approved-investment-application-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name referral-service-credit-application-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name referral-service-credit-application-user-information-reviewed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name referral-service-credit-application-user-preliminary-data-collected-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name referral-service-expired-bonus-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name referral-service-expired-bounty-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name referral-service-jito-credit-application-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name referral-service-mortgage-account-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name referral-service-mortgage-lead-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name referral-service-prepaid-card-application-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name referral-service-savings-account-opened-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name referral-service-threshold-met-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name restriction-policy-service-associate-restriction-policy-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name restriction-policy-service-associate-restriction-policy-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name restriction-policy-service-disassociate-restriction-policy-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name restriction-policy-service-disassociate-restriction-policy-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name restriction-policy-service-evaluation-audit-log-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name restriction-policy-service-evaluation-audit-log-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-service-applied-bonus-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-service-batch-update-transactions-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-service-batch-update-transactions-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-service-benefit-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name rewards-service-calculate-users-collection-order-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-service-calculate-users-collection-order-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-service-card-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-service-check-winback-eligibility-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-service-check-winback-eligibility-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-service-fingerprint-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-service-handle-delay-card-replaced-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-service-handle-delay-card-replaced-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-service-location-funding-account-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-service-mcd-transaction-processed-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name rewards-service-offer-expiring-soon-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-service-transaction-processed-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name rewards-service-user-benefit-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name rewards-service-user-wizard-data-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-store-service-order-processed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-store-service-order-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-store-service-region-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-store-service-rewards-account-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-store-service-user-rewards-data-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name rewards-store-service-user-rewards-scheme-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-store-service-user-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name rewards-wizard-service-brand-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-account-service-create-savings-account-cmd-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name savings-account-service-create-savings-account-cmd.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name savings-account-service-savings-account-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name savings-account-t5-slip-generator-t5-slip-data-processed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-onboarding-service-address-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-onboarding-service-application-metadata-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-onboarding-service-berbix-retry-triggered-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-onboarding-service-berbix-transaction-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-onboarding-service-block-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-onboarding-service-date-of-birth-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-onboarding-service-employment-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-onboarding-service-foreign-tax-information-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-onboarding-service-id-verification-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-onboarding-service-id-verification-synced-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-onboarding-service-id-verification-unsynced-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-onboarding-service-move-account-deposit-partner-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-onboarding-service-move-account-deposit-partner-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-onboarding-service-name-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-onboarding-service-prepaid-card-application-pin-set-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-onboarding-service-prepaid-card-creation-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-onboarding-service-prequalification-claimed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-onboarding-service-primary-checks-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-onboarding-service-primary-checks-retry-succeeded-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-onboarding-service-savings-account-closed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-onboarding-service-savings-account-replication-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name savings-onboarding-service-savings-product-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-onboarding-service-sin-module-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-statement-pdf-generator-data-processed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-transaction-service-balance-summary-generated-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name eft-service-clear-savings-withdrawal-authorization-cmd-res-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name eft-service-clear-savings-withdrawal-authorization-cmd-res.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name savings-transaction-service-clear-savings-withdrawal-authorization-cmd-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name savings-transaction-service-clear-savings-withdrawal-authorization-cmd.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name savings-transaction-service-record-ogl-entry-task-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name savings-transaction-service-record-ogl-entry-task.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-record-savings-deposit-cmd-res-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name bank-service-record-savings-deposit-cmd-res.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name savings-transaction-service-record-savings-deposit-cmd-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name savings-transaction-service-record-savings-deposit-cmd.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name eft-service-release-savings-deposit-hold-cmd-res-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name eft-service-release-savings-deposit-hold-cmd-res.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name savings-transaction-service-release-savings-deposit-hold-cmd-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name savings-transaction-service-release-savings-deposit-hold-cmd.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name eft-service-reverse-transaction-cmd-res-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name eft-service-reverse-transaction-cmd-res.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name savings-transaction-service-reverse-transaction-cmd-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name savings-transaction-service-reverse-transaction-cmd.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name savings-transaction-service-savings-interest-cutoff-calculated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-transaction-service-savings-statement-period-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name savings-transaction-service-savings-transaction-upserted-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name sendy-service-mcd-3ds-otp-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-applied-bonus-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-applied-bounty-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-approved-credit-application-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-approved-savings-application-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-card-reissuance-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-card-reissuance-requested-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-card-reissued-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-credit-account-auto-payment-disabled-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-credit-account-auto-payment-failed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-credit-application-manually-approved-for-secured-credit-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-credit-application-ops-reviewed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-credit-auto-payment-successful-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-credit-delinquency-block-updated-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name sendy-service-credit-limit-increase-applied-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-credit-limit-restriction-applied-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-delayed-event-handling-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-delinquency-block-updated-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name sendy-service-direct-deposit-registration-uploaded-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-disposition-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-external-to-savings-subscription-auto-disabled-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-fingerprint-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-fund-secured-account-external-funds-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-fund-secured-account-external-funds-rejected-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-handle-credit-transaction-detection-response-received-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-handle-credit-transaction-detection-response-received-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-in-store-credit-application-declined-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-installment-plan-external-payment-rejected-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-installment-plan-initialized-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-installment-plan-savings-insufficient-funds-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-installment-repayment-method-invalidated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-instant-tax-refund-nsf-charged-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-instant-tax-refund-payment-failed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-instant-tax-refund-payment-successful-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-instant-tax-refund-repayment-method-invalidated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-investment-application-ops-reviewed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-investment-user-annual-reassessment-notification-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-investment-user-annual-reassessment-notification-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-loan-agreement-generated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-loan-application-ops-reviewed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-mcd-wallet-activated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-merchant-email-verification-requested-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-new-investment-account-type-opened-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-order-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-order-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-outbound-eft-transaction-rejected-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-outbound-eft-transaction-settled-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-password-existence-checked-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-phone-verification-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-prepaid-card-application-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-prepaid-settled-transaction-authorized-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-prepaid-transaction-authorized-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-prepaid-transaction-declined-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-prepaid-transaction-reversed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-prequalification-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-prequalification-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-prequalification-url-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-replacement-card-shipped-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-restriction-policy-association-changed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-restriction-policy-changed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-retry-message-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-reward-redeemed-to-account-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name sendy-service-rewards-cash-out-to-credit-failed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-rewards-cash-out-to-savings-failed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-savings-application-ops-reviewed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-savings-t5-slip-revealed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-savings-to-payee-subscription-auto-disabled-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-secured-credit-application-manually-reviewed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-secured-credit-limit-decrease-unsuccessful-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-secured-credit-limit-decreased-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-secured-credit-limit-increase-unsuccessful-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-secured-credit-limit-increased-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-security-funds-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-sts-savings-account-balance-summary-generated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-token-activation-code-notification-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-top-up-processing-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-user-account-unusual-activity-detected-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-user-email-verification-requested-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-user-initialized-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-user-membership-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-user-notification-preferences-updated-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-user-notification-preferences-updated-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-user-notification-settings-updated-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-user-rewards-plan-actions-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name sendy-service-web-to-app-deep-link-requested-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name settler-financial-advice-message-received-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name settler-financial-advice-message-received.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name settler-fraud-transaction-create-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name settler-fraud-transaction-create-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-rewards-account-transaction-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-rewards-service-credit-transaction-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-applied-bonus-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-applied-bounty-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-batch-update-fingerprint-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-batch-update-fingerprint-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-bill-pay-vendor-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-brand-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-card-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-credit-account-closed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-credit-account-opened-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-credit-account-transaction-deleted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-credit-account-transaction-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-evaluate-threshold-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-evaluate-threshold-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-fingerprint-spend-group-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-fingerprint-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-guaranteed-cashback-cycle-ended-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-invalidate-user-period-snapshot-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-invalidate-user-period-snapshot-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-retry-transaction-fingerprint-update-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-retry-transaction-fingerprint-update-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-rewards-account-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-savings-account-closed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-savings-account-opened-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-savings-account-transaction-deleted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name spend-analytics-service-savings-account-transaction-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name statement-gen-card-program-template-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name statement-gen-credit-account-charged-off-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name statement-gen-credit-limit-increase-applied-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name statement-gen-interest-payment-evaluated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name statement-gen-process-savings-account-t5-slip-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name statement-gen-process-savings-account-t5-slip-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name statement-gen-savings-account-statement-requested-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name statement-service-credit-application-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name statement-service-generate-statement-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name statement-service-jito-approved-credit-application-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name statement-service-printed-statement-requested-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name term-loan-service-balance-summary-generated-event-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name term-loan-service-external-account-deleted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name term-loan-service-external-to-term-loan-late-decline-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name term-loan-service-installment-plan-initialized-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name term-loan-service-instant-tax-refund-cra-deposit-received-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name term-loan-service-instant-tax-refund-initialized-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name term-loan-service-process-immediate-payment-task-dlq.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name term-loan-service-process-immediate-payment-task.fifo --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true
awslocal sqs create-queue --queue-name term-loan-service-savings-account-closed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name term-loan-service-savings-account-suspended-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name term-loan-service-term-loan-auto-payment-triggered-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-approved-credit-application-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-approved-credit-card-application-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-approved-investment-application-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-approved-loan-application-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-approved-savings-application-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-baas-credit-application-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-baas-savings-application-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-baas-secured-credit-application-created-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-citizenship-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-credit-application-decision-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-credit-disclosure-accepted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-credit-product-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-credit-user-information-reviewed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-investment-account-completion-synced-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-investment-agreements-block-started-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-investment-annual-reassessment-started-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-investment-application-abandoned-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-investment-application-decision-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-investment-portfolio-block-started-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-investment-product-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-investment-questionnaire-block-started-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-investment-user-information-reviewed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-loan-application-decision-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-loan-user-information-reviewed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-marital-information-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-metadata-updated-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-metadata-updated-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-prepaid-card-creation-initialized-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-risk-capacity-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-savings-application-abandoned-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-savings-application-decision-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-savings-product-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-savings-user-information-reviewed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-sin-income-tax-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-user-tax-information-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name unified-onboarding-service-user-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name user-service-admin-user-roles-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name user-service-block-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name user-service-credit-card-application-completed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name user-service-fetch-iovation-report-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name user-service-fetch-iovation-report-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name user-service-hbc-in-store-setup-password-reminder-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name user-service-in-store-application-credit-reason-declined-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name user-service-investment-account-closed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name user-service-investment-account-opened-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name user-service-investment-suitability-annual-income-updated-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name user-service-jito-in-store-application-credit-reason-declined-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name user-service-metadata-upserted-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name user-service-mortgage-account-opened-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name user-service-prequalification-claimed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name user-service-reminder-claim-profile-instore-applications-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name user-service-restriction-policy-association-changed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name user-service-restriction-policy-changed-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name user-service-savings-application-abandoned-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name user-service-user-authorized-support-event-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name whodunnit-service-admin-audit-log-event-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name whodunnit-service-process-customer-change-logs-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name whodunnit-service-process-customer-change-logs-task --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name whodunnit-service-process-customer-change-logs-task-dlq --attributes MessageRetentionPeriod=86400
awslocal sqs create-queue --queue-name whodunnit-service-process-customer-change-logs-task --attributes MessageRetentionPeriod=86400
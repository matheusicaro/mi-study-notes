const chalk = require('chalk');
const { SNS } = require('@aws-sdk/client-sns');
const { SQS } = require('@aws-sdk/client-sqs');

const resources = require('../resources.json');

(async () => {
  let topicCount = 0;
  let queueCount = 0;
  let subscriptionCount = 0;

  const serviceFilters = process.argv.slice(2);

  const sns = new SNS({
    endpoint: 'http://localhost:4566',
    region: 'ca-central-1',
    credentials: {
      accessKeyId: 'test',
      secretAccessKey: 'test',
    },
  });
  const sqs = new SQS({
    endpoint: 'http://localhost:4566',
    region: 'ca-central-1',
    credentials: {
      accessKeyId: 'test',
      secretAccessKey: 'test',
    },
  });

  for (const topic of resources.topics) {
    if (serviceFilters.length > 0 && !serviceFilters.some((service) => topic.includes(service))) {
      continue;
    }

    const newTopic = await sns.createTopic({
      Name: topic,
      Attributes: {
        FifoTopic: topic.endsWith('.fifo'),
      },
    });

    console.log(`${chalk.yellow('TOPIC:     ')} ${newTopic.TopicArn}`);

    topicCount += 1;
  }

  for (const queue of resources.queues) {
    if (serviceFilters.length > 0 && !serviceFilters.some((service) => queue.name.includes(service))) {
      continue;
    }

    const newQueue = await sqs.createQueue({
      QueueName: queue.name,
      Attributes: {
        MessageRetentionPeriod: '86400',
        ...(queue.name.endsWith('.fifo') ? { FifoQueue: queue.name.endsWith('.fifo') } : {}),
      },
    });

    console.log(`${chalk.green('QUEUE:     ')} ${newQueue.QueueUrl}`);

    queueCount += 1;

    if (serviceFilters.length > 0 && !serviceFilters.some((service) => queue.topic.includes(service))) {
      continue;
    }

    await sns.subscribe({
      Protocol: 'sqs',
      TopicArn: `arn:aws:sns:ca-central-1:000000000000:${queue.topic}`,
      Endpoint: `http://localhost:4566/000000000000/${queue.name}`,
    });

    console.log(`${chalk.magenta('SUBSCRIBE: ')} arn:aws:sns:ca-central-1:000000000000:${queue.topic}`);

    subscriptionCount += 1;
  }

  for (const taskQueue of resources.taskQueues) {
    if (serviceFilters.length > 0 && !serviceFilters.some((service) => taskQueue.includes(service))) {
      continue;
    }

    const newQueue = await sqs.createQueue({
      QueueName: taskQueue,
      Attributes: {
        MessageRetentionPeriod: '86400',
        ...(taskQueue.endsWith('.fifo') ? { FifoQueue: taskQueue.endsWith('.fifo') } : {}),
      },
    });

    console.log(`${chalk.green('QUEUE:     ')} ${newQueue.QueueUrl}`);

    queueCount += 1;
  }

  console.log();
  console.log(`Created ${topicCount} topics, ${queueCount} queues, ${subscriptionCount} subscriptions`);
})();

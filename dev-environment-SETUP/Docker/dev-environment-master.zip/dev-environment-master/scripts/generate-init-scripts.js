const fs = require('fs');
const path = require('path');

const resources = require('../resources.json');

(async () => {
  const commands = ['#!/bin/sh'];

  for (const topic of resources.topics) {
    if (topic.endsWith('.fifo')) {
      commands.push(`awslocal sns create-topic --name ${topic} --attributes FifoTopic=true`);
    } else {
      commands.push(`awslocal sns create-topic --name ${topic}`);
    }
  }

  for (const queue of resources.queues) {
    if (queue.name.endsWith('.fifo')) {
      commands.push(
        `awslocal sqs create-queue --queue-name ${queue.name} --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true`
      );
    } else {
      commands.push(`awslocal sqs create-queue --queue-name ${queue.name} --attributes MessageRetentionPeriod=86400`);
    }

    commands.push(
      `awslocal sns subscribe --topic-arn arn:aws:sns:ca-central-1:000000000000:${queue.topic} --notification-endpoint http://localhost:4566/000000000000/${queue.name} --protocol sqs`
    );
  }

  for (const taskQueue of resources.taskQueues) {
    if (taskQueue.endsWith('.fifo')) {
      commands.push(
        `awslocal sqs create-queue --queue-name ${taskQueue} --attributes MessageRetentionPeriod=86400 --attributes FifoQueue=true`
      );
    } else {
      commands.push(`awslocal sqs create-queue --queue-name ${taskQueue} --attributes MessageRetentionPeriod=86400`);
    }
  }

  fs.writeFileSync(path.join(__dirname, 'localstack', 'init-queues.sh'), commands.join('\n'));
})();

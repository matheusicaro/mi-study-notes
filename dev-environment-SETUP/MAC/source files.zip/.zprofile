
eval "$(/opt/homebrew/bin/brew shellenv)"

##
# Your previous /Users/matheus/.zprofile file was backed up as /Users/matheus/.zprofile.macports-saved_2023-09-30_at_10:42:54
##

# MacPorts Installer addition on 2023-09-30_at_10:42:54: adding an appropriate PATH variable for use with MacPorts.
export PATH="/opt/local/bin:/opt/local/sbin:$PATH"
# Finished adapting your PATH environment variable for use with MacPorts.


# MacPorts Installer addition on 2023-09-30_at_10:42:54: adding an appropriate MANPATH variable for use with MacPorts.
export MANPATH="/opt/local/share/man:$MANPATH"
# Finished adapting your MANPATH environment variable for use with MacPorts.


# Setting PATH for Python 3.13
# The original version is saved in .zprofile.pysave
PATH="/Library/Frameworks/Python.framework/Versions/3.13/bin:${PATH}"
export PATH
